//Type your code here\\\
var solvedMTTRView = ["114133587374"];
var cseSolvedMTTR = [];
var productSolvedMTTR = [];
var cloudSolvedMTTR = [];
var cseCurrentMonthTickets = [];
var cloudCurrentMonthTickets = [];
var productCurrentMonthTickets = [];
var cseSolvedMTTRVal = 0;
var productSolvedMTTRVal = 0;
var cloudSolvedMTTRVal = 0;
var overAllSolvedMTTRVal = 0;

function solvedMTTR() {
    if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
        var operationName = mobileFabricConfiguration.integrationServices[0].operations[4];
        headers = {};
        data = {
            "viewId": solvedMTTRView[0]
        };
        mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
        mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, solvedMTTRSuccess, solvedMTTRFailure);
    } else {
        alert("Network Error Occured");
    }
}

function solvedMTTRSuccess(res) {
    if (res.ticketsCount !== "0") {
        for (var m = 0; m < res.tickets.length; m++) {
            var id = res.tickets[m].AssigneeId;
            if (id === 14255408 || id === 14272801548) {
                cseSolvedMTTR.push(res.tickets[m]);
            } else if (id === 235456932) {
                productSolvedMTTR.push(res.tickets[m]);
            } else if (id === 256357194) {
                cloudSolvedMTTR.push(res.tickets[m]);
            }
        }
        if (m === res.tickets.length) {
            getCurrentMonthSolvedTickets();
        }
    }
}

function solvedMTTRFailure(res) {
    alert("Error in Solved MTTR for this month");
}

function getCurrentMonthSolvedTickets() {
    for (var i = 0; i < cseSolvedMTTR.length; i++) {
        var date = new Date();
        var solvedDate = cseSolvedMTTR[i].MetricSet[0].SolvedAt;
        var solvedFormat = new Date(solvedDate);
        currentRunningMonth = date.getMonth() + 1;
        solvedMonth = solvedFormat.getMonth() + 1;
        if (currentRunningMonth === solvedMonth) {
            var createdAt = cseSolvedMTTR[i].CreatedAt;
            var createdNew = new Date(createdAt);
            var hours = Math.abs(solvedFormat - createdNew) / 36e5;
            cseSolvedMTTR[i].hoursSpent = hours;
            cseCurrentMonthTickets.push(cseSolvedMTTR[i]);
        }
    }
    for (var j = 0; j < productSolvedMTTR.length; j++) {
        var dateProd = new Date();
        var solvedDateProd = productSolvedMTTR[j].MetricSet[0].SolvedAt;
        var solvedFormatProd = new Date(solvedDateProd);
        currentRunningMonth = dateProd.getMonth() + 1;
        solvedMonth = solvedFormatProd.getMonth() + 1;
        if (currentRunningMonth === solvedMonth) {
            var createdAtProd = productSolvedMTTR[j].CreatedAt;
            var createdNewProd = new Date(createdAtProd);
            var hoursProd = Math.abs(solvedFormatProd - createdNewProd) / 36e5;
            productSolvedMTTR[j].hoursSpent = hoursProd;
            productCurrentMonthTickets.push(productSolvedMTTR[j]);
        }
    }
    for (var k = 0; k < cloudSolvedMTTR.length; k++) {
        var dateCloud = new Date();
        var solvedDateCloud = cloudSolvedMTTR[k].MetricSet[0].SolvedAt;
        var solvedFormatCloud = new Date(solvedDateCloud);
        currentRunningMonth = dateCloud.getMonth() + 1;
        solvedMonth = solvedFormatCloud.getMonth() + 1;
        if (currentRunningMonth === solvedMonth) {
            var createdAtCloud = cloudSolvedMTTR[k].CreatedAt;
            var createdNewCloud = new Date(createdAtCloud);
            var hoursCloud = Math.abs(solvedFormatCloud - createdNewCloud) / 36e5;
            cloudSolvedMTTR[k].hoursSpent = hoursCloud;
            cloudCurrentMonthTickets.push(cloudSolvedMTTR[k]);
        }
    }
    if (k === cloudSolvedMTTR.length) {
        solvedMTTRCalculation();
    }
}

function solvedMTTRCalculation() {
    tempCseHours = 0;
    tempProductHours = 0;
    tempCloudHours = 0;
    for (var i = 0; i < cseCurrentMonthTickets.length; i++) {
        tempCseHours += cseCurrentMonthTickets[i].hoursSpent;
    }
    for (var j = 0; j < productCurrentMonthTickets.length; j++) {
        tempProductHours += productCurrentMonthTickets[j].hoursSpent;
    }
    for (var k = 0; k < cloudCurrentMonthTickets.length; k++) {
        tempCloudHours += cloudCurrentMonthTickets[k].hoursSpent;
    }
    overAllSolvedMonthHours = tempCseHours + tempProductHours + tempCloudHours;
    cseDays = tempCseHours / 24;
    cseDays = Math.round(cseDays * 10) / 10;
    if (cseCurrentMonthTickets.length !== 0) cseSolvedMTTRVal = cseDays / (cseCurrentMonthTickets.length);
    //erAllSolvedMTTRVal+=cseSolvedMTTRVal;
    cseSolvedMTTRVal = Math.round(cseSolvedMTTRVal * 10) / 10;
    prodDays = tempProductHours / 24;
    prodDays = Math.round(prodDays * 10) / 10;
    if (productCurrentMonthTickets.length !== 0) productSolvedMTTRVal = prodDays / (productCurrentMonthTickets.length);
    //verAllSolvedMTTRVal+=productSolvedMTTRVal;
    productSolvedMTTRVal = Math.round(productSolvedMTTRVal * 10) / 10;
    cloudDays = tempCloudHours / 24;
    cloudDays = Math.round(cloudDays * 10) / 10;
    if (cloudCurrentMonthTickets.length !== 0) cloudSolvedMTTRVal = cloudDays / (cloudCurrentMonthTickets.length);
    //    overAllSolvedMTTRVal+=cloudSolvedMTTRVal;
    //    overAllSolvedMTTRVal = overAllSolvedMTTRVal/3;
    //    overAllSolvedMTTRVal = Math.round( overAllSolvedMTTRVal * 10 ) / 10;
    cloudSolvedMTTRVal = Math.round(cloudSolvedMTTRVal * 10) / 10;
    overallDays = overAllSolvedMonthHours / 24;
    overallDays = Math.round(overallDays * 10) / 10;
    if (cseCurrentMonthTickets.length !== 0 || productCurrentMonthTickets.length !== 0 || cloudCurrentMonthTickets.length !== 0) overAllSolvedMTTRVal = overallDays / (cseCurrentMonthTickets.length + productCurrentMonthTickets.length + cloudCurrentMonthTickets.length);
    overAllSolvedMTTRVal = Math.round(overAllSolvedMTTRVal * 10) / 10;
    temp = {
        "premierValue": []
    };
    temp.premierValue.push(overAllSolvedMTTRVal);
    temp.premierValue.push(cseSolvedMTTRVal);
    temp.premierValue.push(productSolvedMTTRVal);
    temp.premierValue.push(cloudSolvedMTTRVal);
    frmDashboard.gauge.chartData = temp;
    google.charts.load('current', {
        'packages': ['gauge']
    });
    google.charts.setOnLoadCallback(drawGuageChart);
    //kony.timer.schedule(a, refreshApp, 300, true);
    drawLineChart();
    // kony.application.dismissLoadingScreen();
}