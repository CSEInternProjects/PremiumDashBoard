//Type your code here
firstResponseCseBreached = [];
firstResponseProductBreached = [];
var hours;
var days;

function showPopup(context) {
    var val, n;
    var flxId = context.constructorList[0].id;
    frmDashboard.flxPopupLead.segPopupLead.widgetDataMap = {
        slblTicket: "slblTicket",
        slblSeverity: "slblSeverity",
        slblCustName: "slblCustName",
        slblCreated: "slblCreated",
        slblPsAssignee: "slblPsAssignee",
        lblTicket: "valId",
        lblSeverity: "severityOfTicket",
        lblCustName: "CName",
        lblCreated: "days",
        lblPsAssignee: "PSAssignee"
    };
    frmDashboard.flxPopupLag.segPopupLag.widgetDataMap = {
        slblTicket: "slblTicket",
        slblSeverity: "slblSeverity",
        slblCustName: "slblCustName",
        slblCreated: "slblCreated",
        slblPsAssignee: "slblPsAssignee",
        lblTicket: "valId",
        lblSupportPlan: "SupportPlan",
        lblSeverity: "severityOfTicket",
        lblCustName: "CName",
        lblCreated: "days",
        lblPsAssignee: "PSAssignee"
    };
    arrToSetSegData = [
        [{
            slblTicket: "Ticket Id",
            slblSupportPlan: "Support Plan",
            slblSeverity: "Severity",
            slblCustName: "Customer Name",
            slblCreated: "Age(Days)",
            slblUpdated: "UpdatedAt",
            slblPsAssignee: "CSE Assignee"
        }, ]
    ];
    switch (flxId) {
        case "flxRTB0":
            for (n = 0; n < popupCseTicketsArr.length; n++) {
                hours = popupCseTicketsArr[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                popupCseTicketsArr[n].days = days;
                valId = popupCseTicketsArr[n].ticketId;
                popupCseTicketsArr[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(popupCseTicketsArr);
            frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
            break;
        case "flxRTB1":
            for (n = 0; n < popupProductTicketsArr.length; n++) {
                hours = popupProductTicketsArr[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                popupProductTicketsArr[n].days = days;
                valId = popupProductTicketsArr[n].ticketId;
                popupProductTicketsArr[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(popupProductTicketsArr);
            frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
            break;
        case "flxRTB2":
            for (n = 0; n < popupCloudTicketsArr.length; n++) {
                hours = popupCloudTicketsArr[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                popupCloudTicketsArr[n].days = days;
                valId = popupCloudTicketsArr[n].ticketId;
                popupCloudTicketsArr[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(popupCloudTicketsArr);
            frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
            break;
        case "flxRB0":
            for (n = 0; n < popupCseTicketsBreachedArr.length; n++) {
                hours = popupCseTicketsBreachedArr[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                popupCseTicketsBreachedArr[n].days = days;
                valId = popupCseTicketsBreachedArr[n].ticketId;
                popupCseTicketsBreachedArr[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(popupCseTicketsBreachedArr);
            frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            break;
        case "flxRB1":
            for (n = 0; n < popupProductTicketsBreachedArr.length; n++) {
                hours = popupProductTicketsBreachedArr[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                popupProductTicketsBreachedArr[n].days = days;
                valId = popupProductTicketsBreachedArr[n].ticketId;
                popupProductTicketsBreachedArr[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(popupProductTicketsBreachedArr);
            frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            break;
        case "flxRB2":
            for (n = 0; n < popupCloudTicketsBreachedArr.length; n++) {
                hours = popupCloudTicketsBreachedArr[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                popupCloudTicketsBreachedArr[n].days = days;
                valId = popupCloudTicketsBreachedArr[n].ticketId;
                popupCloudTicketsBreachedArr[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(popupCloudTicketsBreachedArr);
            frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            break;
        case "flxMttr0":
            for (n = 0; n < mttrCseTickets.length; n++) {
                hours = mttrCseTickets[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                mttrCseTickets[n].days = days;
                valId = mttrCseTickets[n].ticketId;
                mttrCseTickets[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(mttrCseTickets);
            frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            break;
        case "flxMttr1":
            for (n = 0; n < mttrProductTickets.length; n++) {
                hours = mttrProductTickets[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                mttrProductTickets[n].days = days;
                valId = mttrProductTickets[n].ticketId;
                mttrProductTickets[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(mttrProductTickets);
            frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            break;
        case "flxMttr2":
            for (n = 0; n < mttrCloudTickets.length; n++) {
                hours = mttrCloudTickets[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                mttrCloudTickets[n].days = days;
                valId = mttrCloudTickets[n].ticketId;
                mttrCloudTickets[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(mttrCloudTickets);
            frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            break;
        case "flxFRB0":
            for (n = 0; n < firstResponseCseBreached.length; n++) {
                hours = firstResponseCseBreached[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                firstResponseCseBreached[n].days = days;
                valId = firstResponseCseBreached[n].ticketId;
                firstResponseCseBreached[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(firstResponseCseBreached);
            frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            break;
        case "flxFRB1":
            for (n = 0; n < firstResponseProductBreached.length; n++) {
                hours = firstResponseProductBreached[n].hours;
                days = hours / 24;
                days = Math.round(days * 10) / 10;
                firstResponseProductBreached[n].days = days;
                valId = firstResponseProductBreached[n].ticketId;
                firstResponseProductBreached[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
            }
            arrToSetSegData[0].push(firstResponseProductBreached);
            frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            break;
    }
    if (arrToSetSegData[0][1].length !== 0) {
        flxRowTemp.forceLayout();
        frmDashboard.flxIndicators.opacity = 0.1;
        frmDashboard.flxIndicators.forceLayout();
        if (flxId === "flxRTB0" || flxId === "flxRTB1" || flxId === "flxRTB2") {
            frmDashboard.flxPopupLead.setVisibility(true);
            frmDashboard.flxPopupLead.forceLayout();
        } else if (flxId === "flxRB0" || flxId === "flxRB1" || flxId === "flxRB2" || flxId === "flxMttr0" || flxId === "flxMttr1" || flxId === "flxMttr2" || flxId === "flxFRB0" || flxId === "flxFRB1") {
            frmDashboard.flxPopupLag.setVisibility(true);
            frmDashboard.flxPopupLag.forceLayout();
        }
    } else {
        frmDashboard.flxIndicators.opacity = 1;
        alert("Sorry there are no tickets to display");
    }
}