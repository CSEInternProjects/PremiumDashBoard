popupTicketsArr = [];
mttrTicketsArr = [];
criticalHours = 0;
highHours = 0;
mediumHours = 0;
lowHours = 0;
firstResponseBreachedArr = [];
var mttrCseTickets = [];
var mttrProductTickets = [];
var mttrCloudTickets = [];
popupTicketsBreachedArr = [];

function criticalTicketsToBreach(arr1) {
    // kony.print("arr1 length :"+arr1.length);
    //   kony.print("arr:"+JSON.Stringify(arr1));
    tempArr = [];
    tempArr1 = [];
    for (var k = 0; k < arr1.length; k++) {
        var createdTime = arr1[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr1[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        criticalHours += hours;
        if (hours > 21 && hours <= 24) {
            arr1[k].hours = hours;
            arr1[k].CreatedAt = createdDateTime;
            arr1[k].UpdatedAt = updatedDateTime;
            delete arr1[k].CreatedNew;
            delete arr1[k].UpdatedNew;
            delete arr1[k].CustomField;
            tempArr.push(arr1[k]);
            popupTicketsArr.push(arr1[k]);
        }
    }
    return tempArr;
}

function criticalTicketsBreached(arr2) {
    //kony.print("arr2 length :"+arr2.length);
    //   kony.print("arr:"+JSON.Stringify(arr2));
    tempArr = [];
    for (var k = 0; k < arr2.length; k++) {
        var createdTime = arr2[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr2[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 24 && hours > 192) {
            arr2[k].hours = hours;
            arr2[k].CreatedAt = createdDateTime;
            arr2[k].UpdatedAt = updatedDateTime;
            delete arr2[k].CreatedNew;
            delete arr2[k].UpdatedNew;
            delete arr2[k].CustomField;
            //tempArr1.push(arr2[k]);
            mttrTicketsArr.push(arr2[k]);
            tempArr.push(arr2[k]);
            popupTicketsBreachedArr.push(arr2[k]);
        } else if (hours > 24) {
            arr2[k].hours = hours;
            arr2[k].CreatedAt = createdDateTime;
            arr2[k].UpdatedAt = updatedDateTime;
            delete arr2[k].CreatedNew;
            delete arr2[k].UpdatedNew;
            delete arr2[k].CustomField;
            tempArr.push(arr2[k]);
            popupTicketsBreachedArr.push(arr2[k]);
        }
    }
    return tempArr;
}

function criticalTicketsBreached1(arr3) {
    //kony.print("arr3 length :"+arr3.length);
    //   kony.print("arr:"+JSON.Stringify(arr3));
    tempArr = [];
    for (var k = 0; k < arr3.length; k++) {
        var createdTime = arr3[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr3[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr3[k].CreatedAt = localDate;
        arr3[k].UpdatedAt = updatedNew;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 0.5) {
            arr3[k].hours = hours;
            tempArr.push(arr3[k]);
            firstResponseBreachedArr.push(tempArr);
        }
    }
    return tempArr;
}

function highTicketsToBreach(arr4) {
    // kony.print("arr4 length :"+arr4.length);
    // kony.print("arr:"+arr4);
    tempArr = [];
    tempArr1 = [];
    for (var k = 0; k < arr4.length; k++) {
        var createdTime = arr4[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr4[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        highHours += hours;
        if (hours > 144 && hours <= 168) {
            arr4[k].hours = hours;
            arr4[k].CreatedAt = createdDateTime;
            arr4[k].UpdatedAt = updatedDateTime;
            delete arr4[k].CreatedNew;
            delete arr4[k].UpdatedNew;
            delete arr4[k].CustomField;
            tempArr.push(arr4[k]);
            popupTicketsArr.push(arr4[k]);
        }
        //        if(hours>192)
        //          {
        //            arr4[k].hours=hours;
        //            arr4[k].CreatedAt=createdDateTime;
        //            arr4[k].UpdatedAt=updatedDateTime;
        //            delete arr4[k].CreatedNew;
        //            delete arr4[k].UpdatedNew;
        //            delete arr4[k].CustomField;
        //             tempArr1.push(arr4[k]);
        //            mttrTicketsArr.push(arr4[k]);
        //          }
    }
    return tempArr;
}

function highTicketsBreached(arr5) {
    //kony.print("arr5 length :"+arr5.length);
    // kony.print("arr:"+arr5);
    tempArr = [];
    for (var k = 0; k < arr5.length; k++) {
        var createdTime = arr5[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr5[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 168 && hours > 192) {
            arr5[k].hours = hours;
            arr5[k].CreatedAt = createdDateTime;
            arr5[k].UpdatedAt = updatedDateTime;
            delete arr5[k].CreatedNew;
            delete arr5[k].UpdatedNew;
            delete arr5[k].CustomField;
            mttrTicketsArr.push(arr5[k]);
            tempArr.push(arr5[k]);
            popupTicketsBreachedArr.push(arr5[k]);
        } else if (hours > 168) {
            arr5[k].hours = hours;
            arr5[k].CreatedAt = createdDateTime;
            arr5[k].UpdatedAt = updatedDateTime;
            delete arr5[k].CreatedNew;
            delete arr5[k].UpdatedNew;
            delete arr5[k].CustomField;
            tempArr.push(arr5[k]);
            popupTicketsBreachedArr.push(arr5[k]);
        }
    }
    return tempArr;
}

function highTicketsBreached1(arr6) {
    // kony.print("arr6 length :"+arr6.length);
    //  kony.print("arr:"+arr6);
    tempArr = [];
    for (var k = 0; k < arr6.length; k++) {
        var createdTime = arr6[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr6[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr6[k].CreatedAt = localDate;
        arr6[k].UpdatedAt = updatedNew;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 2) {
            arr6[k].hours = hours;
            tempArr.push(arr6[k]);
            firstResponseBreachedArr.push(tempArr);
        }
    }
    return tempArr;
}

function mediumTicketsToBreach(arr7) {
    // kony.print("arr7 length :"+arr7.length);
    //kony.print("arr:"+arr7);
    tempArr = [];
    tempArr1 = [];
    for (var k = 0; k < arr7.length; k++) {
        var createdTime = arr7[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr7[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        mediumHours += hours;
        if (hours > 432 && hours <= 504) {
            arr7[k].hours = hours;
            arr7[k].CreatedAt = createdDateTime;
            arr7[k].UpdatedAt = updatedDateTime;
            delete arr7[k].CreatedNew;
            delete arr7[k].UpdatedNew;
            delete arr7[k].CustomField;
            tempArr.push(arr7[k]);
            popupTicketsArr.push(arr7[k]);
        }
        //        if(hours>192)
        //          {
        //            arr7[k].hours=hours;
        //            arr7[k].CreatedAt=createdDateTime;
        //            arr7[k].UpdatedAt=updatedDateTime;
        //            delete arr7[k].CreatedNew;
        //            delete arr7[k].UpdatedNew;
        //            delete arr7[k].CustomField;
        //             tempArr1.push(arr7[k]);
        //            mttrTicketsArr.push(arr7[k]);
        //          }
    }
    return tempArr;
}

function mediumTicketsBreached(arr8) {
    // kony.print("low tickets breached:");
    //kony.print(arr8);
    //kony.print("arr8 length :"+arr8.length);
    // kony.print("arr:"+arr8);
    tempArr = [];
    for (var k = 0; k < arr8.length; k++) {
        var createdTime = arr8[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr8[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr8[k].CreatedNew = localDate;
        arr8[k].UpdatedNew = updatedNew;
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 504) {
            arr8[k].hours = hours;
            arr8[k].CreatedAt = createdDateTime;
            arr8[k].UpdatedAt = updatedDateTime;
            delete arr8[k].CreatedNew;
            delete arr8[k].UpdatedNew;
            delete arr8[k].CustomField;
            tempArr.push(arr8[k]);
            mttrTicketsArr.push(arr8[k]);
            popupTicketsBreachedArr.push(arr8[k]);
        }
    }
    return tempArr;
}

function mediumTicketsBreached1(arr9) {
    // kony.print("arr9 length :"+arr9.length);
    //kony.print("arr:"+arr9);
    tempArr = [];
    for (var k = 0; k < arr9.length; k++) {
        var createdTime = arr9[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr9[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr9[k].CreatedAt = localDate;
        arr9[k].UpdatedAt = updatedNew;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 8) {
            arr9[k].hours = hours;
            tempArr.push(arr9[k]);
            firstResponseBreachedArr.push(tempArr);
        }
    }
    return tempArr;
}

function lowTicketsToBreach(arr12) {
    //  kony.print("arr12 length :"+arr12.length);
    // kony.print("arr:"+arr12);
    tempArr = [];
    tempArr1 = [];
    for (var k = 0; k < arr12.length; k++) {
        var createdTime = arr12[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr12[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        lowHours += hours;
        if (hours > 432 && hours <= 504) {
            arr12[k].hours = hours;
            arr12[k].CreatedAt = createdDateTime;
            arr12[k].UpdatedAt = updatedDateTime;
            delete arr12[k].CreatedNew;
            delete arr12[k].UpdatedNew;
            delete arr12[k].CustomField;
            tempArr.push(arr12[k]);
            popupTicketsArr.push(arr12[k]);
        }
        //        if(hours>192)
        //          {
        //            arr12[k].hours=hours;
        //            arr12[k].CreatedAt=createdDateTime;
        //            arr12[k].UpdatedAt=updatedDateTime;
        //            delete arr12[k].CreatedNew;
        //            delete arr12[k].UpdatedNew;
        //            delete arr12[k].CustomField;
        //             tempArr1.push(arr12[k]);
        //            mttrTicketsArr.push(arr12[k]);
        //          }
    }
    return tempArr;
}

function lowTicketsBreached(arr11) {
    //  kony.print("low tickets breached:");
    //kony.print(arr11);
    // kony.print("arr11 length :"+arr11.length);
    // kony.print("arr:"+arr11);
    tempArr = [];
    for (var k = 0; k < arr11.length; k++) {
        var createdTime = arr11[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr11[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr11[k].CreatedNew = localDate;
        arr11[k].UpdatedNew = updatedNew;
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 504) {
            arr11[k].hours = hours;
            arr11[k].CreatedAt = createdDateTime;
            arr11[k].UpdatedAt = updatedDateTime;
            delete arr11[k].CreatedNew;
            delete arr11[k].UpdatedNew;
            delete arr11[k].CustomField;
            tempArr.push(arr11[k]);
            mttrTicketsArr.push(arr11[k]);
            popupTicketsBreachedArr.push(arr11[k]);
        }
    }
    return tempArr;
}

function lowTicketsBreached1(arr10) {
    // kony.print("arr10 length :"+arr10.length);
    //kony.print("arr:"+arr10);
    tempArr = [];
    for (var k = 0; k < arr10.length; k++) {
        var createdTime = arr10[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr10[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr10[k].CreatedAt = localDate;
        arr10[k].UpdatedAt = updatedNew;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 24) {
            arr10[k].hours = hours;
            tempArr.push(arr10[k]);
            firstResponseBreachedArr.push(tempArr);
        }
    }
    return tempArr;
}