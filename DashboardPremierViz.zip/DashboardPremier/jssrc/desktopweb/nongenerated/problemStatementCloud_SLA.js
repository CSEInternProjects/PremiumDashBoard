//Type your code here
//Type your code here
var ticketsForSLACloud;
ticketsForCommentsCloud = [];
ProblemStatementPopupCloud = [];
var valueCloud = 0;
var idCloud;

function fillIndicatorsCloud() {
    //alert("Entered FillIndicatorsCloud");
    temp = [];
    tempSLA = [];
    if (openCloud.ticketsCount !== "0") {
        for (var i = 0; i < openCloud.tickets.length; i++) {
            var createdTime = openCloud.tickets[i].CreatedAt;
            var localDate = new Date(createdTime);
            var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
            var lDateString = localDate.toString();
            var CTime = lDateString.substr(16, 8);
            var createdDateTime = CDate + " " + CTime;
            var date = new Date();
            var hours = Math.abs(date - localDate) / 36e5;
            if (hours > 24) {
                temp.push(openCloud.tickets[i].ticketId);
            }
            customArr = openCloud.tickets[i].CustomField;
            for (var k = 0; k < customArr.length; k++) {
                if (customArr[k].id === 22054000) {
                    if (customArr[k].value !== null) {
                        lastUpdated = customArr[k].value;
                        lastUpdated = lastUpdated.toString();
                    } else {
                        lastUpdated = null;
                    }
                }
            }
            if (lastUpdated !== null) {
                var dateUpdated = lastUpdated.substr(0, 10);
                var time = lastUpdated.substr(11, 8);
                dateUpdated = dateUpdated.replace("/", " ");
                dateUpdated = dateUpdated.replace("/", " ");
                time = time.replace(":", " ");
                time = time.replace(":", " ");
                var dateArr = dateUpdated.split(" ");
                var timeArr = time.split(" ");
                var dd = dateArr[0];
                var mm = parseInt(dateArr[1]) - 1;
                mm = mm.toString();
                var yy = dateArr[2];
                var h = timeArr[0];
                var m = timeArr[1];
                var s = timeArr[2];
                var lastUpdated = new Date(yy, mm, dd, h, m, s);
                var newDate = new Date();
                var hoursSinceUpdate = Math.abs(newDate - lastUpdated) / 36e5;
                if (hoursSinceUpdate > 20) {
                    tempSLA.push(openCloud.tickets[i].ticketId);
                }
            }
        }
        ticketsForSLACloud = tempSLA;
        ticketsForCommentsCloud = temp;
        if (ticketsForCommentsCloud.length !== 0) {
            idCloud = ticketsForCommentsCloud[valueCloud];
            mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
            headers = {};
            data = {
                "ticketId": idCloud
            };
            mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getCloudCommentsSuccessCallback, getCloudCommentsErrorCallback);
        } else {
            frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementCloud.lblPSCloud1.text = 0;
            frmDashboard.flxQualityIndicators.flxProblemStatement.lblProblemStatementCount.text = ProblemStatementPopupCse.length + ProblemStatementPopupProduct.length + ProblemStatementPopupCloud.length;
        }
    } else {
        frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementCloud.lblPSCloud1.text = 0;
        frmDashboard.flxQualityIndicators.flxProblemStatement.lblProblemStatementCount.text = ProblemStatementPopupCse.length + ProblemStatementPopupProduct.length + ProblemStatementPopupCloud.length;
        frmDashboard.flxSLAList.flxSLACloud.lblSLACloud1.text = 0;
        frmDashboard.flxSLA.lblSLACount.text = ticketsForSLACse.length + ticketsForSLAProduct.length + ticketsForSLACloud.length;
    }
}

function invokingToGetCloudComments(value) {
    idCloud = ticketsForCommentsCloud[value];
    mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
    var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
    headers = {};
    data = {
        "ticketId": idCloud
    };
    mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getCloudCommentsSuccessCallback, getCloudCommentsErrorCallback);
}

function getCloudCommentsSuccessCallback(res) {
    if (res.count !== 0) {
        flag = 0;
        for (var k = 0; k < res.comments.length; k++) {
            str = res.comments[k].text;
            if (str.indexOf("#Problem Statement#") >= 0) {
                flag = 1;
            }
        }
        if (flag === 0) {
            ProblemStatementPopupCloud.push(idCloud);
        }
    }
    valueCloud++;
    if (valueCloud < ticketsForCommentsCloud.length) {
        invokingToGetCloudComments(valueCloud);
    } else {
        frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementCloud.lblPSCloud1.text = ProblemStatementPopupCloud.length;
        frmDashboard.flxQualityIndicators.flxProblemStatement.lblProblemStatementCount.text = ProblemStatementPopupCse.length + ProblemStatementPopupProduct.length + ProblemStatementPopupCloud.length;
        frmDashboard.flxSLAList.flxSLACloud.lblSLACloud1.text = ticketsForSLACloud.length;
        frmDashboard.flxSLA.lblSLACount.text = ticketsForSLACse.length + ticketsForSLAProduct.length + ticketsForSLACloud.length;
    }
}

function getCloudCommentsErrorCallback(res) {
    //alert("Error in retreiving comments");
}