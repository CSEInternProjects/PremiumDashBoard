//Type your code here
//Type your code here
var ticketArrayIterator = 0;
var globTicekts;
Count = 0;
var interactionsCount = 0;
var globalDummy = [];
interactionsCSE = [];
interactionsProduct = [];
interactionsCloud = [];

function returnCountOfInteractions(viewNum) {
    if (viewNum === 2) {
        for (var x = 0; x < globalResponsesLeadLag.length; x++) {
            if (globalResponsesLeadLag[x].viewNumber === "114115512134") {
                for (var y = 0; y < globalResponsesLeadLag[x].tickets.length; y++) {
                    if (globalResponsesLeadLag[x].tickets[y].Comment_Count > 15) {
                        interactionsCSE.push(globalResponsesLeadLag[x].tickets[y].ticketId);
                    }
                }
            }
        }
        frmDashboard.flxIndicators.flxLeadIndicator.flxInteractionsList.flxInteractions0.lblInteractions02.text = interactionsCSE.length;
    } else if (viewNum === 3) {
        for (var a = 0; a < globalResponsesLeadLag.length; a++) {
            if (globalResponsesLeadLag[a].viewNumber === " 114115514894") {
                for (var b = 0; b < globalResponsesLeadLag[a].tickets.length; b++) {
                    if (globalResponsesLeadLag[a].tickets[b].Comment_Count > 15) {
                        interactionsProduct.push(globalResponsesLeadLag[a].tickets[b].ticketId);
                    }
                }
            }
        }
        frmDashboard.flxIndicators.flxLeadIndicator.flxInteractionsList.flxInteractions1.lblInteractions12.text = interactionsProduct.length;
    } else if (viewNum === 4) {
        for (var m = 0; m < globalResponsesLeadLag.length; m++) {
            if (globalResponsesLeadLag[m].viewNumber === "114115514994") {
                for (var n = 0; n < globalResponsesLeadLag[m].tickets.length; n++) {
                    if (globalResponsesLeadLag[m].tickets[n].Comment_Count > 15) {
                        interactionsCloud.push(globalResponsesLeadLag[m].tickets[n].ticketId);
                    }
                }
            }
        }
        frmDashboard.flxIndicators.flxLeadIndicator.flxInteractionsList.flxInteractions2.lblInteractions22.text = interactionsCloud.length;
        frmDashboard.flxLeadIndicator.flxInteractions.lblInteractionsCount.text = interactionsCSE.length + interactionsProduct.length + interactionsCloud.length;
    }
    viewNumLead++;
    if (viewNumLead < viewArrLeadIndicator.length) {
        //alert("Invoked "+viewNumLead);
        getLeadIndicatorResponse(viewArrLeadIndicator[viewNumLead]);
    }
}
// 		if(ticketArrayIterator<globTickets.length)
//         	{
//           var id=a[ticketArrayIterator];
//       headers={};
//       data={"ticketId":id};
//        mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getRepliesSuccessCallback, getRepliesErrorCallback);
//             }
//   else
//     {
//            switch(viewNumLead)
//       {
//           case 2:
//                    interactionsCSE=globalDummy;
//                  interactionsCount+=Count;
//                  frmDashboard.flxIndicators.flxLeadIndicator.flxInteractionsList.flxInteractions0.lblInteractions02.text=Count;
//                 globalDummy=[];
//                  Count=0;
//           ticketArrayIterator=0;
//       			break;
//           case 3:
//   				 interactionsProduct=globalDummy;
//          			 interactionsCount+=Count;
//                  frmDashboard.flxIndicators.flxLeadIndicator.flxInteractionsList.flxInteractions1.lblInteractions12.text=Count;
//                   globalDummy=[];
//       					Count=0;
//          			 ticketArrayIterator=0;
//                break;
//           case 4:
//                  interactionsCloud=globalDummy;
//          			 interactionsCount+=Count;
//                  frmDashboard.flxIndicators.flxLeadIndicator.flxInteractionsList.flxInteractions2.lblInteractions22.text=Count;
//                   globalDummy=[];
//       			Count=0;
//          		 ticketArrayIterator=0;
//                   frmDashboard.flxLeadIndicator.flxInteractions.lblInteractionsCount.text=interactionsCount;
//                      interactionsCount=0;
//                break;
//      		 }
//           viewNumLead++;
//  			 if(viewNumLead < viewArrLeadIndicator.length)
//   			  {
//                      //alert("Invoked "+viewNumLead);
//   					    getLeadIndicatorResponse(viewArrLeadIndicator[viewNumLead]);
//   				  }
//     }
// }
// function getRepliesSuccessCallback(res)
// {
//   rCount=parseInt(res.list[0].RepliesCount);
//   if(rCount > 15)
//     {
//       kony.print("Tickets with interaction >15"+globTickets[ticketArrayIterator]);
//       globalDummy.push(res.list[0].ticketId);
//       Count++;
//     }
//   ticketArrayIterator++;
//   if(ticketArrayIterator<=globTickets.length)
//         {
//           kony.print("&&&&&&&&&&&&&&&Count&&&&&&&&&"+Count+" "+viewNumLead);
//         returnCountOfReplies(globTickets);
//         }
// }
// function getRepliesErrorCallback(res)
// {
//  //alert("Error in reading interactions") ;
//   frmDashboard.flxIndicators.opacity=1;
// }