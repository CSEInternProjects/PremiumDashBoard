//Type your code here
//Type your code here
severityJustificationCommentsCse = [];
severityJustificationPopupCse = [];
customerDiscussionPopupCse = [];
var valueSJCse = 0;
var idSJCse;

function severityJustificationCse() {
    temp = [];
    if (openCse.ticketsCount !== "0") {
        for (var i = 0; i < openCse.tickets.length; i++) {
            custName = "";
            psAssign = "";
            severity = "";
            customArr = openCse.tickets[i].CustomField;
            for (var k = 0; k < customArr.length; k++) {
                if (customArr[k].id === 22846480) {
                    if (customArr[k].value !== null) {
                        temp.push(openCse.tickets[i].ticketId);
                    }
                } else if (customArr[k].id === 77167) {
                    severity = customArr[k].value;
                } else if (customArr[k].id === 21277110) {
                    custName = customArr[k].value;
                } else if (customArr[k].id === 21145230) {
                    psAssign = customArr[k].value;
                }
            }
            severity = severity.toLowerCase();
            severity = severity.trim();
            if (custName !== null) CustomerName = custName.trim();
            else CustomerName = "none";
            PSAssignee = psAssign.trim();
            openCse.tickets[i].CName = CustomerName;
            openCse.tickets[i].severityOfTicket = severity;
            PSAssignee = PSAssignee.trim();
            PSAssignee = PSAssignee.replace("_", " ");
            PSAssignee = PSAssignee.replace("-", " ");
            var arr = PSAssignee.split(' ');
            var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
            if (arr.length > 1) {
                var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
                if (second !== "Tickets") {
                    PSAssignee = first + " " + second;
                } else {
                    PSAssignee = first;
                }
            } else {
                PSAssignee = first;
            }
            if (PSAssignee === "") {
                PSAssignee = "None";
            }
            openCse.tickets[i].PSAssignee = PSAssignee;
        }
        severityJustificationCommentsCse = temp;
        if (severityJustificationCommentsCse.length !== 0) {
            idSJCse = severityJustificationCommentsCse[valueSJCse];
            mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
            headers = {};
            data = {
                "ticketId": idSJCse
            };
            mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getSJCseCommentsSuccessCallback, getSJCseCommentsErrorCallback);
        } else {
            frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJCse.lblSJCse1.text = 0;
            frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDCse.lblCDCse1.text = 0;
        }
    } else {
        frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJCse.lblSJCse1.text = 0;
        frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDCse.lblCDCse1.text = 0;
    }
}

function invokingToGetSJCseComments(value) {
    idSJCse = severityJustificationCommentsCse[value];
    mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
    var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
    headers = {};
    data = {
        "ticketId": idSJCse
    };
    mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getSJCseCommentsSuccessCallback, getSJCseCommentsErrorCallback);
}

function getSJCseCommentsSuccessCallback(res) {
    if (res.count !== 0) {
        flag = 0;
        test = 0;
        for (var k = 0; k < res.comments.length; k++) {
            str = res.comments[k].text;
            if (str.indexOf("#Severity Justification#") >= 0) {
                flag = 1;
            }
            if (str.indexOf("#Customer Discussion#") >= 0) {
                test = 1;
            }
        }
        if (flag === 0) {
            severityJustificationPopupCse.push(idSJCse);
        }
        if (test === 0) {
            customerDiscussionPopupCse.push(idSJCse);
        }
    }
    valueSJCse++;
    if (valueSJCse < severityJustificationCommentsCse.length) {
        invokingToGetSJCseComments(valueSJCse);
    } else {
        frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJCse.lblSJCse1.text = severityJustificationPopupCse.length;
        frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDCse.lblCDCse1.text = customerDiscussionPopupCse.length;
    }
}

function getSJCseCommentsErrorCallback(res) {
    // alert("Error in retreiving comments");
}