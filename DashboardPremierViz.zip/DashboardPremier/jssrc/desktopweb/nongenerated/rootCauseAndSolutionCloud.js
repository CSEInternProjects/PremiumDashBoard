//Type your code here
//Type your code here
rootCauseTicketsCloud = [];
rootCausePopupCloud = [];
solutionPopupCloud = [];
var valueRootCauseCloud = 0;
var idRootCauseCloud;

function rootCauseCloud() {
    // alert("RootcauseCLoud");
    temp = [];
    if (monthTicketsSolvedCloud.length > 0) {
        for (var i = 0; i < monthTicketsSolvedCloud.length; i++) {
            custName = "";
            psAssign = "";
            severity = "";
            temp.push(monthTicketsSolvedCloud[i].ticketId);
            customArr = monthTicketsSolvedCloud[i].CustomField;
            for (var k = 0; k < customArr.length; k++) {
                //         if(customArr[k].id===22846480)
                //           {
                //             if(customArr[k].value!==null)
                //               {
                //                 temp.push(monthTicketsSolvedCloud[i].ticketId);
                //               }
                //           }
                if (customArr[k].id === 77167) {
                    severity = customArr[k].value;
                } else if (customArr[k].id === 21277110) {
                    custName = customArr[k].value;
                } else if (customArr[k].id === 21145230) {
                    psAssign = customArr[k].value;
                }
            }
            severity = severity.toLowerCase();
            severity = severity.trim();
            if (custName !== null) CustomerName = custName.trim();
            else CustomerName = "none";
            PSAssignee = psAssign.trim();
            monthTicketsSolvedCloud[i].CName = CustomerName;
            monthTicketsSolvedCloud[i].severityOfTicket = severity;
            PSAssignee = PSAssignee.trim();
            PSAssignee = PSAssignee.replace("_", " ");
            PSAssignee = PSAssignee.replace("-", " ");
            var arr = PSAssignee.split(' ');
            var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
            if (arr.length > 1) {
                var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
                if (second !== "Tickets") {
                    PSAssignee = first + " " + second;
                } else {
                    PSAssignee = first;
                }
            } else {
                PSAssignee = first;
            }
            if (PSAssignee === "") {
                PSAssignee = "None";
            }
            monthTicketsSolvedCloud[i].PSAssignee = PSAssignee;
        }
        rootCauseTicketsCloud = temp;
        if (rootCauseTicketsCloud.length !== 0) {
            idRootCauseCloud = rootCauseTicketsCloud[valueRootCauseCloud];
            mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
            headers = {};
            data = {
                "ticketId": idRootCauseCloud
            };
            mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getCloudRootCauseCommentsSuccessCallback, getCloudRootCauseCommentsErrorCallback);
        } else {
            frmDashboard.flxQualityIndicators.flxRootCauseList.flxRCCloud.lblRCCloud1.text = 0;
            frmDashboard.flxQualityIndicators.flxSolutionList.flxSolCloud.lblSolCloud1.text = 0;
            frmDashboard.flxQualityIndicators.flxRootCause.lblRootCauseCount.text = rootCausePopupCse.length + rootCausePopupProduct.length + rootCausePopupCloud.length;
            frmDashboard.flxQualityIndicators.flxSolution.lblSolutionCount.text = solutionPopupCse.length + solutionPopupProduct.length + solutionPopupCloud.length;
            frmDashboard.flxIndicators.opacity = 1;
            kony.application.dismissLoadingScreen();
        }
    } else {
        frmDashboard.flxQualityIndicators.flxRootCauseList.flxRCCloud.lblRCCloud1.text = 0;
        frmDashboard.flxQualityIndicators.flxSolutionList.flxSolCloud.lblSolCloud1.text = 0;
        frmDashboard.flxQualityIndicators.flxRootCause.lblRootCauseCount.text = rootCausePopupCse.length + rootCausePopupProduct.length + rootCausePopupCloud.length;
        frmDashboard.flxQualityIndicators.flxSolution.lblSolutionCount.text = solutionPopupCse.length + solutionPopupProduct.length + solutionPopupCloud.length;
        frmDashboard.flxIndicators.opacity = 1;
        kony.application.dismissLoadingScreen();
    }
}

function invokingToGetRootCauseCloudComments(value) {
    idRootCauseCloud = rootCauseTicketsCloud[value];
    mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
    var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
    headers = {};
    data = {
        "ticketId": idRootCauseCloud
    };
    mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getCloudRootCauseCommentsSuccessCallback, getCloudRootCauseCommentsErrorCallback);
}

function getCloudRootCauseCommentsSuccessCallback(res) {
    if (res.count !== 0) {
        flag = 0;
        test = 0;
        for (var k = 0; k < res.comments.length; k++) {
            str = res.comments[k].text;
            if (str.indexOf("#Root Cause#") >= 0) {
                flag = 1;
            }
            if (str.indexOf("#Solution#") >= 0) {
                test = 1;
            }
        }
        if (flag === 0) {
            rootCausePopupCloud.push(idRootCauseCloud);
        }
        if (test === 0) {
            solutionPopupCloud.push(idRootCauseCloud);
        }
    }
    valueRootCauseCloud++;
    if (valueRootCauseCloud < rootCauseTicketsCloud.length) {
        invokingToGetRootCauseCloudComments(valueRootCauseCloud);
    } else {
        frmDashboard.flxQualityIndicators.flxRootCauseList.flxRCCloud.lblRCCloud1.text = rootCausePopupCloud.length;
        frmDashboard.flxQualityIndicators.flxSolutionList.flxSolCloud.lblSolCloud1.text = solutionPopupCloud.length;
        frmDashboard.flxQualityIndicators.flxRootCause.lblRootCauseCount.text = rootCausePopupCse.length + rootCausePopupProduct.length + rootCausePopupCloud.length;
        frmDashboard.flxQualityIndicators.flxSolution.lblSolutionCount.text = solutionPopupCse.length + solutionPopupProduct.length + solutionPopupCloud.length;
        frmDashboard.flxIndicators.opacity = 1;
        kony.application.dismissLoadingScreen();
    }
}

function getCloudRootCauseCommentsErrorCallback(res) {
    // alert("Error in retreiving comments");
}
//Type your code here