//Type your code here
//Type your code here
severityJustificationCommentsProduct = [];
severityJustificationPopupProduct = [];
customerDiscussionPopupProduct = [];
var valueSJProduct = 0;
var idSJProduct;

function severityJustificationProduct() {
    temp = [];
    if (openProduct.ticketsCount !== "0") {
        for (var i = 0; i < openProduct.tickets.length; i++) {
            custName = "";
            psAssign = "";
            severity = "";
            customArr = openProduct.tickets[i].CustomField;
            for (var k = 0; k < customArr.length; k++) {
                if (customArr[k].id === 22846480) {
                    if (customArr[k].value !== null) {
                        temp.push(openProduct.tickets[i].ticketId);
                    }
                } else if (customArr[k].id === 77167) {
                    severity = customArr[k].value;
                } else if (customArr[k].id === 21277110) {
                    custName = customArr[k].value;
                } else if (customArr[k].id === 21145230) {
                    psAssign = customArr[k].value;
                }
            }
            severity = severity.toLowerCase();
            severity = severity.trim();
            if (custName !== null) CustomerName = custName.trim();
            else CustomerName = "none";
            PSAssignee = psAssign.trim();
            openProduct.tickets[i].CName = CustomerName;
            openProduct.tickets[i].severityOfTicket = severity;
            PSAssignee = PSAssignee.trim();
            PSAssignee = PSAssignee.replace("_", " ");
            PSAssignee = PSAssignee.replace("-", " ");
            var arr = PSAssignee.split(' ');
            var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
            if (arr.length > 1) {
                var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
                if (second !== "Tickets") {
                    PSAssignee = first + " " + second;
                } else {
                    PSAssignee = first;
                }
            } else {
                PSAssignee = first;
            }
            if (PSAssignee === "") {
                PSAssignee = "None";
            }
            openProduct.tickets[i].PSAssignee = PSAssignee;
        }
        severityJustificationCommentsProduct = temp;
        if (severityJustificationCommentsProduct.length !== 0) {
            idSJProduct = severityJustificationCommentsProduct[valueSJProduct];
            mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
            headers = {};
            data = {
                "ticketId": idSJProduct
            };
            mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getSJProductCommentsSuccessCallback, getSJProductCommentsErrorCallback);
        } else {
            frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJProduct.lblSJProduct1.text = 0;
            frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDProduct.lblCDProduct1.text = 0;
        }
    } else {
        frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJProduct.lblSJProduct1.text = 0;
        frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDProduct.lblCDProduct1.text = 0;
    }
}

function invokingToGetSJProductComments(value) {
    idSJProduct = severityJustificationCommentsProduct[value];
    mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
    var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
    headers = {};
    data = {
        "ticketId": idSJProduct
    };
    mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getSJProductCommentsSuccessCallback, getSJProductCommentsErrorCallback);
}

function getSJProductCommentsSuccessCallback(res) {
    if (res.count !== 0) {
        flag = 0;
        test = 0;
        //           for(var z=0;z<res.comments.length;z++)
        //            {
        //             str=res.comments[z].text;
        //            if(str.indexOf("#Severity Justification#") >=0) 
        //              {
        //                flag=1;
        //                break;
        //              }
        //            }
        //           if(flag!==1)
        //             {
        // //                  if(res.nextPage===null)
        // //                    {
        //     			     if(flag===0)
        //       		 		   {
        //           			    severityJustificationPopupProduct.push(idSJProduct);
        //      				   }
        //                  //  }
        //                   else
        //                     {
        //                     }
        //             }
        for (var k = 0; k < res.comments.length; k++) {
            str = res.comments[k].text;
            if (str.indexOf("#Severity Justification#") >= 0) {
                flag = 1;
            }
            if (str.indexOf("#Customer Discussion#") >= 0) {
                test = 1;
            }
        }
        if (flag === 0) {
            severityJustificationPopupProduct.push(idSJProduct);
        }
        if (test === 0) {
            customerDiscussionPopupProduct.push(idSJProduct);
        }
    }
    valueSJProduct++;
    if (valueSJProduct < severityJustificationCommentsProduct.length) {
        invokingToGetSJProductComments(valueSJProduct);
    } else {
        frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJProduct.lblSJProduct1.text = severityJustificationPopupProduct.length;
        frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDProduct.lblCDProduct1.text = customerDiscussionPopupProduct.length;
    }
}

function getSJProductCommentsErrorCallback(res) {
    //  alert("Error in retreiving comments");
}