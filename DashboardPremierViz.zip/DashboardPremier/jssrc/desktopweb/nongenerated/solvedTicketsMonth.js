//Type your code here
solvedMonthView = ["114133917254"];
solvedCseMonth = [];
solvedProductMonth = [];
solvedCloudMonth = [];
monthTicketsSolvedCse = [];
monthTicketsSolvedProduct = [];
monthTicketsSolvedCloud = [];

function solvedTicketsForMonth() {
    mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
    var operationName = mobileFabricConfiguration.integrationServices[0].operations[4];
    headers = {};
    data = {
        "viewId": solvedMonthView[0]
    };
    mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, solvedMonthSuccessCallback, solvedMonthErrorCallback);
}

function solvedMonthSuccessCallback(res) {
    if (res.ticketsCount !== "0") {
        for (var m = 0; m < res.tickets.length; m++) {
            var id = res.tickets[m].AssigneeId;
            if (id === 14255408 || id === 14272801548) {
                solvedCseMonth.push(res.tickets[m]);
            } else if (id === 235456932) {
                solvedProductMonth.push(res.tickets[m]);
            } else if (id === 256357194) {
                solvedCloudMonth.push(res.tickets[m]);
            }
        }
        if (m === res.tickets.length) {
            getSolvedTicketsForMonth();
        }
    }
}

function solvedMonthErrorCallback() {
    alert("Error in retreiving Solved tickets for month");
}

function getSolvedTicketsForMonth() {
    for (var i = 0; i < solvedCseMonth.length; i++) {
        var date = new Date();
        var solvedDate = solvedCseMonth[i].MetricSet[0].SolvedAt;
        var solvedFormat = new Date(solvedDate);
        currentRunningMonth = date.getMonth() + 1;
        solvedMonth = solvedFormat.getMonth() + 1;
        if (currentRunningMonth === solvedMonth) {
            var createdAt = solvedCseMonth[i].CreatedAt;
            var createdNew = new Date(createdAt);
            var hours = Math.abs(solvedFormat - createdNew) / 36e5;
            solvedCseMonth[i].hoursSpent = hours;
            monthTicketsSolvedCse.push(solvedCseMonth[i]);
        }
    }
    for (var j = 0; j < solvedProductMonth.length; j++) {
        var dateProd = new Date();
        var solvedDateProd = solvedProductMonth[j].MetricSet[0].SolvedAt;
        var solvedFormatProd = new Date(solvedDateProd);
        currentRunningMonth = dateProd.getMonth() + 1;
        solvedMonth = solvedFormatProd.getMonth() + 1;
        if (currentRunningMonth === solvedMonth) {
            var createdAtProd = solvedProductMonth[j].CreatedAt;
            var createdNewProd = new Date(createdAtProd);
            var hoursProd = Math.abs(solvedFormatProd - createdNewProd) / 36e5;
            solvedProductMonth[j].hoursSpent = hoursProd;
            monthTicketsSolvedProduct.push(solvedProductMonth[j]);
        }
    }
    for (var k = 0; k < solvedCloudMonth.length; k++) {
        var dateCloud = new Date();
        var solvedDateCloud = solvedCloudMonth[k].MetricSet[0].SolvedAt;
        var solvedFormatCloud = new Date(solvedDateCloud);
        currentRunningMonth = dateCloud.getMonth() + 1;
        solvedMonth = solvedFormatCloud.getMonth() + 1;
        if (currentRunningMonth === solvedMonth) {
            var createdAtCloud = solvedCloudMonth[k].CreatedAt;
            var createdNewCloud = new Date(createdAtCloud);
            var hoursCloud = Math.abs(solvedFormatCloud - createdNewCloud) / 36e5;
            solvedCloudMonth[k].hoursSpent = hoursCloud;
            monthTicketsSolvedCloud.push(solvedCloudMonth[k]);
        }
    }
    if (k === solvedCloudMonth.length) {
        rootCauseCse();
        rootCauseProduct();
    }
}