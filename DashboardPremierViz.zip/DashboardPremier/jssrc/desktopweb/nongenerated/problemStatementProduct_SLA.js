//Type your code here
//Type your code here
var ticketsForSLAProduct;
ticketsForCommentsProduct = [];
ProblemStatementPopupProduct = [];
var valueProduct = 0;
var idProduct;

function fillIndicatorsProduct() {
    temp = [];
    tempSLA = [];
    if (openProduct.ticketsCount !== "0") {
        for (var i = 0; i < openProduct.tickets.length; i++) {
            var createdTime = openProduct.tickets[i].CreatedAt;
            var localDate = new Date(createdTime);
            var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
            var lDateString = localDate.toString();
            var CTime = lDateString.substr(16, 8);
            var createdDateTime = CDate + " " + CTime;
            var date = new Date();
            var hours = Math.abs(date - localDate) / 36e5;
            if (hours > 24) {
                temp.push(openProduct.tickets[i].ticketId);
            }
            customArr = openProduct.tickets[i].CustomField;
            for (var k = 0; k < customArr.length; k++) {
                if (customArr[k].id === 22054000) {
                    if (customArr[k].value !== null) {
                        lastUpdated = customArr[k].value;
                        lastUpdated = lastUpdated.toString();
                    } else {
                        lastUpdated = null;
                    }
                }
            }
            if (lastUpdated !== null) {
                var dateUpdated = lastUpdated.substr(0, 10);
                var time = lastUpdated.substr(11, 8);
                dateUpdated = dateUpdated.replace("/", " ");
                dateUpdated = dateUpdated.replace("/", " ");
                time = time.replace(":", " ");
                time = time.replace(":", " ");
                var dateArr = dateUpdated.split(" ");
                var timeArr = time.split(" ");
                var dd = dateArr[0];
                var mm = parseInt(dateArr[1]) - 1;
                mm = mm.toString();
                var yy = dateArr[2];
                var h = timeArr[0];
                var m = timeArr[1];
                var s = timeArr[2];
                var lastUpdated = new Date(yy, mm, dd, h, m, s);
                var newDate = new Date();
                var hoursSinceUpdate = Math.abs(newDate - lastUpdated) / 36e5;
                if (hoursSinceUpdate > 20) {
                    tempSLA.push(openProduct.tickets[i].ticketId);
                }
            }
        }
        ticketsForSLAProduct = tempSLA;
        ticketsForCommentsProduct = temp;
        if (ticketsForCommentsProduct.length !== 0) {
            idProduct = ticketsForCommentsProduct[valueProduct];
            mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
            headers = {};
            data = {
                "ticketId": idProduct
            };
            mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getProductCommentsSuccessCallback, getProductCommentsErrorCallback);
        } else {
            frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementProduct.lblPSProduct1.text = 0;
        }
    } else {
        frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementProduct.lblPSProduct1.text = 0;
        frmDashboard.flxLeadIndicator.flxSLAList.flxSLAProduct.lblSLAProduct1.text = 0;
    }
}

function invokingToGetProductComments(value) {
    idProduct = ticketsForCommentsProduct[value];
    mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
    var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
    headers = {};
    data = {
        "ticketId": idProduct
    };
    mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getProductCommentsSuccessCallback, getProductCommentsErrorCallback);
}

function getProductCommentsSuccessCallback(res) {
    if (res.count !== 0) {
        flag = 0;
        for (var k = 0; k < res.comments.length; k++) {
            str = res.comments[k].text;
            if (str.indexOf("#Problem Statement#") >= 0) {
                flag = 1;
            }
        }
        if (flag === 0) {
            ProblemStatementPopupProduct.push(idProduct);
        }
    }
    valueProduct++;
    if (valueProduct < ticketsForCommentsProduct.length) {
        invokingToGetProductComments(valueProduct);
    } else {
        frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementProduct.lblPSProduct1.text = ProblemStatementPopupProduct.length;
        frmDashboard.flxLeadIndicator.flxSLAList.flxSLAProduct.lblSLAProduct1.text = ticketsForSLAProduct.length;
    }
}

function getProductCommentsErrorCallback(res) {
    //alert("Error in retreiving comments");
}