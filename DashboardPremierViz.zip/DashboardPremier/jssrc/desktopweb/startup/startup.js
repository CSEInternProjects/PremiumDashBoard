//startup.js file
var appConfig = {
    appId: "DashboardPremier",
    appName: "DashboardPremier",
    appVersion: "2.1.2",
    platformVersion: null,
    serverIp: "10.10.34.98",
    serverPort: "80",
    secureServerPort: "443",
    isturlbase: "https://productsupport.konylabs.net/services",
    isMFApp: true,
    appKey: "13f4e65125c64d418210ea66635e3352",
    appSecret: "2d07b5021ec6e5079cdb8c8685ba95de",
    serviceUrl: "https://productsupport.konylabs.net/authService/100000002/appconfig",
    svcDoc: {
        "appId": "6cfb8c9d-b8a1-47b5-8140-7628d7d04866",
        "baseId": "491cf53e-2c95-4c83-8c03-8294c2f8eb19",
        "name": "DashboardPremier",
        "selflink": "https://productsupport.konylabs.net/authService/100000002/appconfig",
        "integsvc": {
            "GraphsData": "https://productsupport.konylabs.net/services/GraphsData",
            "zendeskConnect": "https://productsupport.konylabs.net/services/zendeskConnect"
        },
        "reportingsvc": {
            "custom": "https://productsupport.konylabs.net/services/CMS",
            "session": "https://productsupport.konylabs.net/services/IST"
        },
        "services_meta": {
            "GraphsData": {
                "version": "1.0",
                "url": "https://productsupport.konylabs.net/services/GraphsData",
                "type": "integsvc"
            },
            "zendeskConnect": {
                "version": "1.0",
                "url": "https://productsupport.konylabs.net/services/zendeskConnect",
                "type": "integsvc"
            }
        }
    },
    eventTypes: ["FormEntry", "Error", "Crash"],
    url: "https://productsupport.konylabs.net/admin/DashboardPremier/MWServlet",
    secureurl: "https://productsupport.konylabs.net/admin/DashboardPremier/MWServlet",
    middlewareContext: "DashboardPremier"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    initializeUserWidgets();
    initializesecHeadTempLag();
    initializesecHeadTempLead();
    initializesegRowTemp();
    initializeTemp0gc1438a9d1874e();
    frmDashboardGlobals();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        APILevel: 7300
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    requirejs.config({
        baseUrl: "desktopweb/appjs"
    });
    var requireModulesList = getSPARequireModulesList();
    require(requireModulesList, function() {
        kony.application.setApplicationInitializationEvents({
            init: appInit,
            showstartupform: function() {
                frmDashboard.show();
            }
        });
    });
};

function loadResources() {
    kony.theme.packagedthemes(
        ["default"]);
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "serviceUrl": appConfig.serviceUrl,
        eventTypes: ["FormEntry", "Error", "Crash"]
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    spaAPM && spaAPM.startTracking();
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}

function initializeApp() {
    kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
    //If default locale is specified. This is set even before any other app life cycle event is called.
    loadResources();
};
									function getSPARequireModulesList(){ return ['kvmodules']; }
								