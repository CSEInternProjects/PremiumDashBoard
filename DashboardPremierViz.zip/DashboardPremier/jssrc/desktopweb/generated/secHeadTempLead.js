function initializesecHeadTempLead() {
    flxHeadTempLead = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "30px",
        "id": "flxHeadTempLead",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "skin": "flxSkinGreen"
    }, {}, {});
    flxHeadTempLead.setDefaultUnit(kony.flex.DP);
    var slblTicket = new kony.ui.Label({
        "id": "slblTicket",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslLabel0i407adb86ea649",
        "text": "TIcket ",
        "top": "30%",
        "width": "9%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var slblSeverity = new kony.ui.Label({
        "id": "slblSeverity",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0e89d841c5da04d",
        "text": "Severity",
        "top": "30%",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var slblCustName = new kony.ui.Label({
        "id": "slblCustName",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0c0706135a0ce4d",
        "text": "Customer",
        "top": "30%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var slblCreated = new kony.ui.Label({
        "id": "slblCreated",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0i7b0a8ba95644e",
        "text": "Created Date",
        "top": "30%",
        "width": "15%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var slblPsAssignee = new kony.ui.Label({
        "id": "slblPsAssignee",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0f000a30ae34048",
        "text": "PS Assignee",
        "top": "30%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxHeadTempLead.add(slblTicket, slblSeverity, slblCustName, slblCreated, slblPsAssignee);
}