function addWidgetsfrmDashboard() {
    frmDashboard.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0cd1d7c6b88fb47",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.PERCENTAGE);
    var lblAppName = new kony.ui.Label({
        "id": "lblAppName",
        "isVisible": true,
        "left": "20px",
        "skin": "CopyslLabel0f741efe4131049",
        "text": "Premier Support Dashboard",
        "top": "10px",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 1, 0],
        "paddingInPixel": false
    }, {});
    var imgFlxKony = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "47px",
        "id": "imgFlxKony",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "right": "15px",
        "skin": "CopyslFbox0ebdbbfd85cfa41",
        "top": "7px",
        "width": "100px",
        "zIndex": 1
    }, {}, {});
    imgFlxKony.setDefaultUnit(kony.flex.DP);
    imgFlxKony.add();
    flxHeader.add(lblAppName, imgFlxKony);
    var flxIndicators = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "67%",
        "id": "flxIndicators",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "skin": "CopyslFbox0d3195fd5e2e448",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxIndicators.setDefaultUnit(kony.flex.PERCENTAGE);
    var flxTicketStatus = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxTicketStatus",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "skin": "skinLeadIndicator",
        "top": "0%",
        "width": "24%",
        "zIndex": 1
    }, {}, {});
    flxTicketStatus.setDefaultUnit(kony.flex.DP);
    var flxLabelTS = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "flxLabelTS",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "20%",
        "skin": "CopyslFbox0h94666d706094c",
        "top": "4%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxLabelTS.setDefaultUnit(kony.flex.DP);
    var lblTicketStatus = new kony.ui.Label({
        "height": "100%",
        "id": "lblTicketStatus",
        "isVisible": true,
        "left": "0%",
        "skin": "lblLeadIndicatorsskin",
        "text": "TICKET STATUS",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    flxLabelTS.add(lblTicketStatus);
    var flxOpen = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxOpen",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "20%",
        "onClick": AS_FlexContainer_e3577b8ae1934d66954247b2efef75dc,
        "skin": "flxSkinBlue",
        "top": "4%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxOpen.setDefaultUnit(kony.flex.DP);
    var lblOpen = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblOpen",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "Open",
        "width": "35%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblOpenCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblOpenCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "14%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDown = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDown",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxOpen.add(lblOpen, lblOpenCount, imgDropDown);
    var flxOpenList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxOpenList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "20%",
        "skin": "CopyslFbox0de409c0fb3364a",
        "top": "0%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxOpenList.setDefaultUnit(kony.flex.DP);
    var flxO1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxO1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_h3374a95e1fd431cbe43da7a032976e3,
        "skin": "CopyslFbox0ebe25e6bc55243",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxO1.setDefaultUnit(kony.flex.DP);
    var lblO11 = new kony.ui.Label({
        "id": "lblO11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblO12 = new kony.ui.Label({
        "height": "83%",
        "id": "lblO12",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxO1.add(lblO11, lblO12);
    var flxO2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0ef10cc6a2dad4d",
        "height": "33%",
        "id": "flxO2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_jb0362e00dea42c1a30a73e75120a07e,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "0.50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxO2.setDefaultUnit(kony.flex.DP);
    var lblO21 = new kony.ui.Label({
        "id": "lblO21",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblO22 = new kony.ui.Label({
        "height": "83%",
        "id": "lblO22",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxO2.add(lblO21, lblO22);
    var flxO3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0ece21307c80644",
        "height": "33%",
        "id": "flxO3",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_ca08736ecad54dc28eb54d2bdf7f59e6,
        "skin": "CopyslFbox0e4dcf811c8f645",
        "top": "0.60%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxO3.setDefaultUnit(kony.flex.DP);
    var lblO31 = new kony.ui.Label({
        "id": "lblO31",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblO32 = new kony.ui.Label({
        "height": "83%",
        "id": "lblO32",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxO3.add(lblO31, lblO32);
    flxOpenList.add(flxO1, flxO2, flxO3);
    var flxPending = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxPending",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "20%",
        "onClick": AS_FlexContainer_f2003b2681654937a13482e35ab69b0f,
        "skin": "flxSkinOrange",
        "top": "2%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxPending.setDefaultUnit(kony.flex.DP);
    var lblPending = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblPending",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "Pending",
        "width": "35%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblPendingCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblPendingCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "14%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDown1 = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDown1",
        "isVisible": true,
        "right": "1%",
        "skin": "CopyslImage0a074bebf11fc4a",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxPending.add(lblPending, lblPendingCount, imgDropDown1);
    var flxPendingList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxPendingList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "20%",
        "skin": "CopyslFbox0c4fe3c95397a4f",
        "top": "0%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxPendingList.setDefaultUnit(kony.flex.DP);
    var flxP1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxP1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_c8d1e7a1573c47079d5b211ea31a635b,
        "skin": "CopyslFbox0ebe25e6bc55243",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxP1.setDefaultUnit(kony.flex.DP);
    var lblP11 = new kony.ui.Label({
        "id": "lblP11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblP12 = new kony.ui.Label({
        "height": "83%",
        "id": "lblP12",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxP1.add(lblP11, lblP12);
    var flxP2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0ef10cc6a2dad4d",
        "height": "33%",
        "id": "flxP2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_a23ddcaf3bca4d9d83a15a0194575519,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "0.50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxP2.setDefaultUnit(kony.flex.DP);
    var lblP21 = new kony.ui.Label({
        "id": "lblP21",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblP22 = new kony.ui.Label({
        "height": "83%",
        "id": "lblP22",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxP2.add(lblP21, lblP22);
    var flxP3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0ece21307c80644",
        "height": "33%",
        "id": "flxP3",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_b7cc417e577543d88e74b13e5246b8ed,
        "skin": "CopyslFbox0e4dcf811c8f645",
        "top": "0.60%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxP3.setDefaultUnit(kony.flex.DP);
    var lblP31 = new kony.ui.Label({
        "id": "lblP31",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblP32 = new kony.ui.Label({
        "height": "83%",
        "id": "lblP32",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxP3.add(lblP31, lblP32);
    flxPendingList.add(flxP1, flxP2, flxP3);
    var flxSolved = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxSolved",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "20%",
        "onClick": AS_FlexContainer_a1ea7a6c777f4d23ad69128fd51a1123,
        "skin": "flxSkinGreen",
        "top": "2%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxSolved.setDefaultUnit(kony.flex.DP);
    var lblSolved = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblSolved",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "Solved",
        "width": "35%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblSolvedCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblSolvedCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "14%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDown2 = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDown2",
        "isVisible": true,
        "right": "1%",
        "skin": "CopyslImage0e352e8e8ff164e",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSolved.add(lblSolved, lblSolvedCount, imgDropDown2);
    var flxSolvedList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxSolvedList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "20%",
        "skin": "flxOPMTTRLIST",
        "top": "0%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxSolvedList.setDefaultUnit(kony.flex.DP);
    var flxS1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxS1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_hebed9fbe08f4221aacd7e3777807d52,
        "skin": "CopyslFbox0ebe25e6bc55243",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxS1.setDefaultUnit(kony.flex.DP);
    var lblS11 = new kony.ui.Label({
        "id": "lblS11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblS12 = new kony.ui.Label({
        "height": "83%",
        "id": "lblS12",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxS1.add(lblS11, lblS12);
    var flxS2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0ef10cc6a2dad4d",
        "height": "33%",
        "id": "flxS2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_abe9aae68f464caebe170902ff948f96,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "0.50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxS2.setDefaultUnit(kony.flex.DP);
    var lblS21 = new kony.ui.Label({
        "id": "lblS21",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblS22 = new kony.ui.Label({
        "height": "83%",
        "id": "lblS22",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxS2.add(lblS21, lblS22);
    var flxS3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0ece21307c80644",
        "height": "33%",
        "id": "flxS3",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_c2465f6cc3004de2a9bf5d481fc7523d,
        "skin": "CopyslFbox0e4dcf811c8f645",
        "top": "0.60%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxS3.setDefaultUnit(kony.flex.DP);
    var lblS31 = new kony.ui.Label({
        "id": "lblS31",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblS32 = new kony.ui.Label({
        "height": "83%",
        "id": "lblS32",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxS3.add(lblS31, lblS32);
    flxSolvedList.add(flxS1, flxS2, flxS3);
    var flxOPMTTR = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxOPMTTR",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "20%",
        "onClick": AS_FlexContainer_fa5e91aec5794e96b2cbf2454ee22b2c,
        "skin": "flxSkinDarkBlue",
        "top": "2%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxOPMTTR.setDefaultUnit(kony.flex.DP);
    var lblOPMTTR = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblOPMTTR",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "MTTR",
        "width": "35%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblOpenPending = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblOpenPending",
        "isVisible": true,
        "left": "26.02%",
        "skin": "CopylblSev0c4510a0218484d",
        "text": "(Open + Pending)",
        "width": "58.96%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblOPMTTRCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblOPMTTRCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "14%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgOPMTTR = new kony.ui.Image2({
        "height": "100%",
        "id": "imgOPMTTR",
        "isVisible": true,
        "right": "1%",
        "skin": "CopyslImage0e352e8e8ff164e",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxOPMTTR.add(lblOPMTTR, lblOpenPending, lblOPMTTRCount, imgOPMTTR);
    var flxOPMTTRList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxOPMTTRList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "20%",
        "skin": "flxOPMTTRLIST",
        "top": "0%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxOPMTTRList.setDefaultUnit(kony.flex.DP);
    var flxCSEMTTR = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxCSEMTTR",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0ebe25e6bc55243",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxCSEMTTR.setDefaultUnit(kony.flex.DP);
    var lblCSEMTTR = new kony.ui.Label({
        "id": "lblCSEMTTR",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CSEMTTR = new kony.ui.Label({
        "height": "83%",
        "id": "CSEMTTR",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lblMttrSkin",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCSEMTTR.add(lblCSEMTTR, CSEMTTR);
    var flxProdMTTR = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0ef10cc6a2dad4d",
        "height": "33%",
        "id": "flxProdMTTR",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "0.50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxProdMTTR.setDefaultUnit(kony.flex.DP);
    var lblProductMTTR = new kony.ui.Label({
        "id": "lblProductMTTR",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var ProductMTTR = new kony.ui.Label({
        "height": "83%",
        "id": "ProductMTTR",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lblMttrSkin",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxProdMTTR.add(lblProductMTTR, ProductMTTR);
    var flxCloudMTTR = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0ece21307c80644",
        "height": "33%",
        "id": "flxCloudMTTR",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0e4dcf811c8f645",
        "top": "0.60%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxCloudMTTR.setDefaultUnit(kony.flex.DP);
    var lblCloudMTTR = new kony.ui.Label({
        "id": "lblCloudMTTR",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CloudMTTR = new kony.ui.Label({
        "height": "83%",
        "id": "CloudMTTR",
        "isVisible": true,
        "left": "74.35%",
        "skin": "lblMttrSkin",
        "text": "...",
        "top": "10%",
        "width": "12%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCloudMTTR.add(lblCloudMTTR, CloudMTTR);
    flxOPMTTRList.add(flxCSEMTTR, flxProdMTTR, flxCloudMTTR);
    flxTicketStatus.add(flxLabelTS, flxOpen, flxOpenList, flxPending, flxPendingList, flxSolved, flxSolvedList, flxOPMTTR, flxOPMTTRList);
    var flxLeadIndicator = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxLeadIndicator",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "skin": "skinLeadIndicator",
        "top": "0%",
        "width": "24%",
        "zIndex": 1
    }, {}, {});
    flxLeadIndicator.setDefaultUnit(kony.flex.DP);
    var flxLabelLeadInd = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "flxLabelLeadInd",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "10%",
        "skin": "CopyslFbox0h94666d706094c",
        "top": "4%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxLabelLeadInd.setDefaultUnit(kony.flex.DP);
    var lblLeadInd = new kony.ui.Label({
        "height": "100%",
        "id": "lblLeadInd",
        "isVisible": true,
        "left": "0%",
        "skin": "lblLeadIndicatorsskin",
        "text": "LEAD INDICATORS",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    flxLabelLeadInd.add(lblLeadInd);
    var flxNoFirstResponse = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxNoFirstResponse",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_bb5b30be40ee4558b25b3b6013d67ada,
        "skin": "flxSkinLightGrey",
        "top": "4%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxNoFirstResponse.setDefaultUnit(kony.flex.DP);
    var lblNoFirstResponse = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblNoFirstResponse",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "No First Response",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblFirstResponseCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblFirstResponseCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownNFR = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownNFR",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxNoFirstResponse.add(lblNoFirstResponse, lblFirstResponseCount, imgDropDownNFR);
    var flxNoFirstResList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxNoFirstResList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "skinForBorder",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxNoFirstResList.setDefaultUnit(kony.flex.DP);
    var flxNR0 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "49%",
        "id": "flxNR0",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_e83391b2da6d453d9765e292463972c3,
        "skin": "CopyslFbox0ebe25e6bc55243",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxNR0.setDefaultUnit(kony.flex.DP);
    var lblNR01 = new kony.ui.Label({
        "id": "lblNR01",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblNR02 = new kony.ui.Label({
        "height": "63%",
        "id": "lblNR02",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxNR0.add(lblNR01, lblNR02);
    var flxNR1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "49%",
        "id": "flxNR1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_f7fbd9dc12f942b8b5139be598241d6e,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "1%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxNR1.setDefaultUnit(kony.flex.DP);
    var lblNR11 = new kony.ui.Label({
        "id": "lblNR11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblNR12 = new kony.ui.Label({
        "height": "63%",
        "id": "lblNR12",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxNR1.add(lblNR11, lblNR12);
    flxNoFirstResList.add(flxNR0, flxNR1);
    var flxResolutionToBreach = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxResolutionToBreach",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_a8eb57fd242844e5b53eb4fea0d6e9da,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxResolutionToBreach.setDefaultUnit(kony.flex.DP);
    var lblResolutionToBreach = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblResolutionToBreach",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "Resolution To Breach",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblRTBCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblRTBCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownRTB = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownRTB",
        "isVisible": true,
        "right": "1%",
        "skin": "CopyslImage0a074bebf11fc4a",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxResolutionToBreach.add(lblResolutionToBreach, lblRTBCount, imgDropDownRTB);
    var flxResToBreachList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxResToBreachList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "skinForBorder",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxResToBreachList.setDefaultUnit(kony.flex.DP);
    var flxRTB0 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxRTB0",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_h021267dd2114033950e9c380310cf2a,
        "skin": "CopyslFbox0e7052db733ab4b",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxRTB0.setDefaultUnit(kony.flex.DP);
    var lblRTB01 = new kony.ui.Label({
        "id": "lblRTB01",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRTB02 = new kony.ui.Label({
        "height": "92%",
        "id": "lblRTB02",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRTB0.add(lblRTB01, lblRTB02);
    var flxRTB1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxRTB1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_j9d0f6ab1a174b03b653d0a120d62e49,
        "skin": "CopyslFbox0e7052db733ab4b",
        "top": "0.50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxRTB1.setDefaultUnit(kony.flex.DP);
    var lblRTB11 = new kony.ui.Label({
        "id": "lblRTB11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRTB12 = new kony.ui.Label({
        "height": "92%",
        "id": "lblRTB12",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRTB1.add(lblRTB11, lblRTB12);
    var flxRTB2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxRTB2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_i39286f6bd5c4471a70a2f49f542ad6a,
        "skin": "CopyslFbox0e7052db733ab4b",
        "top": "0.60%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxRTB2.setDefaultUnit(kony.flex.DP);
    var lblRTB21 = new kony.ui.Label({
        "id": "lblRTB21",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRTB22 = new kony.ui.Label({
        "height": "92%",
        "id": "lblRTB22",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRTB2.add(lblRTB21, lblRTB22);
    flxResToBreachList.add(flxRTB0, flxRTB1, flxRTB2);
    var flxAutoClosure = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxAutoClosure",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_ac8f6b5ca75d43a78bb450e57661dbd8,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxAutoClosure.setDefaultUnit(kony.flex.DP);
    var lblAutoClosure = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblAutoClosure",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "To Be AutoSolved(24 hrs)",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblAutoSolvedCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblAutoSolvedCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownAutoSolved = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownAutoSolved",
        "isVisible": true,
        "right": "1%",
        "skin": "CopyslImage0e352e8e8ff164e",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxAutoClosure.add(lblAutoClosure, lblAutoSolvedCount, imgDropDownAutoSolved);
    var flxAutoClosureList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxAutoClosureList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "skinForBorder",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxAutoClosureList.setDefaultUnit(kony.flex.DP);
    var flxAC0 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "49%",
        "id": "flxAC0",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_i9e8e05f555f4e548465a290d3be8b18,
        "skin": "CopyslFbox0accb1a0f660447",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxAC0.setDefaultUnit(kony.flex.DP);
    var lblAC01 = new kony.ui.Label({
        "id": "lblAC01",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblAC02 = new kony.ui.Label({
        "height": "63%",
        "id": "lblAC02",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxAC0.add(lblAC01, lblAC02);
    var flxAC1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "49%",
        "id": "flxAC1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_fb4039925c5345cdaae7436ca671b062,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "0.80%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxAC1.setDefaultUnit(kony.flex.DP);
    var lblAC11 = new kony.ui.Label({
        "id": "lblAC11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblAC12 = new kony.ui.Label({
        "height": "63%",
        "id": "lblAC12",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxAC1.add(lblAC11, lblAC12);
    flxAutoClosureList.add(flxAC0, flxAC1);
    var flxInteractions = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxInteractions",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_c542abe6139a4b2982ce8152b87f0615,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxInteractions.setDefaultUnit(kony.flex.DP);
    var lblinteractions = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblinteractions",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "Interactions ( >15 )",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblInteractionsCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblInteractionsCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownInteractions = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownInteractions",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxInteractions.add(lblinteractions, lblInteractionsCount, imgDropDownInteractions);
    var flxInteractionsList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxInteractionsList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "skinForBorder",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxInteractionsList.setDefaultUnit(kony.flex.DP);
    var flxInteractions0 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxInteractions0",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_cdd1ecee9cb4493aa325d91f7b012b29,
        "skin": "CopyslFbox0accb1a0f660447",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxInteractions0.setDefaultUnit(kony.flex.DP);
    var lblInteractions01 = new kony.ui.Label({
        "id": "lblInteractions01",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblInteractions02 = new kony.ui.Label({
        "height": "92%",
        "id": "lblInteractions02",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxInteractions0.add(lblInteractions01, lblInteractions02);
    var flxInteractions1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxInteractions1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_d1e745dacd474f42a33cfbc419b1b298,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "1%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxInteractions1.setDefaultUnit(kony.flex.DP);
    var lblInteractions11 = new kony.ui.Label({
        "id": "lblInteractions11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblInteractions12 = new kony.ui.Label({
        "height": "92%",
        "id": "lblInteractions12",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxInteractions1.add(lblInteractions11, lblInteractions12);
    var flxInteractions2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxInteractions2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_be0e73e7b0b74c379e155386fc01427b,
        "skin": "CopyslFbox0e4dcf811c8f645",
        "top": "0.90%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxInteractions2.setDefaultUnit(kony.flex.DP);
    var lblInteractions21 = new kony.ui.Label({
        "id": "lblInteractions21",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblInteractions22 = new kony.ui.Label({
        "height": "92%",
        "id": "lblInteractions22",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxInteractions2.add(lblInteractions21, lblInteractions22);
    flxInteractionsList.add(flxInteractions0, flxInteractions1, flxInteractions2);
    var flxSLA = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxSLA",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_ae532a037217437482f9a3e02486c241,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxSLA.setDefaultUnit(kony.flex.DP);
    var lblSLA = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblSLA",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "CallBack SLA ( > 20 hrs )",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblSLACount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblSLACount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownSLA = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownSLA",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSLA.add(lblSLA, lblSLACount, imgDropDownSLA);
    var flxSLAList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxSLAList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "skinForBorder",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxSLAList.setDefaultUnit(kony.flex.DP);
    var flxSLACse = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxSLACse",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_e9303dc5ed764687b415310f0da0294c,
        "skin": "CopyslFbox0accb1a0f660447",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSLACse.setDefaultUnit(kony.flex.DP);
    var lblSLACse0 = new kony.ui.Label({
        "id": "lblSLACse0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSLACse1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblSLACse1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSLACse.add(lblSLACse0, lblSLACse1);
    var flxSLAProduct = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxSLAProduct",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_f8d94c34f2a349ad8557156bbeb1100c,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "1%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSLAProduct.setDefaultUnit(kony.flex.DP);
    var lblSLAProduct0 = new kony.ui.Label({
        "id": "lblSLAProduct0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSLAProduct1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblSLAProduct1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSLAProduct.add(lblSLAProduct0, lblSLAProduct1);
    var flxSLACloud = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxSLACloud",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_dac53b0d5a4e433483f03909a95da541,
        "skin": "CopyslFbox0e4dcf811c8f645",
        "top": "0.90%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSLACloud.setDefaultUnit(kony.flex.DP);
    var lblSLACloud0 = new kony.ui.Label({
        "id": "lblSLACloud0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSLACloud1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblSLACloud1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSLACloud.add(lblSLACloud0, lblSLACloud1);
    flxSLAList.add(flxSLACse, flxSLAProduct, flxSLACloud);
    flxLeadIndicator.add(flxLabelLeadInd, flxNoFirstResponse, flxNoFirstResList, flxResolutionToBreach, flxResToBreachList, flxAutoClosure, flxAutoClosureList, flxInteractions, flxInteractionsList, flxSLA, flxSLAList);
    var flxLagIndicator = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxLagIndicator",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "skin": "skinLeadIndicator",
        "top": "0%",
        "width": "24%",
        "zIndex": 1
    }, {}, {});
    flxLagIndicator.setDefaultUnit(kony.flex.DP);
    var flxLagInd = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "flxLagInd",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "10%",
        "skin": "CopyslFbox0h94666d706094c",
        "top": "4%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxLagInd.setDefaultUnit(kony.flex.DP);
    var lblLagIndicator = new kony.ui.Label({
        "height": "100%",
        "id": "lblLagIndicator",
        "isVisible": true,
        "left": "0%",
        "skin": "lblLeadIndicatorsskin",
        "text": "LAG INDICATORS",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    flxLagInd.add(lblLagIndicator);
    var flxFirstResponseBreached = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxFirstResponseBreached",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_if4766d9b02342e3b0359a250a31a8b7,
        "skin": "flxSkinLightGrey",
        "top": "4%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxFirstResponseBreached.setDefaultUnit(kony.flex.DP);
    var lblFirstResponseBreached = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblFirstResponseBreached",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "First Response Breach",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblFirstResponseBreachedCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblFirstResponseBreachedCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownFRB = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownFRB",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxFirstResponseBreached.add(lblFirstResponseBreached, lblFirstResponseBreachedCount, imgDropDownFRB);
    var flxFirstResBreachedList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxFirstResBreachedList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "skinForBorder",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxFirstResBreachedList.setDefaultUnit(kony.flex.DP);
    var flxFRB0 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "49%",
        "id": "flxFRB0",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_cb69c6be89de42e5beba96f2090f5b5d,
        "skin": "CopyslFbox0ebe25e6bc55243",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxFRB0.setDefaultUnit(kony.flex.DP);
    var lblFRB01 = new kony.ui.Label({
        "id": "lblFRB01",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblFRB02 = new kony.ui.Label({
        "height": "63%",
        "id": "lblFRB02",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxFRB0.add(lblFRB01, lblFRB02);
    var flxFRB1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "49%",
        "id": "flxFRB1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_d6f08cefb369450aa34220a6c20b40f4,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "1%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxFRB1.setDefaultUnit(kony.flex.DP);
    var lblFRB11 = new kony.ui.Label({
        "id": "lblFRB11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblFRB12 = new kony.ui.Label({
        "height": "63%",
        "id": "lblFRB12",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxFRB1.add(lblFRB11, lblFRB12);
    flxFirstResBreachedList.add(flxFRB0, flxFRB1);
    var flxResolutionBreached = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxResolutionBreached",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_cb5fc2d8e93a47b2b53e44bb84987204,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxResolutionBreached.setDefaultUnit(kony.flex.DP);
    var lblResolutionBreached = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblResolutionBreached",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "Resolution Breached",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblRBCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblRBCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownRB = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownRB",
        "isVisible": true,
        "right": "1%",
        "skin": "CopyslImage0a074bebf11fc4a",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxResolutionBreached.add(lblResolutionBreached, lblRBCount, imgDropDownRB);
    var flxRBList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxRBList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "skinForBorder",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxRBList.setDefaultUnit(kony.flex.DP);
    var flxRB0 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxRB0",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_c3b5daa6dcd94a63958db6d3ddef81a4,
        "skin": "CopyslFbox0e7052db733ab4b",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxRB0.setDefaultUnit(kony.flex.DP);
    var lblRB01 = new kony.ui.Label({
        "id": "lblRB01",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRB02 = new kony.ui.Label({
        "height": "92%",
        "id": "lblRB02",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRB0.add(lblRB01, lblRB02);
    var flxRB1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxRB1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_edd7b91eb76a431d89a6ccba4c687b4e,
        "skin": "CopyslFbox0dca9a479a0c54c",
        "top": "0.50%",
        "width": "100%",
        "zIndex": 2
    }, {}, {});
    flxRB1.setDefaultUnit(kony.flex.DP);
    var lblRB11 = new kony.ui.Label({
        "id": "lblRB11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRB12 = new kony.ui.Label({
        "height": "92%",
        "id": "lblRB12",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRB1.add(lblRB11, lblRB12);
    var flxRB2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxRB2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_dd338d40e70b4629a95c54432d63307c,
        "skin": "CopyslFbox0gf7d4a67cec641",
        "top": "0.60%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxRB2.setDefaultUnit(kony.flex.DP);
    var lblRB21 = new kony.ui.Label({
        "id": "lblRB21",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRB22 = new kony.ui.Label({
        "height": "92%",
        "id": "lblRB22",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRB2.add(lblRB21, lblRB22);
    flxRBList.add(flxRB0, flxRB1, flxRB2);
    var flxNegativeFeedback = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxNegativeFeedback",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_ga820469027d4094be4236ab15b2b407,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxNegativeFeedback.setDefaultUnit(kony.flex.DP);
    var lblNFB = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblNFB",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "Negative Feedback",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblNFBCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblNFBCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownNFB = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownNFB",
        "isVisible": true,
        "right": "1%",
        "skin": "CopyslImage0e352e8e8ff164e",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxNegativeFeedback.add(lblNFB, lblNFBCount, imgDropDownNFB);
    var flxNFBList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxNFBList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "skinForBorder",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxNFBList.setDefaultUnit(kony.flex.DP);
    var flxNFB0 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "49%",
        "id": "flxNFB0",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_a16d20ad4a8548d684cb59f3c293da1c,
        "skin": "CopyslFbox0accb1a0f660447",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxNFB0.setDefaultUnit(kony.flex.DP);
    var lblNFB01 = new kony.ui.Label({
        "id": "lblNFB01",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblNFB02 = new kony.ui.Label({
        "height": "63%",
        "id": "lblNFB02",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxNFB0.add(lblNFB01, lblNFB02);
    var flxNFB1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "49%",
        "id": "flxNFB1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_a0c254d1d06243daa0c28a100d4fdbf6,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "0.80%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxNFB1.setDefaultUnit(kony.flex.DP);
    var lblNFB11 = new kony.ui.Label({
        "id": "lblNFB11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblNFB12 = new kony.ui.Label({
        "height": "63%",
        "id": "lblNFB12",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "10%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxNFB1.add(lblNFB11, lblNFB12);
    flxNFBList.add(flxNFB0, flxNFB1);
    var flxMttr = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxMttr",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_cdc59487787b46219d4ed0934fd89c95,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxMttr.setDefaultUnit(kony.flex.DP);
    var lblMttr = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblMttr",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "MTTR ( > 8 Days )",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblMTTRCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblMTTRCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownMttr = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownMttr",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxMttr.add(lblMttr, lblMTTRCount, imgDropDownMttr);
    var flxMttrList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxMttrList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "skinForBorder",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxMttrList.setDefaultUnit(kony.flex.DP);
    var flxMttr0 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxMttr0",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_c8dc27624039415a907f948e733ed080,
        "skin": "CopyslFbox0accb1a0f660447",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxMttr0.setDefaultUnit(kony.flex.DP);
    var lblMttr01 = new kony.ui.Label({
        "id": "lblMttr01",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblMttr02 = new kony.ui.Label({
        "height": "92%",
        "id": "lblMttr02",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxMttr0.add(lblMttr01, lblMttr02);
    var flxMttr1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxMttr1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_ecf98e3308444d2bbea85afa407cde89,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "1%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxMttr1.setDefaultUnit(kony.flex.DP);
    var lblMttr11 = new kony.ui.Label({
        "id": "lblMttr11",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblMttr12 = new kony.ui.Label({
        "height": "92%",
        "id": "lblMttr12",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxMttr1.add(lblMttr11, lblMttr12);
    var flxMttr2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxMttr2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_baae8a13ecc54f9e8fe92df14677232c,
        "skin": "CopyslFbox0e4dcf811c8f645",
        "top": "0.90%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxMttr2.setDefaultUnit(kony.flex.DP);
    var lblMttr21 = new kony.ui.Label({
        "id": "lblMttr21",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblMttr22 = new kony.ui.Label({
        "height": "92%",
        "id": "lblMttr22",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxMttr2.add(lblMttr21, lblMttr22);
    flxMttrList.add(flxMttr0, flxMttr1, flxMttr2);
    var flxEscalations = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxEscalations",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_be1469f938a04d3a8c1abdb6482c19fa,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxEscalations.setDefaultUnit(kony.flex.DP);
    var lblEscalations = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblEscalations",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "Escalations",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblEscalationsCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblEscalationsCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownEscalations = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownEscalations",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxEscalations.add(lblEscalations, lblEscalationsCount, imgDropDownEscalations);
    var flxEscalationsList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxEscalationsList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "skinForBorder",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxEscalationsList.setDefaultUnit(kony.flex.DP);
    var flxEscalationsCse = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxEscalationsCse",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_fd1a48d000ec4180aef09e2ef1b6c290,
        "skin": "CopyslFbox0accb1a0f660447",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxEscalationsCse.setDefaultUnit(kony.flex.DP);
    var lblESCCse0 = new kony.ui.Label({
        "id": "lblESCCse0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblESCCse1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblESCCse1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxEscalationsCse.add(lblESCCse0, lblESCCse1);
    var flxEscalationsProduct = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxEscalationsProduct",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_i1e429bc615b4b79a960253d86631e9f,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "1%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxEscalationsProduct.setDefaultUnit(kony.flex.DP);
    var lblESCProduct0 = new kony.ui.Label({
        "id": "lblESCProduct0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblESCProduct1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblESCProduct1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxEscalationsProduct.add(lblESCProduct0, lblESCProduct1);
    var flxEscalationsCloud = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxEscalationsCloud",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_d5bbebeb6f884643b1831a27ef88cec0,
        "skin": "CopyslFbox0e4dcf811c8f645",
        "top": "0.90%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxEscalationsCloud.setDefaultUnit(kony.flex.DP);
    var lblESCCloud0 = new kony.ui.Label({
        "id": "lblESCCloud0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblESCCloud1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblESCCloud1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxEscalationsCloud.add(lblESCCloud0, lblESCCloud1);
    flxEscalationsList.add(flxEscalationsCse, flxEscalationsProduct, flxEscalationsCloud);
    flxLagIndicator.add(flxLagInd, flxFirstResponseBreached, flxFirstResBreachedList, flxResolutionBreached, flxRBList, flxNegativeFeedback, flxNFBList, flxMttr, flxMttrList, flxEscalations, flxEscalationsList);
    var flxQualityIndicators = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxQualityIndicators",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "skin": "CopyskinLeadIndicator0fbb4cd5fb72f48",
        "top": "0%",
        "width": "24%",
        "zIndex": 1
    }, {}, {});
    flxQualityIndicators.setDefaultUnit(kony.flex.DP);
    var flxQualityInd = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "flxQualityInd",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "10%",
        "skin": "CopyslFbox0h94666d706094c",
        "top": "4%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxQualityInd.setDefaultUnit(kony.flex.DP);
    var lblQualityInd = new kony.ui.Label({
        "height": "100%",
        "id": "lblQualityInd",
        "isVisible": true,
        "left": "0%",
        "skin": "lblLeadIndicatorsskin",
        "text": "QUALITY INDICATORS",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [1, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    flxQualityInd.add(lblQualityInd);
    var flxProblemStatement = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxProblemStatement",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_h38ac08ac4374411bb27d5f1b589e6f0,
        "skin": "flxSkinLightGrey",
        "top": "4%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxProblemStatement.setDefaultUnit(kony.flex.DP);
    var lblProblemStatement = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblProblemStatement",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "No #Problem Stat...#",
        "width": "74%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblProblemStatementCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblProblemStatementCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownPS = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownPS",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxProblemStatement.add(lblProblemStatement, lblProblemStatementCount, imgDropDownPS);
    var flxProblemStatementList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxProblemStatementList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "slFbox",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxProblemStatementList.setDefaultUnit(kony.flex.DP);
    var flxProblemStatementCse = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxProblemStatementCse",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_db118491ebbe4828a2c23a7384814db3,
        "skin": "CopyslFbox0ebe25e6bc55243",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxProblemStatementCse.setDefaultUnit(kony.flex.DP);
    var lblPSCse0 = new kony.ui.Label({
        "id": "lblPSCse0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblPSCse1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblPSCse1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxProblemStatementCse.add(lblPSCse0, lblPSCse1);
    var flxProblemStatementProduct = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxProblemStatementProduct",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_jb95a174fe144ea2ad3aa3a5589f8567,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "1%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxProblemStatementProduct.setDefaultUnit(kony.flex.DP);
    var lblPSProduct0 = new kony.ui.Label({
        "id": "lblPSProduct0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblPSProduct1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblPSProduct1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxProblemStatementProduct.add(lblPSProduct0, lblPSProduct1);
    var flxProblemStatementCloud = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxProblemStatementCloud",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_a9021af389d5431695bc94a941291ec1,
        "skin": "CopyslFbox0ebe25e6bc55243",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxProblemStatementCloud.setDefaultUnit(kony.flex.DP);
    var lblPSCloud0 = new kony.ui.Label({
        "id": "lblPSCloud0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblPSCloud1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblPSCloud1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxProblemStatementCloud.add(lblPSCloud0, lblPSCloud1);
    flxProblemStatementList.add(flxProblemStatementCse, flxProblemStatementProduct, flxProblemStatementCloud);
    var flxSeverityJustification = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxSeverityJustification",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_ad5ab9b175d64cd8902fe987f9b71bb3,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxSeverityJustification.setDefaultUnit(kony.flex.DP);
    var lblSeverityJustification = new kony.ui.Label({
        "id": "lblSeverityJustification",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "No #Severity Just...#",
        "top": "33%",
        "width": "74%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 0, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblSeverityJustificationCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblSeverityJustificationCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownSJ = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownSJ",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSeverityJustification.add(lblSeverityJustification, lblSeverityJustificationCount, imgDropDownSJ);
    var flxSeverityJustificationList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxSeverityJustificationList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "slFbox",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxSeverityJustificationList.setDefaultUnit(kony.flex.DP);
    var flxSJCse = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxSJCse",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_ia1eb62a6e344176b18dfb9bc3c64f57,
        "skin": "CopyslFbox0accb1a0f660447",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSJCse.setDefaultUnit(kony.flex.DP);
    var lblSJCse0 = new kony.ui.Label({
        "id": "lblSJCse0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSJCse1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblSJCse1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSJCse.add(lblSJCse0, lblSJCse1);
    var flxSJProduct = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxSJProduct",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_fe65343c663f4f98a2e9c6403389933b,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "1%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSJProduct.setDefaultUnit(kony.flex.DP);
    var lblSJProduct0 = new kony.ui.Label({
        "id": "lblSJProduct0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSJProduct1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblSJProduct1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSJProduct.add(lblSJProduct0, lblSJProduct1);
    var flxSJCloud = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxSJCloud",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_hb5735ac443f4e9c92d7b2d73ed8ba17,
        "skin": "CopyslFbox0e4dcf811c8f645",
        "top": "0.90%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSJCloud.setDefaultUnit(kony.flex.DP);
    var lblSJCloud0 = new kony.ui.Label({
        "id": "lblSJCloud0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSJCloud1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblSJCloud1",
        "isVisible": true,
        "left": "76%",
        "onTouchEnd": AS_Label_a3bc091324c54ed7ab5aeb69012cc5af,
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSJCloud.add(lblSJCloud0, lblSJCloud1);
    flxSeverityJustificationList.add(flxSJCse, flxSJProduct, flxSJCloud);
    var flxCustomerDiscussion = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxCustomerDiscussion",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_f3c90be6b6a24a00a8e36292f1eb9f2f,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxCustomerDiscussion.setDefaultUnit(kony.flex.DP);
    var lblCustomerDiscussion = new kony.ui.Label({
        "id": "lblCustomerDiscussion",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "No #Customer Disc...#",
        "top": "33%",
        "width": "74%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 0, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblCustomerDiscussionCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblCustomerDiscussionCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownCD = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownCD",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCustomerDiscussion.add(lblCustomerDiscussion, lblCustomerDiscussionCount, imgDropDownCD);
    var flxCustomerDiscussionList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxCustomerDiscussionList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "slFbox",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxCustomerDiscussionList.setDefaultUnit(kony.flex.DP);
    var flxCDCse = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxCDCse",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_e6977cadcc0e499e9d8b2e073507763c,
        "skin": "CopyslFbox0accb1a0f660447",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxCDCse.setDefaultUnit(kony.flex.DP);
    var lblCDCse0 = new kony.ui.Label({
        "id": "lblCDCse0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblCDCse1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblCDCse1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCDCse.add(lblCDCse0, lblCDCse1);
    var flxCDProduct = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxCDProduct",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_dae012b1fd864aa380d3b88d2c6005ee,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "1%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxCDProduct.setDefaultUnit(kony.flex.DP);
    var lblCDProduct0 = new kony.ui.Label({
        "id": "lblCDProduct0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblCDProduct1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblCDProduct1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCDProduct.add(lblCDProduct0, lblCDProduct1);
    var flxCDCloud = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxCDCloud",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_dd7acb80302f46e7883b2850ea1b16b9,
        "skin": "CopyslFbox0e4dcf811c8f645",
        "top": "0.90%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxCDCloud.setDefaultUnit(kony.flex.DP);
    var lblCDCloud0 = new kony.ui.Label({
        "id": "lblCDCloud0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblCDCloud1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblCDCloud1",
        "isVisible": true,
        "left": "76%",
        "onTouchEnd": AS_Label_a3bc091324c54ed7ab5aeb69012cc5af,
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCDCloud.add(lblCDCloud0, lblCDCloud1);
    flxCustomerDiscussionList.add(flxCDCse, flxCDProduct, flxCDCloud);
    var flxRootCause = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxRootCause",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10.00%",
        "onClick": AS_FlexContainer_i4f9de7209c24a45a778f44139349073,
        "skin": "flxSkinLightGrey",
        "top": "2.00%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxRootCause.setDefaultUnit(kony.flex.DP);
    var lblRootCause = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblRootCause",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "No #Root Cause#",
        "width": "74%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblRootCauseCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblRootCauseCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownRC = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownRC",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRootCause.add(lblRootCause, lblRootCauseCount, imgDropDownRC);
    var flxRootCauseList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxRootCauseList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "slFbox",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxRootCauseList.setDefaultUnit(kony.flex.DP);
    var flxRCCse = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxRCCse",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_acb1f16d25b84976b17b21fc9df50f8d,
        "skin": "CopyslFbox0e7052db733ab4b",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxRCCse.setDefaultUnit(kony.flex.DP);
    var lblRCCse0 = new kony.ui.Label({
        "id": "lblRCCse0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRCCse1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblRCCse1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRCCse.add(lblRCCse0, lblRCCse1);
    var flxRCProduct = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxRCProduct",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_c4627af2a9a748acb6464317548a6377,
        "skin": "CopyslFbox0dca9a479a0c54c",
        "top": "0.50%",
        "width": "100%",
        "zIndex": 2
    }, {}, {});
    flxRCProduct.setDefaultUnit(kony.flex.DP);
    var lblRCProduct0 = new kony.ui.Label({
        "id": "lblRCProduct0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRCProduct1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblRCProduct1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRCProduct.add(lblRCProduct0, lblRCProduct1);
    var flxRCCloud = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxRCCloud",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_fe983421b10343a1943a6ffb72370307,
        "skin": "CopyslFbox0gf7d4a67cec641",
        "top": "0.60%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxRCCloud.setDefaultUnit(kony.flex.DP);
    var lblRCCloud0 = new kony.ui.Label({
        "id": "lblRCCloud0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRCCloud1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblRCCloud1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRCCloud.add(lblRCCloud0, lblRCCloud1);
    flxRootCauseList.add(flxRCCse, flxRCProduct, flxRCCloud);
    var flxSolution = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxSolution",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10%",
        "onClick": AS_FlexContainer_ed7622bd58264ca4986ce34726c4a0cd,
        "skin": "flxSkinLightGrey",
        "top": "2%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxSolution.setDefaultUnit(kony.flex.DP);
    var lblSolution = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblSolution",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSev",
        "text": "No #Solution#",
        "width": "74%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [4, 1, 2, 0],
        "paddingInPixel": false
    }, {});
    var lblSolutionCount = new kony.ui.Label({
        "centerY": "50%",
        "height": "70%",
        "id": "lblSolutionCount",
        "isVisible": true,
        "right": "12%",
        "skin": "lblTCSkin",
        "text": "---",
        "top": "10%",
        "width": "13%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [1, 2, 2, 0],
        "paddingInPixel": false
    }, {});
    var imgDropDownSOL = new kony.ui.Image2({
        "height": "100%",
        "id": "imgDropDownSOL",
        "isVisible": true,
        "right": "1%",
        "skin": "slImage",
        "src": "dropdown1.png",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSolution.add(lblSolution, lblSolutionCount, imgDropDownSOL);
    var flxSolutionList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "24%",
        "id": "flxSolutionList",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "10%",
        "skin": "slFbox",
        "top": "0%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxSolutionList.setDefaultUnit(kony.flex.DP);
    var flxSolCse = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxSolCse",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_hbc74b23181c4e23896c215aff280971,
        "skin": "CopyslFbox0accb1a0f660447",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSolCse.setDefaultUnit(kony.flex.DP);
    var lblSolCse0 = new kony.ui.Label({
        "id": "lblSolCse0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "CSE",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSolCse1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblSolCse1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSolCse.add(lblSolCse0, lblSolCse1);
    var flxSolProduct = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxSolProduct",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_g97736514e924776b98995df0cd7e9b5,
        "skin": "CopyslFbox0eb01ada6c31747",
        "top": "0.80%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSolProduct.setDefaultUnit(kony.flex.DP);
    var lblSolProduct0 = new kony.ui.Label({
        "id": "lblSolProduct0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Product",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSolProduct1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblSolProduct1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSolProduct.add(lblSolProduct0, lblSolProduct1);
    var flxSolCloud = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "flxFocus",
        "height": "33%",
        "id": "flxSolCloud",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_ff0c9f27c6bc46649d6c510fb2e7e517,
        "skin": "CopyslFbox0accb1a0f660447",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSolCloud.setDefaultUnit(kony.flex.DP);
    var lblSolCloud0 = new kony.ui.Label({
        "id": "lblSolCloud0",
        "isVisible": true,
        "left": "6.58%",
        "skin": "lbl1",
        "text": "Cloud",
        "top": "24.72%",
        "width": "65px",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSolCloud1 = new kony.ui.Label({
        "height": "92%",
        "id": "lblSolCloud1",
        "isVisible": true,
        "left": "76%",
        "skin": "lbl2",
        "text": "...",
        "top": "4%",
        "width": "11%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_CENTER,
        "padding": [0, 2, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSolCloud.add(lblSolCloud0, lblSolCloud1);
    flxSolutionList.add(flxSolCse, flxSolProduct, flxSolCloud);
    flxQualityIndicators.add(flxQualityInd, flxProblemStatement, flxProblemStatementList, flxSeverityJustification, flxSeverityJustificationList, flxCustomerDiscussion, flxCustomerDiscussionList, flxRootCause, flxRootCauseList, flxSolution, flxSolutionList);
    flxIndicators.add(flxTicketStatus, flxLeadIndicator, flxLagIndicator, flxQualityIndicators);
    var flxCharts = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "id": "flxCharts",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0c0d3bca47c5b40",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxCharts.setDefaultUnit(kony.flex.DP);
    var lblMTTRSolved = new kony.ui.Label({
        "height": "6%",
        "id": "lblMTTRSolved",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0c98b68dda2794f",
        "text": "MTTR For Month ( SOLVED )",
        "top": "2%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var gauge = new kony.ui.CustomWidget({
        "id": "gauge",
        "isVisible": true,
        "left": "0%",
        "top": "8%",
        "width": "49%",
        "height": "92%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "widgetName": "GaugeChart"
    });
    var lblSeparator = new kony.ui.Label({
        "height": "90%",
        "id": "lblSeparator",
        "isVisible": true,
        "left": "49%",
        "skin": "CopyslLabel0c49d0cb1e2e54a",
        "top": "5%",
        "width": "0.10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopylblSeparator0a95b428cbf8644 = new kony.ui.Label({
        "height": "95%",
        "id": "CopylblSeparator0a95b428cbf8644",
        "isVisible": false,
        "left": "36.90%",
        "skin": "CopyslLabel0c49d0cb1e2e54a",
        "top": "5%",
        "width": "0.10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopylblSeparator0h62ea44da8644d = new kony.ui.Label({
        "height": "95%",
        "id": "CopylblSeparator0h62ea44da8644d",
        "isVisible": false,
        "left": "25.20%",
        "skin": "CopyslLabel0c49d0cb1e2e54a",
        "top": "5%",
        "width": "0.10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopylblSeparator0ja645c9f859343 = new kony.ui.Label({
        "height": "95%",
        "id": "CopylblSeparator0ja645c9f859343",
        "isVisible": false,
        "left": "13.50%",
        "skin": "CopyslLabel0c49d0cb1e2e54a",
        "top": "5%",
        "width": "0.10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lineChart = new kony.ui.CustomWidget({
        "id": "lineChart",
        "isVisible": true,
        "left": "50%",
        "top": "0%",
        "width": "50%",
        "height": "99.78%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "widgetName": "LineChart"
    });
    flxCharts.add(lblMTTRSolved, gauge, lblSeparator, CopylblSeparator0a95b428cbf8644, CopylblSeparator0h62ea44da8644d, CopylblSeparator0ja645c9f859343, lineChart);
    var flxPopupLead = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40%",
        "id": "flxPopupLead",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "23%",
        "skin": "slFbox",
        "top": "20%",
        "width": "50%",
        "zIndex": 10
    }, {}, {});
    flxPopupLead.setDefaultUnit(kony.flex.DP);
    var segPopupLead = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [
            [{
                    "slblCreated": "Created Date",
                    "slblCustName": "Customer",
                    "slblPsAssignee": "PS Assignee",
                    "slblSeverity": "Severity",
                    "slblTicket": "TIcket "
                },
                [{
                    "lblCreated": "Created Date",
                    "lblCustName": "Customer",
                    "lblPsAssignee": "Created Date",
                    "lblSeverity": "Severity",
                    "lblTicket": "RichText"
                }, {
                    "lblCreated": "Created Date",
                    "lblCustName": "Customer",
                    "lblPsAssignee": "Created Date",
                    "lblSeverity": "Severity",
                    "lblTicket": "RichText"
                }, {
                    "lblCreated": "Created Date",
                    "lblCustName": "Customer",
                    "lblPsAssignee": "Created Date",
                    "lblSeverity": "Severity",
                    "lblTicket": "RichText"
                }]
            ]
        ],
        "groupCells": false,
        "height": "94%",
        "id": "segPopupLead",
        "isVisible": true,
        "left": "0%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowSkin": "Copyseg0db3521d31dcc41",
        "rowTemplate": flxRowTemp,
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "sectionHeaderTemplate": flxHeadTempLead,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "6%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxHeadTempLead": "flxHeadTempLead",
            "flxRowTemp": "flxRowTemp",
            "lblCreated": "lblCreated",
            "lblCustName": "lblCustName",
            "lblPsAssignee": "lblPsAssignee",
            "lblSeverity": "lblSeverity",
            "lblTicket": "lblTicket",
            "slblCreated": "slblCreated",
            "slblCustName": "slblCustName",
            "slblPsAssignee": "slblPsAssignee",
            "slblSeverity": "slblSeverity",
            "slblTicket": "slblTicket"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnCloseLead = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossRed0c63e10f86c784c",
        "height": "6%",
        "id": "btnCloseLead",
        "isVisible": true,
        "onClick": AS_Button_j3c670e1ff7c4af6a2beaac3d8d15bd5,
        "right": "0%",
        "skin": "CopyslButtonGlossBlue0h47faa3ca6af4c",
        "text": "X",
        "top": "0%",
        "width": "3%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxPopupLead.add(segPopupLead, btnCloseLead);
    var flxPopupLag = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40%",
        "id": "flxPopupLag",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "23%",
        "skin": "slFbox",
        "top": "20%",
        "width": "50%",
        "zIndex": 10
    }, {}, {});
    flxPopupLag.setDefaultUnit(kony.flex.DP);
    var segPopupLag = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [
            [{
                    "slblCreated": "Created Date",
                    "slblCustName": "Customer",
                    "slblPsAssignee": "PS Assignee",
                    "slblSeverity": "Severity",
                    "slblTicket": "TIcket "
                },
                [{
                    "lblCreated": "Created Date",
                    "lblCustName": "Customer",
                    "lblPsAssignee": "Created Date",
                    "lblSeverity": "Severity",
                    "lblTicket": "RichText"
                }, {
                    "lblCreated": "Created Date",
                    "lblCustName": "Customer",
                    "lblPsAssignee": "Created Date",
                    "lblSeverity": "Severity",
                    "lblTicket": "RichText"
                }, {
                    "lblCreated": "Created Date",
                    "lblCustName": "Customer",
                    "lblPsAssignee": "Created Date",
                    "lblSeverity": "Severity",
                    "lblTicket": "RichText"
                }]
            ]
        ],
        "groupCells": false,
        "height": "94%",
        "id": "segPopupLag",
        "isVisible": true,
        "left": "0%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowSkin": "Copyseg0e822b55e095143",
        "rowTemplate": flxRowTemp,
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "sectionHeaderTemplate": flxHeadTempLag,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "6%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxHeadTempLag": "flxHeadTempLag",
            "flxRowTemp": "flxRowTemp",
            "lblCreated": "lblCreated",
            "lblCustName": "lblCustName",
            "lblPsAssignee": "lblPsAssignee",
            "lblSeverity": "lblSeverity",
            "lblTicket": "lblTicket",
            "slblCreated": "slblCreated",
            "slblCustName": "slblCustName",
            "slblPsAssignee": "slblPsAssignee",
            "slblSeverity": "slblSeverity",
            "slblTicket": "slblTicket"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnSegPopupLag = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossRed0d2f6641c51b949",
        "height": "6%",
        "id": "btnSegPopupLag",
        "isVisible": true,
        "onClick": AS_Button_d3edde8805ff4a50b431a6d008c34d56,
        "right": "0%",
        "skin": "CopyslButtonGlossBlue0h47faa3ca6af4c",
        "text": "X",
        "top": "0%",
        "width": "3%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxPopupLag.add(segPopupLag, btnSegPopupLag);
    var imgRefresh = new kony.ui.Image2({
        "centerX": "97.14%",
        "height": "5%",
        "id": "imgRefresh",
        "isVisible": false,
        "onTouchEnd": AS_Image_b01da0bdd9ba4bc181176e3b8e1a733c,
        "skin": "slImage",
        "src": "ref31.png",
        "top": "2.54%",
        "width": "4%",
        "zIndex": 10
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmDashboard.add(flxHeader, flxIndicators, flxCharts, flxPopupLead, flxPopupLag, imgRefresh);
};

function frmDashboardGlobals() {
    frmDashboard = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmDashboard,
        "enabledForIdleTimeout": false,
        "id": "frmDashboard",
        "init": AS_Form_gbe490a63a0d420eb3e8024f1be2c48e,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0hc760f1674eb4b"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
};