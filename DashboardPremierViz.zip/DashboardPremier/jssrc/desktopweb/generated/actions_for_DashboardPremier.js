//actions.js file 
function AS_Button_d3edde8805ff4a50b431a6d008c34d56(eventobject) {
    frmDashboard.flxPopupLag.setVisibility(false);
    frmDashboard.flxIndicators.opacity = 1;
}

function AS_Button_d6ad25737adb44af86d5aefccc24cb18(eventobject) {
    frmDashboard.flxPopup.setVisibility(false);
}

function AS_Button_d854375919574f279f68f78c9ef8979b(eventobject) {
    return getResponse.call(this, null);
}

function AS_Button_f480db671a604c71a3d8eed9851c18cb(eventobject) {
    return getResponse.call(this, null);
}

function AS_Button_fe985221f0e44895916ee58a97e8aa20(eventobject) {
    return showPopup.call(this, null);
}

function AS_Button_j3c670e1ff7c4af6a2beaac3d8d15bd5(eventobject) {
    frmDashboard.flxPopupLead.setVisibility(false);
    frmDashboard.flxIndicators.opacity = 1;
}

function AS_FlexContainer_a0219f77fc3748dcb754efaa87790e0a(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_a0918c458d9847f3b65d18be37e6561a(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_a0c254d1d06243daa0c28a100d4fdbf6(eventobject) {
    return showNFBPopup.call(this, eventobject);
}

function AS_FlexContainer_a0ffab38c71b4de09d86a809495e8442(eventobject) {
    return showSolvedPopup.call(this, eventobject);
}

function AS_FlexContainer_a16d20ad4a8548d684cb59f3c293da1c(eventobject) {
    return showNFBPopup.call(this, eventobject);
}

function AS_FlexContainer_a16f119d297f4a509fbf657096142c2a(eventobject) {
    if (frmDashboard.flxNFBList.isVisible) {
        frmDashboard.flxNFBList.setVisibility(false);
    } else {
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(true);
    }
}

function AS_FlexContainer_a1ea7a6c777f4d23ad69128fd51a1123(eventobject) {
    if (frmDashboard.flxSolvedList.isVisible) {
        frmDashboard.flxSolvedList.setVisibility(false);
    } else {
        frmDashboard.flxOpenList.setVisibility(false);
        frmDashboard.flxPendingList.setVisibility(false);
        frmDashboard.flxOPMTTRList.setVisibility(false);
        frmDashboard.flxSolvedList.setVisibility(true);
    }
}

function AS_FlexContainer_a2030c3e2a7f45feb5aa0cf9418daa56(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_a23ddcaf3bca4d9d83a15a0194575519(eventobject) {
    return showPendingPopup.call(this, eventobject);
}

function AS_FlexContainer_a2dc83eb194e4cd7809d53fd086730e0(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_a405ae1cad7146e6846ccd060a3fd029(eventobject) {
    if (frmDashboard.flxRBList.isVisible) frmDashboard.flxRBList.setVisibility(false);
    else {
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(true);
    }
}

function AS_FlexContainer_a4b16230d8d24bb381a062123324e006(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_a53958344f1a46609091a566b3110f09(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_a7d9e3065c2346cd8034ba6b8259eeea(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_a8afb219d47348b487fcb1ea1234a523(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_a8eb57fd242844e5b53eb4fea0d6e9da(eventobject) {
    if (frmDashboard.flxResToBreachList.isVisible) {
        frmDashboard.flxResToBreachList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(true);
    } else {
        frmDashboard.flxInteractionsList.setVisibility(false);
        frmDashboard.flxAutoClosureList.setVisibility(false);
        frmDashboard.flxNoFirstResList.setVisibility(false);
        frmDashboard.flxSLAList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(false);
        frmDashboard.flxResToBreachList.setVisibility(true);
        frmDashboard.flxNoFirstResponse.setVisibility(true);
        frmDashboard.flxResolutionToBreach.top = "2%";
        frmDashboard.flxResolutionToBreach.forceLayout();
    }
}

function AS_FlexContainer_a8fa7e8185c44655adac42b1eb44c292(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_a9021af389d5431695bc94a941291ec1(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_a99480931ca5471da702330ae846670e(eventobject) {
    if (frmDashboard.flxPendingList.isVisible) frmDashboard.flxPendingList.setVisibility(false);
    else frmDashboard.flxPendingList.setVisibility(true);
}

function AS_FlexContainer_aa07d73aa5a5432ebacc93ffef347894(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_aae79fb09a8847dba8b651820f6c77d0(eventobject) {
    if (frmDashboard.flxMttrList.isVisible) frmDashboard.flxMttrList.setVisibility(false);
    else {
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(true);
    }
}

function AS_FlexContainer_ab2f8249c4db4312b592bb14ad79e83c(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_ab6109487bf8495288d0b363a189f9b9(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_abe9aae68f464caebe170902ff948f96(eventobject) {
    return showSolvedPopup.call(this, eventobject);
}

function AS_FlexContainer_ac807ce47d804f6a9d4eb48cac6e45d2(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_ac8f6b5ca75d43a78bb450e57661dbd8(eventobject) {
    if (frmDashboard.flxAutoClosureList.isVisible) {
        frmDashboard.flxAutoClosureList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(true);
    } else {
        frmDashboard.flxInteractionsList.setVisibility(false);
        frmDashboard.flxNoFirstResList.setVisibility(false);
        frmDashboard.flxResToBreachList.setVisibility(false);
        frmDashboard.flxSLAList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(false);
        frmDashboard.flxAutoClosureList.setVisibility(true);
        frmDashboard.flxNoFirstResponse.setVisibility(true);
        frmDashboard.flxResolutionToBreach.top = "2%";
        frmDashboard.flxResolutionToBreach.forceLayout();
    }
}

function AS_FlexContainer_acb1f16d25b84976b17b21fc9df50f8d(eventobject) {
    return showRC_SOLPopup.call(this, eventobject);
}

function AS_FlexContainer_ad5ab9b175d64cd8902fe987f9b71bb3(eventobject) {
    if (frmDashboard.flxQualityIndicators.flxSeverityJustificationList.isVisible) {
        frmDashboard.flxQualityIndicators.flxSeverityJustificationList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxSolution.setVisibility(true);
    } else {
        frmDashboard.flxProblemStatementList.setVisibility(false);
        frmDashboard.flxSolutionList.setVisibility(false);
        frmDashboard.flxRootCauseList.setVisibility(false);
        frmDashboard.flxCustomerDiscussionList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxSeverityJustificationList.setVisibility(true);
        frmDashboard.flxQualityIndicators.flxSolution.setVisibility(false);
        frmDashboard.flxProblemStatement.setVisibility(true);
        frmDashboard.flxSeverityJustification.top = "2%";
        frmDashboard.flxSeverityJustification.forceLayout();
    }
}

function AS_FlexContainer_ad65dd6fcd17431db2fa5fc4f314af73(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_ae532a037217437482f9a3e02486c241(eventobject) {
    if (frmDashboard.flxSLAList.isVisible) {
        frmDashboard.flxNoFirstResponse.setVisibility(true);
        frmDashboard.flxResolutionToBreach.top = "2%";
        frmDashboard.flxResolutionToBreach.forceLayout();
        frmDashboard.flxSLAList.setVisibility(false);
    } else {
        frmDashboard.flxNoFirstResponse.setVisibility(false);
        frmDashboard.flxResolutionToBreach.top = "4%";
        frmDashboard.flxResolutionToBreach.forceLayout();
        frmDashboard.flxNoFirstResList.setVisibility(false);
        frmDashboard.flxResToBreachList.setVisibility(false);
        frmDashboard.flxAutoClosureList.setVisibility(false);
        frmDashboard.flxInteractionsList.setVisibility(false);
        frmDashboard.flxSLAList.setVisibility(true);
    }
}

function AS_FlexContainer_af97b71e227e431098a8bdb06ee59394(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_b598702eac01414eaa1d7c79c1e48578(eventobject, x, y) {
    return showPopup.call(this, null);
}

function AS_FlexContainer_b5b5730c62af47f8a527c464272ec474(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_b700562b2e314a049ff35e6da133ee52(eventobject) {
    if (frmDashboard.flxRBList.isVisible) frmDashboard.flxRBList.setVisibility(false);
    else {
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(true);
    }
}

function AS_FlexContainer_b72030680ad2478aaf475ab19683308a(eventobject) {
    return showSolvedPopup.call(this, eventobject);
}

function AS_FlexContainer_b7a65eba6fe04702ab748f0e287070c2(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_b7cc417e577543d88e74b13e5246b8ed(eventobject) {
    return showPendingPopup.call(this, eventobject);
}

function AS_FlexContainer_b83b6260c8484d10b1d965c842e4ecfc(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_b8a3b587b9324901899f2504fbafd5cd(eventobject) {
    if (frmDashboard.flxRBList.isVisible) frmDashboard.flxRBList.setVisibility(false);
    else {
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(true);
    }
}

function AS_FlexContainer_b9156b36829f4311aa9ce936a1931916(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_b930c34ca46f4b0cbba78e17f7854691(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_ba3f6364ade04f46970e6f10c744cff6(eventobject) {
    if (frmDashboard.flxSolvedList.isVisible) {
        frmDashboard.flxSolvedList.setVisibility(false);
    } else {
        if (frmDashboard.flxOpenList.isVisible && frmDashboard.flxPendingList.isVisible) {
            frmDashboard.flxOpenList.setVisibility(false);
            frmDashboard.flxPendingList.setVisibility(false);
            frmDashboard.flxSolvedList.setVisibility(true);
        } else {
            frmDashboard.flxSolvedList.setVisibility(true);
        }
    }
}

function AS_FlexContainer_baae8a13ecc54f9e8fe92df14677232c(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_bb5b30be40ee4558b25b3b6013d67ada(eventobject) {
    if (frmDashboard.flxNoFirstResList.isVisible) {
        frmDashboard.flxNoFirstResList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(true);
    } else {
        frmDashboard.flxResToBreachList.setVisibility(false);
        frmDashboard.flxInteractionsList.setVisibility(false);
        frmDashboard.flxAutoClosureList.setVisibility(false);
        frmDashboard.flxSLAList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(false);
        frmDashboard.flxNoFirstResList.setVisibility(true);
    }
}

function AS_FlexContainer_bb859cdc6df7416ab5a2334a80a36aa0(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_bbc475a2a2864339b382b67d3da10a82(eventobject) {
    if (frmDashboard.flxFirstResBreachedList.isVisible) frmDashboard.flxFirstResBreachedList.setVisibility(false);
    else {
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(true);
    }
}

function AS_FlexContainer_be0e73e7b0b74c379e155386fc01427b(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_be1469f938a04d3a8c1abdb6482c19fa(eventobject) {
    if (frmDashboard.flxEscalationsList.isVisible) {
        frmDashboard.flxEscalationsList.setVisibility(false);
        frmDashboard.flxFirstResponseBreached.setVisibility(true);
        frmDashboard.flxResolutionBreached.top = "2%";
        frmDashboard.flxResolutionBreached.forceLayout();
    } else {
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxEscalationsList.setVisibility(true);
        frmDashboard.flxFirstResponseBreached.setVisibility(false);
        frmDashboard.flxResolutionBreached.top = "4%";
        frmDashboard.flxResolutionBreached.forceLayout();
    }
}

function AS_FlexContainer_befcb965a2cf43b29322dc7b0a8ca948(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_bf9f0d08afb34a339913e283bb21f277(eventobject) {
    return showNFBPopup.call(this, eventobject);
}

function AS_FlexContainer_c02ef2c64db046e2b60184a654f7bbf2(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_c0887ec327f1494a97e486bcd650d6eb(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_c19977aeb5f9482aa78b2d5348d58fb4(eventobject) {
    if (frmDashboard.flxFirstResBreachedList.isVisible) frmDashboard.flxFirstResBreachedList.setVisibility(false);
    else {
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(true);
    }
}

function AS_FlexContainer_c2011870d2164892a9a2598468281963(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_c2465f6cc3004de2a9bf5d481fc7523d(eventobject) {
    return showSolvedPopup.call(this, eventobject);
}

function AS_FlexContainer_c270d6cb39ae4d43881ecbbe81514982(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_c3b5daa6dcd94a63958db6d3ddef81a4(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_c446dfd92b7544c2a7382b39a1c24af6(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_c4627af2a9a748acb6464317548a6377(eventobject) {
    return showRC_SOLPopup.call(this, eventobject);
}

function AS_FlexContainer_c542abe6139a4b2982ce8152b87f0615(eventobject) {
    if (frmDashboard.flxInteractionsList.isVisible) {
        frmDashboard.flxInteractionsList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(true);
    } else {
        frmDashboard.flxNoFirstResList.setVisibility(false);
        frmDashboard.flxResToBreachList.setVisibility(false);
        frmDashboard.flxAutoClosureList.setVisibility(false);
        frmDashboard.flxSLAList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(false);
        frmDashboard.flxInteractionsList.setVisibility(true);
        frmDashboard.flxNoFirstResponse.setVisibility(true);
        frmDashboard.flxResolutionToBreach.top = "2%";
        frmDashboard.flxResolutionToBreach.forceLayout();
    }
}

function AS_FlexContainer_c77c4a4e4bba4e5aa4c2f55535e285f8(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_c869de0af1c341f5bac35a377746108a(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_c86d8f658cc64e60b8d6f226eb72d725(eventobject) {}

function AS_FlexContainer_c8d1e7a1573c47079d5b211ea31a635b(eventobject) {
    return showPendingPopup.call(this, eventobject);
}

function AS_FlexContainer_c8da99587af94922ab8167195c138c57(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_c8dc27624039415a907f948e733ed080(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_c99fc2977e154e69b8574677b848b6ee(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_c9a542db9961467293bb9eac773f3c77(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_ca08736ecad54dc28eb54d2bdf7f59e6(eventobject) {
    return showOpenPopup.call(this, eventobject);
}

function AS_FlexContainer_ca2fbd2154894bd4a55171e462e5e2ea(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_cb072dc2b7a24d39b617ffa7f5d34b64(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_cb5fc2d8e93a47b2b53e44bb84987204(eventobject) {
    if (frmDashboard.flxRBList.isVisible) {
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxEscalations.setVisibility(true);
    } else {
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxEscalationsList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(true);
        frmDashboard.flxEscalations.setVisibility(false);
        frmDashboard.flxFirstResponseBreached.setVisibility(true);
        frmDashboard.flxResolutionBreached.top = "2%";
        frmDashboard.flxResolutionBreached.forceLayout();
    }
}

function AS_FlexContainer_cb69c6be89de42e5beba96f2090f5b5d(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_cdc59487787b46219d4ed0934fd89c95(eventobject) {
    if (frmDashboard.flxMttrList.isVisible) {
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxEscalations.setVisibility(true);
    } else {
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxEscalationsList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(true);
        frmDashboard.flxEscalations.setVisibility(false);
        frmDashboard.flxFirstResponseBreached.setVisibility(true);
        frmDashboard.flxResolutionBreached.top = "2%";
        frmDashboard.flxResolutionBreached.forceLayout();
    }
}

function AS_FlexContainer_cdd1ecee9cb4493aa325d91f7b012b29(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_cef9e334ecfd4702a9700ded2090e364(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_d1422faff2764661891d7599c5e99c3d(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_d1e745dacd474f42a33cfbc419b1b298(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_d1f433bba3d04b28962b53d39a9876b6(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_d222051ea196448b81be98edaa787708(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_d2e62926da1e4d40953b468ce3ae4b5d(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_d476dbdd29b54d69af812aa7d8109074(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_d488f8f57f5d46448b7661e33bb1a464(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_d4ac9f12c07349d9a8b4f978c9e3f25b(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_d529420ae08241b4b4c1375249e518ff(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_d5a88ce63ab649c6bc3ad60f1a0b54a6(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_d5bbebeb6f884643b1831a27ef88cec0(eventobject) {
    return showOpenPopup.call(this, eventobject);
}

function AS_FlexContainer_d6f08cefb369450aa34220a6c20b40f4(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_d72ed7d75b2f409e8a24692323ae11c0(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_d8071fc09ea346bc84302a1e7e27bde2(eventobject) {
    if (frmDashboard.flxMttrList.isVisible) frmDashboard.flxMttrList.setVisibility(false);
    else {
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(true);
    }
}

function AS_FlexContainer_d81379b4a20d4305862fca6ed7ed03ab(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_d94099a31993445fb865685e14263fbc(eventobject) {
    return showNFBPopup.call(this, eventobject);
}

function AS_FlexContainer_dab6275c8b414a82bbeb628624ed7f2e(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_dac53b0d5a4e433483f03909a95da541(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_dae012b1fd864aa380d3b88d2c6005ee(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_db118491ebbe4828a2c23a7384814db3(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_dd338d40e70b4629a95c54432d63307c(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_dd7acb80302f46e7883b2850ea1b16b9(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_df74915fc3ef4c5983416dd306c5d013(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_df78e4216c52461c889a43a55b97b86d(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_df90087af3d8464d9c27e5e6de45a8cf(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_e03a236afb9b4b05b4ee737e611ca07e(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_e04f645024a64703a63c65af5e2c78a6(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_e21f43059a4c4a06bec9a6e816c6d031(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_e2c4bc04740b4d6baf1d77608f4f3ec2(eventobject, x, y) {}

function AS_FlexContainer_e2d544dc31fa42f08ccfaa16fa60e90e(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_e3577b8ae1934d66954247b2efef75dc(eventobject) {
    if (frmDashboard.flxOpenList.isVisible) frmDashboard.flxOpenList.setVisibility(false);
    else {
        frmDashboard.flxPendingList.setVisibility(false);
        frmDashboard.flxSolvedList.setVisibility(false);
        frmDashboard.flxOPMTTRList.setVisibility(false);
        frmDashboard.flxOpenList.setVisibility(true);
    }
}

function AS_FlexContainer_e5448e9d186341d48779446716e81fae(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_e5bec68a62fc4795ac438ab5b51ea800(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_e5bf8d1695f047d18271caffd0dd2025(eventobject) {
    if (frmDashboard.flxNFBList.isVisible) {
        frmDashboard.flxNFBList.setVisibility(false);
    } else {
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(true);
    }
}

function AS_FlexContainer_e65315eaf6694aff9f747d6cff5e07df(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_e6977cadcc0e499e9d8b2e073507763c(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_e6abadf295f64deda1ef93a418925738(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_e819ccf060b847289e16e0840f59bd07(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_e83391b2da6d453d9765e292463972c3(eventobject) {
    return showNFRPopup.call(this, eventobject);
}

function AS_FlexContainer_e8e8e1bbfae8443b8ae51d85d1f6b90a(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_e9303dc5ed764687b415310f0da0294c(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_e9dbb5dcc3b849beaaa4053658c130af(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_ea2a5a2491a6400bbdf5ca078f31cd1c(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_ea766f5fc92746a1a54cded52bf4658a(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_ecf98e3308444d2bbea85afa407cde89(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_ed7622bd58264ca4986ce34726c4a0cd(eventobject) {
    if (frmDashboard.flxQualityIndicators.flxSolutionList.isVisible) {
        frmDashboard.flxQualityIndicators.flxSolutionList.setVisibility(false);
        frmDashboard.flxProblemStatement.setVisibility(true);
        frmDashboard.flxSeverityJustification.top = "2%";
        frmDashboard.flxSeverityJustification.forceLayout();
    } else {
        frmDashboard.flxProblemStatementList.setVisibility(false);
        frmDashboard.flxRootCauseList.setVisibility(false);
        frmDashboard.flxSeverityJustificationList.setVisibility(false);
        frmDashboard.flxCustomerDiscussionList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxSolutionList.setVisibility(true);
        frmDashboard.flxProblemStatement.setVisibility(false);
        frmDashboard.flxSeverityJustification.top = "4%";
        frmDashboard.flxSeverityJustification.forceLayout();
    }
}

function AS_FlexContainer_edd7b91eb76a431d89a6ccba4c687b4e(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_ef13f254a1cd4f76b69dc1f0c2d39eba(eventobject, x, y) {}

function AS_FlexContainer_f0378c6fa0924b95a7b9fe59a0e4765a(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_f1833a75e13844f7b2a49db0cd8557d4(eventobject) {
    if (frmDashboard.flxNFBList.isVisible) {
        frmDashboard.flxNFBList.setVisibility(false);
    } else {
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(true);
    }
}

function AS_FlexContainer_f2003b2681654937a13482e35ab69b0f(eventobject) {
    if (frmDashboard.flxPendingList.isVisible) frmDashboard.flxPendingList.setVisibility(false);
    else {
        frmDashboard.flxSolvedList.setVisibility(false);
        frmDashboard.flxOpenList.setVisibility(false);
        frmDashboard.flxOPMTTRList.setVisibility(false);
        frmDashboard.flxPendingList.setVisibility(true);
    }
}

function AS_FlexContainer_f3c90be6b6a24a00a8e36292f1eb9f2f(eventobject) {
    if (frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.isVisible) {
        frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxSolution.setVisibility(true);
    } else {
        frmDashboard.flxProblemStatementList.setVisibility(false);
        frmDashboard.flxSolutionList.setVisibility(false);
        frmDashboard.flxRootCauseList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxSeverityJustificationList.setVisibility(false);
        frmDashboard.flxCustomerDiscussionList.setVisibility(true);
        frmDashboard.flxQualityIndicators.flxSolution.setVisibility(false);
        frmDashboard.flxProblemStatement.setVisibility(true);
        frmDashboard.flxSeverityJustification.top = "2%";
        frmDashboard.flxSeverityJustification.forceLayout();
    }
}

function AS_FlexContainer_f3d0292dc0f04cedac5fa2129719c961(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_f512a86989ec41728ab62230977e89c5(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_f54396d40ca84d7f93e93675f65b25b1(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_f677f4a182a147dbbff1fe42689f7fb4(eventobject) {}

function AS_FlexContainer_f71614af2046423080dcdab5db74824d(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_f7fbd9dc12f942b8b5139be598241d6e(eventobject) {
    return showNFRPopup.call(this, eventobject);
}

function AS_FlexContainer_f81d43b60b8445fca8f7f9932fefe403(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_f836f7f3b09f4730ad6fd50c9953c274(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_f8c5ebd0cdfd47c085e90aaac30ec2a5(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_f8d94c34f2a349ad8557156bbeb1100c(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_f8f1dbf590de47619e958587e2afad43(eventobject) {
    if (frmDashboard.flxNFBList.isVisible) {
        frmDashboard.flxNFBList.setVisibility(false);
    } else {
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(true);
    }
}

function AS_FlexContainer_f991dfbf834a40528844f21b17df37d5(eventobject) {
    return showNFBPopup.call(this, eventobject);
}

function AS_FlexContainer_fa5e91aec5794e96b2cbf2454ee22b2c(eventobject) {
    if (frmDashboard.flxOPMTTRList.isVisible) {
        frmDashboard.flxOPMTTRList.setVisibility(false);
    } else {
        frmDashboard.flxOpenList.setVisibility(false);
        frmDashboard.flxPendingList.setVisibility(false);
        frmDashboard.flxSolvedList.setVisibility(false);
        frmDashboard.flxOPMTTRList.setVisibility(true);
    }
}

function AS_FlexContainer_fb4039925c5345cdaae7436ca671b062(eventobject) {
    return showAutoSolvedPopup.call(this, eventobject);
}

function AS_FlexContainer_fcc95050e5474150a2a8d1f3153546ed(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_fd1a48d000ec4180aef09e2ef1b6c290(eventobject) {
    return showOpenPopup.call(this, eventobject);
}

function AS_FlexContainer_fd69a3eca2764bc5a03a0576b5dd30b3(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_fe65343c663f4f98a2e9c6403389933b(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_fe983421b10343a1943a6ffb72370307(eventobject) {
    return showRC_SOLPopup.call(this, eventobject);
}

function AS_FlexContainer_fedb971a9b274f71b337781a9f677ac0(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_ff0c9f27c6bc46649d6c510fb2e7e517(eventobject) {
    return showRC_SOLPopup.call(this, eventobject);
}

function AS_FlexContainer_ff2e8f877dbf4849a48e1948920b6b42(eventobject, x, y) {}

function AS_FlexContainer_ff8770f815724c04bf40d92aabc11346(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_g15c691ba83643059eb2349f056d787f(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_g208592ee4de4a16af8622b80b9d1eed(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_g4441ab3cbb44614acf73d091ee05505(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_g7d48886ae3949789c206edbe92c5275(eventobject) {
    if (frmDashboard.flxRBList.isVisible) frmDashboard.flxRBList.setVisibility(false);
    else {
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(true);
    }
}

function AS_FlexContainer_g9558207e83e4bcc847bcf5c39a5d773(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_g9586b17d6894be088632503d7fb6928(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_g97736514e924776b98995df0cd7e9b5(eventobject) {
    return showRC_SOLPopup.call(this, eventobject);
}

function AS_FlexContainer_ga820469027d4094be4236ab15b2b407(eventobject) {
    if (frmDashboard.flxNFBList.isVisible) {
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxEscalations.setVisibility(true);
    } else {
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxEscalationsList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(true);
        frmDashboard.flxEscalations.setVisibility(false);
        frmDashboard.flxFirstResponseBreached.setVisibility(true);
        frmDashboard.flxResolutionBreached.top = "2%";
        frmDashboard.flxResolutionBreached.forceLayout();
    }
}

function AS_FlexContainer_ga948880b27f42a487796da8c6003600(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_gad40eafa04b4a39bcb3eec24be1ad80(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_gfc32c3821ad4d0c833a365498b29c14(eventobject) {
    if (frmDashboard.flxFirstResBreachedList.isVisible) frmDashboard.flxFirstResBreachedList.setVisibility(false);
    else {
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(true);
    }
}

function AS_FlexContainer_h021267dd2114033950e9c380310cf2a(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_h193ec056fae47d195a91b47ae658590(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_h30027e5112a4949ad6c3327d8c194e1(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_h3374a95e1fd431cbe43da7a032976e3(eventobject) {
    return showOpenPopup.call(this, eventobject);
}

function AS_FlexContainer_h38ac08ac4374411bb27d5f1b589e6f0(eventobject) {
    if (frmDashboard.flxQualityIndicators.flxProblemStatementList.isVisible) {
        frmDashboard.flxQualityIndicators.flxProblemStatementList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxSolution.setVisibility(true);
    } else {
        frmDashboard.flxSolutionList.setVisibility(false);
        frmDashboard.flxRootCauseList.setVisibility(false);
        frmDashboard.flxSeverityJustificationList.setVisibility(false);
        frmDashboard.flxCustomerDiscussionList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxProblemStatementList.setVisibility(true);
        frmDashboard.flxQualityIndicators.flxSolution.setVisibility(false);
    }
}

function AS_FlexContainer_h4ee07da7878494591856bcfad8912ca(eventobject) {
    if (frmDashboard.flxFirstResBreachedList.isVisible) frmDashboard.flxFirstResBreachedList.setVisibility(false);
    else {
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(true);
    }
}

function AS_FlexContainer_h6022918bf1d4eb791e42d31802ea93f(eventobject) {
    if (frmDashboard.flxMttrList.isVisible) frmDashboard.flxMttrList.setVisibility(false);
    else {
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(true);
    }
}

function AS_FlexContainer_h72e053bf88f467bb0be52ff555fdb6f(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_h8654c9a441d49f1a9f8e2d39d6d4ac2(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_hb5735ac443f4e9c92d7b2d73ed8ba17(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_hbc74b23181c4e23896c215aff280971(eventobject) {
    return showRC_SOLPopup.call(this, eventobject);
}

function AS_FlexContainer_hd15e09aa25040818614770d079f637f(eventobject) {
    return showInteractionsPopup.call(this, eventobject);
}

function AS_FlexContainer_hd7861303a8a47a0a25d2cf2cb971f5c(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_he2c66701698406e934870c2ee90d12d(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_hebed9fbe08f4221aacd7e3777807d52(eventobject) {
    return showSolvedPopup.call(this, eventobject);
}

function AS_FlexContainer_i0c6f694a7d3418fbf2a21cff3d764e5(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_i1297f73f22a4b1b9a837433b97ea565(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_i1e429bc615b4b79a960253d86631e9f(eventobject) {
    return showOpenPopup.call(this, eventobject);
}

function AS_FlexContainer_i2633640ceb94db5be98e41183d42856(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_i2faa87f419d4575afaaf5e5cb734ee8(eventobject) {
    if (frmDashboard.flxMttrList.isVisible) frmDashboard.flxMttrList.setVisibility(false);
    else {
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(true);
    }
}

function AS_FlexContainer_i39286f6bd5c4471a70a2f49f542ad6a(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_i493509291c3408b967140e25dff9242(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_i4f9de7209c24a45a778f44139349073(eventobject) {
    if (frmDashboard.flxQualityIndicators.flxRootCauseList.isVisible) {
        frmDashboard.flxQualityIndicators.flxRootCauseList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxSolution.setVisibility(true);
    } else {
        frmDashboard.flxProblemStatementList.setVisibility(false);
        frmDashboard.flxSolutionList.setVisibility(false);
        frmDashboard.flxSeverityJustificationList.setVisibility(false);
        frmDashboard.flxCustomerDiscussionList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxRootCauseList.setVisibility(true);
        frmDashboard.flxQualityIndicators.flxSolution.setVisibility(false);
        frmDashboard.flxProblemStatement.setVisibility(true);
        frmDashboard.flxSeverityJustification.top = "2%";
        frmDashboard.flxSeverityJustification.forceLayout();
    }
}

function AS_FlexContainer_i67174d00ba54f23880f49acb055f392(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_i9a68da99edd47a598af2be15379c0ee(eventobject) {
    if (frmDashboard.flxLagIndicator.flxFirstResBreachedList.isVisible) {
        frmDashboard.flxLagIndicator.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxLagIndicator.flxEscalations.setVisibility(true);
    } else {
        frmDashboard.flxLagIndicator.flxRBList.setVisibility(false);
        frmDashboard.flxLagIndicator.flxNFBList.setVisibility(false);
        frmDashboard.flxLagIndicator.flxMttrList.setVisibility(false);
        frmDashboard.flxLagIndicator.flxEscalationsList.setVisibility(false);
        frmDashboard.flxLagIndicator.flxFirstResBreachedList.setVisibility(true);
        frmDashboard.flxLagIndicator.flxEscalations.setVisibility(false);
    }
}

function AS_FlexContainer_i9e8e05f555f4e548465a290d3be8b18(eventobject) {
    return showAutoSolvedPopup.call(this, eventobject);
}

function AS_FlexContainer_ia1eb62a6e344176b18dfb9bc3c64f57(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_ia90632dcf794eb19367f7553fafa8ca(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_idd3c18bfb6d4d978c095c9eb05588aa(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_if4766d9b02342e3b0359a250a31a8b7(eventobject) {
    if (frmDashboard.flxLagIndicator.flxFirstResBreachedList.isVisible) {
        frmDashboard.flxLagIndicator.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxLagIndicator.flxEscalations.setVisibility(true);
    } else {
        frmDashboard.flxLagIndicator.flxRBList.setVisibility(false);
        frmDashboard.flxLagIndicator.flxNFBList.setVisibility(false);
        frmDashboard.flxLagIndicator.flxMttrList.setVisibility(false);
        frmDashboard.flxLagIndicator.flxEscalationsList.setVisibility(false);
        frmDashboard.flxLagIndicator.flxFirstResBreachedList.setVisibility(true);
        frmDashboard.flxLagIndicator.flxEscalations.setVisibility(false);
    }
}

function AS_FlexContainer_ifc43292dfe44c478130a9e0b4065564(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_j08a4a01f4514ecd970a329269cdcee7(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_j098da75239341a3938697b9e8d576fb(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_j16599488aab4a01bf88228a315985f2(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_j3456a5bc82545438f3a2129208814ae(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_j4c96dba621844bfad2b79798da68ff1(eventobject) {
    return showNFBPopup.call(this, eventobject);
}

function AS_FlexContainer_j600a9b63be64b7b826a806341c8538c(eventobject) {
    return showSolvedPopup.call(this, eventobject);
}

function AS_FlexContainer_j9d0f6ab1a174b03b653d0a120d62e49(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_FlexContainer_jad635b613994c83b54370214d5f9550(eventobject) {
    return navigateToView.call(this, eventobject);
}

function AS_FlexContainer_jb0362e00dea42c1a30a73e75120a07e(eventobject) {
    return showOpenPopup.call(this, eventobject);
}

function AS_FlexContainer_jb95a174fe144ea2ad3aa3a5589f8567(eventobject) {
    return showPS_SJPopup.call(this, eventobject);
}

function AS_FlexContainer_je44c35507974a40a31ae40718f9ca4f(eventobject) {
    return showPopup.call(this, eventobject);
}

function AS_Form_a32e07c3372e4044a298fda022a819f4(eventobject) {
    return separateTicketsSeverityBased.call(this);
}

function AS_Form_d55f28cd228142a6ab7b72ec0674406f(eventobject) {
    return getResponse.call(this, null);
}

function AS_Form_e0e0428dfd75493b84b632582fba2bd8(eventobject) {
    return getResponse.call(this, null);
}

function AS_Form_gbe490a63a0d420eb3e8024f1be2c48e(eventobject) {
    mobileFabricInitialization.call(this);
    frmDashboard.flxSeverityJustification.lblSeverityJustification.top = "33%";
    frmDashboard.flxSeverityJustification.forceLayout();
    frmDashboard.flxOpenList.flxO3.top = "0.6%";
    frmDashboard.flxOpenList.flxO3.forceLayout();
    frmDashboard.flxHeader.height = "8%";
    frmDashboard.flxHeader.forceLayout();
    frmDashboard.flxIndicators.top = "8%";
    frmDashboard.flxIndicators.height = "67%";
    frmDashboard.flxIndicators.forceLayout();
    frmDashboard.flxCharts.top = "75%";
    frmDashboard.flxCharts.height = "25%";
    frmDashboard.flxCharts.forceLayout();
}

function AS_Form_j4b6ecabd43c4cd09e285f1f1f5b65be(eventobject) {
    return mobileFabricInitialization.call(this);
}

function AS_Image_b01da0bdd9ba4bc181176e3b8e1a733c(eventobject, x, y) {
    window.location.reload();
}

function AS_Label_a3bc091324c54ed7ab5aeb69012cc5af(eventobject, x, y) {}

function AS_Label_jead7cc6e9f74e9ca9e9884b3fb61c24(eventobject, x, y) {}

function AS_Segment_e8ec45bef66b4027acb48d668a0b62a4(eventobject, sectionNumber, rowNumber) {
    return showPopup.call(this, null);
}