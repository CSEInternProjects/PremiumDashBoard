function initializesegRowTemp() {
    flxRowTemp = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "36px",
        "id": "flxRowTemp",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0jd37455f395240"
    }, {}, {});
    flxRowTemp.setDefaultUnit(kony.flex.DP);
    var lblTicket = new kony.ui.RichText({
        "id": "lblTicket",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslRichText0fcb80b59f34944",
        "text": "<a href=\"www.gmail.com\">987987</a>",
        "top": "30%",
        "width": "9%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSeverity = new kony.ui.Label({
        "id": "lblSeverity",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslLabel0a5cdb363c29647",
        "text": "Severity",
        "top": "30%",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblCustName = new kony.ui.Label({
        "id": "lblCustName",
        "isVisible": true,
        "left": "20%",
        "skin": "CopyslLabel0h95819d826394d",
        "text": "Customer",
        "top": "30%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblCreated = new kony.ui.Label({
        "id": "lblCreated",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0ifedbe520f3e48",
        "text": "Created Date",
        "top": "30%",
        "width": "15%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblPsAssignee = new kony.ui.Label({
        "id": "lblPsAssignee",
        "isVisible": true,
        "left": "55%",
        "skin": "CopyslLabel0d963f7fc75b648",
        "text": "Assignee",
        "top": "30%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRowTemp.add(lblTicket, lblSeverity, lblCustName, lblCreated, lblPsAssignee);
}