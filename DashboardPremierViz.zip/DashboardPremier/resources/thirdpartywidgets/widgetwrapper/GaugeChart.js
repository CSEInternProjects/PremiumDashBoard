GaugeChart = {

    initializeWidget : function(parentNode, widgetModel)
    {
      
                  console.log("initializing  NOW...");
                  console.log(parentNode);
                  console.log(widgetModel);
				  
				           var area='<div id="chart_div1" style="padding-left:25px"></div>'; 

							parentNode.innerHTML=area;
				  
				  
                        google.charts.load('current', {'packages':['gauge']});
						
						google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
				
        var data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
          ['OverAll', 0],
          ['CSE', 0],
          ['Product', 0],
		  ['Cloud', 0]
        ]);
	    var Ticks = [0, 3, 6, 9, 12, 15];
        var options = {
          width: 750, height: 160,
		  greenFrom: 0,
		  greenTo: 7,
		  yellowFrom: 7,
          yellowTo: 8,
          redFrom:8,
          redTo: 15,
          minorTicks:3,
		  majorTicks:Ticks,
		  min: 0,
          max: 15,
		  animation: {
          duration: 3000,
          easing: 'inAndOut',
		  startup: true
		  }
        };
		 
        var chart1 = new google.visualization.Gauge(document.getElementById('chart_div1'));
        chart1.draw(data, options);     
        data.setValue(0, 1, 0);
        data.setValue(1, 1, 0);
        data.setValue(2, 1, 0);
		data.setValue(3, 1, 0);
		
		chart1.draw(data, options);
      }
    }   
}