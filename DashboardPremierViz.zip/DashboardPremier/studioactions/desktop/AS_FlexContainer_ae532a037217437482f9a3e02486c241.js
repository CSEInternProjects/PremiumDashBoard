function AS_FlexContainer_ae532a037217437482f9a3e02486c241(eventobject) {
    if (frmDashboard.flxSLAList.isVisible) {
        frmDashboard.flxNoFirstResponse.setVisibility(true);
        frmDashboard.flxResolutionToBreach.top = "2%";
        frmDashboard.flxResolutionToBreach.forceLayout();
        frmDashboard.flxSLAList.setVisibility(false);
    } else {
        frmDashboard.flxNoFirstResponse.setVisibility(false);
        frmDashboard.flxResolutionToBreach.top = "4%";
        frmDashboard.flxResolutionToBreach.forceLayout();
        frmDashboard.flxNoFirstResList.setVisibility(false);
        frmDashboard.flxResToBreachList.setVisibility(false);
        frmDashboard.flxAutoClosureList.setVisibility(false);
        frmDashboard.flxInteractionsList.setVisibility(false);
        frmDashboard.flxSLAList.setVisibility(true);
    }
}