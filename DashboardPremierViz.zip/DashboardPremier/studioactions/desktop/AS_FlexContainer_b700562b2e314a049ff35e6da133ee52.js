function AS_FlexContainer_b700562b2e314a049ff35e6da133ee52(eventobject) {
    if (frmDashboard.flxRBList.isVisible) frmDashboard.flxRBList.setVisibility(false);
    else {
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(true);
    }
}