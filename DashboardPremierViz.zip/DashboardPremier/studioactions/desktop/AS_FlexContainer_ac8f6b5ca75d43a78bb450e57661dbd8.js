function AS_FlexContainer_ac8f6b5ca75d43a78bb450e57661dbd8(eventobject) {
    if (frmDashboard.flxAutoClosureList.isVisible) {
        frmDashboard.flxAutoClosureList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(true);
    } else {
        frmDashboard.flxInteractionsList.setVisibility(false);
        frmDashboard.flxNoFirstResList.setVisibility(false);
        frmDashboard.flxResToBreachList.setVisibility(false);
        frmDashboard.flxSLAList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(false);
        frmDashboard.flxAutoClosureList.setVisibility(true);
        frmDashboard.flxNoFirstResponse.setVisibility(true);
        frmDashboard.flxResolutionToBreach.top = "2%";
        frmDashboard.flxResolutionToBreach.forceLayout();
    }
}