function AS_FlexContainer_a1ea7a6c777f4d23ad69128fd51a1123(eventobject) {
    if (frmDashboard.flxSolvedList.isVisible) {
        frmDashboard.flxSolvedList.setVisibility(false);
    } else {
        frmDashboard.flxOpenList.setVisibility(false);
        frmDashboard.flxPendingList.setVisibility(false);
        frmDashboard.flxOPMTTRList.setVisibility(false);
        frmDashboard.flxSolvedList.setVisibility(true);
    }
}