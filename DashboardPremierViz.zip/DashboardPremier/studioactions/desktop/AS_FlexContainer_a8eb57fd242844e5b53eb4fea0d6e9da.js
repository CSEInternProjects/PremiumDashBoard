function AS_FlexContainer_a8eb57fd242844e5b53eb4fea0d6e9da(eventobject) {
    if (frmDashboard.flxResToBreachList.isVisible) {
        frmDashboard.flxResToBreachList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(true);
    } else {
        frmDashboard.flxInteractionsList.setVisibility(false);
        frmDashboard.flxAutoClosureList.setVisibility(false);
        frmDashboard.flxNoFirstResList.setVisibility(false);
        frmDashboard.flxSLAList.setVisibility(false);
        frmDashboard.flxSLA.setVisibility(false);
        frmDashboard.flxResToBreachList.setVisibility(true);
        frmDashboard.flxNoFirstResponse.setVisibility(true);
        frmDashboard.flxResolutionToBreach.top = "2%";
        frmDashboard.flxResolutionToBreach.forceLayout();
    }
}