function AS_FlexContainer_ad5ab9b175d64cd8902fe987f9b71bb3(eventobject) {
    if (frmDashboard.flxQualityIndicators.flxSeverityJustificationList.isVisible) {
        frmDashboard.flxQualityIndicators.flxSeverityJustificationList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxSolution.setVisibility(true);
    } else {
        frmDashboard.flxProblemStatementList.setVisibility(false);
        frmDashboard.flxSolutionList.setVisibility(false);
        frmDashboard.flxRootCauseList.setVisibility(false);
        frmDashboard.flxCustomerDiscussionList.setVisibility(false);
        frmDashboard.flxQualityIndicators.flxSeverityJustificationList.setVisibility(true);
        frmDashboard.flxQualityIndicators.flxSolution.setVisibility(false);
        frmDashboard.flxProblemStatement.setVisibility(true);
        frmDashboard.flxSeverityJustification.top = "2%";
        frmDashboard.flxSeverityJustification.forceLayout();
    }
}