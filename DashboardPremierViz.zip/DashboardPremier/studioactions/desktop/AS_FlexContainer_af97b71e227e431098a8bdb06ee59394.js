function AS_FlexContainer_af97b71e227e431098a8bdb06ee59394(eventobject) {
    return navigateToView.call(this, eventobject);
}