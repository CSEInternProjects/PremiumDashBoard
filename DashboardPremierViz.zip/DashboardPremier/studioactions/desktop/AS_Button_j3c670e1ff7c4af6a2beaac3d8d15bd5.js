function AS_Button_j3c670e1ff7c4af6a2beaac3d8d15bd5(eventobject) {
    frmDashboard.flxPopupLead.setVisibility(false);
    frmDashboard.flxIndicators.opacity = 1;
}