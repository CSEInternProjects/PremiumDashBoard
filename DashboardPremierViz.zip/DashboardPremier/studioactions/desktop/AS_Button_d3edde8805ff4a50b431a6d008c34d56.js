function AS_Button_d3edde8805ff4a50b431a6d008c34d56(eventobject) {
    frmDashboard.flxPopupLag.setVisibility(false);
    frmDashboard.flxIndicators.opacity = 1;
}