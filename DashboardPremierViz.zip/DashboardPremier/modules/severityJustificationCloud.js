//Type your code here
//Type your code here
//Type your code here
severityJustificationCommentsCloud=[];
severityJustificationPopupCloud=[];
customerDiscussionPopupCloud=[];
var valueSJCloud=0;
var idSJCloud;
function severityJustificationCloud()
{
 // alert("Entered SJCLoud");
  //kony.timer.schedule(e, speedometer, 4, false);
  speedometer();
  temp=[];
  if(openCloud.ticketsCount!=="0"){
   for(var i=0;i<openCloud.tickets.length;i++)
    {
      custName="";
       psAssign="";
      severity="";
       
         customArr=openCloud.tickets[i].CustomField;
      for(var k=0;k<customArr.length;k++)
      {
        if(customArr[k].id===22846480)
          {
            if(customArr[k].value!==null)
              {
                temp.push(openCloud.tickets[i].ticketId);
              }
            
          }
        
        else if(customArr[k].id===77167)
          {
            severity=customArr[k].value;
            
          }
        else if(customArr[k].id===21277110)
          {
            custName=customArr[k].value;
          }
          
           else if(customArr[k].id===21145230)
          {
            psAssign=customArr[k].value;
          }
        
      }
      
       severity=severity.toLowerCase();
      severity=severity.trim();
      if(custName!==null)
      		CustomerName=custName.trim();
      else
            CustomerName="none";
      
      PSAssignee=psAssign.trim();
      
             openCloud.tickets[i].CName=CustomerName;
             openCloud.tickets[i].severityOfTicket=severity;
      
       
      


PSAssignee=PSAssignee.trim();
PSAssignee=PSAssignee.replace("_"," ");
      PSAssignee=PSAssignee.replace("-"," ");
var arr = PSAssignee.split(' ');

var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
if(arr.length>1)
{
var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

if(second!=="Tickets")
{
PSAssignee=first+" "+second;
}
else
{
PSAssignee=first;
}
}
else
{
PSAssignee=first;
}
 if(PSAssignee==="")
    {
      PSAssignee="None";
  }
        openCloud.tickets[i].PSAssignee=PSAssignee;
  }
  
  severityJustificationCommentsCloud=temp;
  
  
  if(severityJustificationCommentsCloud.length!==0)
    {
      
        
            idSJCloud=severityJustificationCommentsCloud[valueSJCloud];
           mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
          headers={};

          data={"ticketId":idSJCloud};

           mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getSJCloudCommentsSuccessCallback, getSJCloudCommentsErrorCallback);
        
    
  }
  
  else
    {
      frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJCloud.lblSJCloud1.text=0;
            frmDashboard.flxQualityIndicators.flxSeverityJustification.lblSeverityJustificationCount.text=severityJustificationPopupCse.length+severityJustificationPopupProduct.length+severityJustificationPopupCloud.length;
      
       frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDCloud.lblCDCloud1.text=0;
      frmDashboard.flxQualityIndicators.flxCustomerDiscussion.lblCustomerDiscussionCount.text=customerDiscussionPopupCse.length+customerDiscussionPopupProduct.length+customerDiscussionPopupCloud.length;
      
//        frmDashboard.flxIndicators.opacity=1;  
//       kony.application.dismissLoadingScreen();
      
    }
  
  }
  else
    {
      frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJCloud.lblSJCloud1.text=0;
            frmDashboard.flxQualityIndicators.flxSeverityJustification.lblSeverityJustificationCount.text=severityJustificationPopupCse.length+severityJustificationPopupProduct.length+severityJustificationPopupCloud.length;
      
      frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDCloud.lblCDCloud1.text=0;
      frmDashboard.flxQualityIndicators.flxCustomerDiscussion.lblCustomerDiscussionCount.text=customerDiscussionPopupCse.length+customerDiscussionPopupProduct.length+customerDiscussionPopupCloud.length;
      
//       frmDashboard.flxIndicators.opacity=1; 
//       kony.application.dismissLoadingScreen();
      
    }
  
}

function invokingToGetSJCloudComments(value)
{
   idSJCloud=severityJustificationCommentsCloud[value];
           mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
          headers={};

          data={"ticketId":idSJCloud};

           mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getSJCloudCommentsSuccessCallback, getSJCloudCommentsErrorCallback);
}



function getSJCloudCommentsSuccessCallback(res)
{
  
  if(res.count!==0)
    {
      flag=0;
      test=0;
      for(var k=0;k<res.comments.length;k++)
        {
            str=res.comments[k].text;
           if(str.indexOf("#Severity Justification#") >=0) 
             {
               flag=1;
             }
          if(str.indexOf("#Customer Discussion#") >=0) 
             {
               test=1;
             }
        }
      
      if(flag===0)
        {
           severityJustificationPopupCloud.push(idSJCloud);
        }
        if(test===0)
        {
           customerDiscussionPopupCloud.push(idSJCloud);
        }
      
    }
  
  valueSJCloud++;
  if(valueSJCloud<severityJustificationCommentsCloud.length)
    {
      invokingToGetSJCloudComments(valueSJCloud);
    }
  else
    {
      frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJCloud.lblSJCloud1.text=severityJustificationPopupCloud.length;
      frmDashboard.flxQualityIndicators.flxSeverityJustification.lblSeverityJustificationCount.text=severityJustificationPopupCse.length+severityJustificationPopupProduct.length+severityJustificationPopupCloud.length;
      
      frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDCloud.lblCDCloud1.text=customerDiscussionPopupCloud.length;
      frmDashboard.flxQualityIndicators.flxCustomerDiscussion.lblCustomerDiscussionCount.text=customerDiscussionPopupCse.length+customerDiscussionPopupProduct.length+customerDiscussionPopupCloud.length;
      
      //frmDashboard.flxIndicators.opacity=1;
//       kony.application.dismissLoadingScreen();
    }
}


function getSJCloudCommentsErrorCallback(res)
{
  
  //alert("Error in retreiving comments");
   frmDashboard.flxIndicators.opacity=1;
      
      kony.application.dismissLoadingScreen();
}
