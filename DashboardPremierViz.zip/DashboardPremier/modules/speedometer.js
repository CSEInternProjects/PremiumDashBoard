//Type your code here

function speedometer()
{
 // alert("Entered Speedometer")
  total=0;
  cseTotal=0;
  productTotal=0;
  cloudTotal=0;
   
 for(var z=0;z<globalResponsesLeadLag.length;z++)
   {
     if(globalResponsesLeadLag[z].viewNumber==="114115512134")
       {
         total+=globalResponsesLeadLag[z].tickets.length;
         cseTotal+=globalResponsesLeadLag[z].tickets.length;
         
       }
     else if(globalResponsesLeadLag[z].viewNumber==="114115514894")
       {
        total+=globalResponsesLeadLag[z].tickets.length;
         productTotal+=globalResponsesLeadLag[z].tickets.length;
         
       }
     else if(globalResponsesLeadLag[z].viewNumber==="114115514994")
       {
         total+=globalResponsesLeadLag[z].tickets.length;
         cloudTotal+=globalResponsesLeadLag[z].tickets.length;
         
       }
     
   }
  
  hoursOverall=overallPremiumHours;
  daysOverall=hoursOverall/24;
 daysOverall = Math.round( daysOverall * 10 ) / 10;       
  var mttrOverall=daysOverall/total;
  mttrOverall = Math.round( mttrOverall * 10 ) / 10;
  
  
  hoursCse=cseOpenPendingHours;
  daysCse=hoursCse/24;
 daysCse = Math.round( daysCse * 10 ) / 10;         
  var mttrCse=daysCse/cseTotal;
  mttrCse = Math.round( mttrCse * 10 ) / 10;
  
  
  
  hoursProduct=productOpenPendingHours;
  daysProduct=hoursProduct/24;
 daysProduct = Math.round( daysProduct * 10 ) / 10;       
  var mttrProduct=daysProduct/productTotal;
  mttrProduct = Math.round( mttrProduct * 10 ) / 10;
  
  
  hoursCloud=cloudOpenPendingHours;
  daysCloud=hoursCloud/24;
 daysCloud = Math.round( daysCloud * 10 ) / 10;        
  var mttrCloud=daysCloud/cloudTotal;
  mttrCloud = Math.round( mttrCloud * 10 ) / 10;
  
  solvedMTTR();
  
//   temp={"premierValue":[]};
//   temp.premierValue.push(mttrOverall);
//   temp.premierValue.push(mttrCse);
//   temp.premierValue.push(mttrProduct);
//   temp.premierValue.push(mttrCloud);
  
  frmDashboard.flxOPMTTR.lblOPMTTRCount.text=Math.floor(mttrOverall).toString();
  frmDashboard.flxOPMTTRList.flxCSEMTTR.CSEMTTR.text=mttrCse.toString();
   frmDashboard.flxOPMTTRList.flxProdMTTR.ProductMTTR.text=mttrProduct.toString();
   frmDashboard.flxOPMTTRList.flxCloudMTTR.CloudMTTR.text=mttrCloud.toString();
  
//  frmDashboard.gauge.chartData=temp;
//   google.charts.load('current', {'packages':['gauge']});
						
// 						google.charts.setOnLoadCallback(drawGuageChart);
  
// //kony.timer.schedule(a, refreshApp, 300, true);
//   	drawLineChart();
 
}
 function drawGuageChart() {
				
        var data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
          ['OverAll', 0],
          ['CSE', 0],
          ['Product', 0],
		  ['Cloud', 0]
        ]);
	    var Ticks = [0, 3, 6, 9, 12, 15];
        var options = {
          width: 750, height: 160,
		  greenFrom: 0,
		  greenTo: 7,
		  yellowFrom: 7,
          yellowTo: 8,
          redFrom:8,
          redTo: 15,
          minorTicks:3,
		  majorTicks:Ticks,
		  min: 0,
          max: 15,
		  animation: {
          duration: 3000,
          easing: 'inAndOut',
		  startup: true
		  }
        };
		 
        var chart1 = new google.visualization.Gauge(document.getElementById('chart_div1'));
        chart1.draw(data, options);     
        data.setValue(0, 1, frmDashboard.gauge.chartData.premierValue[0]);
        data.setValue(1, 1, frmDashboard.gauge.chartData.premierValue[1]);
        data.setValue(2, 1, frmDashboard.gauge.chartData.premierValue[2]);
		data.setValue(3, 1, frmDashboard.gauge.chartData.premierValue[3]);
		
		chart1.draw(data, options);
      }








function drawLineChart(){		  
		var options = {
  type: 'line',
  data: {
    labels: frmDashboard.lineChart.chartData.labels,
    datasets: [
	  {
	      label: 'Created',
		  lineTension: 1,
            backgroundColor: "rgba(75,192,192,0.3)",
            borderColor: "rgba(75,192,192,1)",
            borderCapStyle: 'round',
            borderDash: [],
            borderDashOffset: 0.0,
            pointBorderColor: "rgba(75,192,192,1)",
            pointBackgroundColor: "#fff",
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBackgroundColor: "rgba(75,192,192,1)",
            pointHoverBorderColor: "rgba(220,220,220,1)",
            pointHoverBorderWidth: 2,
            pointRadius: 5,
            pointHitRadius: 10,
	      data: frmDashboard.lineChart.chartData.data1,
      	borderWidth: 3
    	},  
      {
	      label: 'Solved',
		  lineTension: 1,
            backgroundColor: "rgba(130,169,76,0.4)",
            borderColor: "rgba(130,169,76,1)",
            borderCapStyle: 'round',
            borderDash: [],
            borderDashOffset: 0.0,
            pointBorderColor: "rgba(75,192,192,1)",
            pointBackgroundColor: "#fff",
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBackgroundColor: "rgba(75,192,192,1)",
            pointHoverBorderColor: "rgba(220,220,220,1)",
            pointHoverBorderWidth: 2,
            pointRadius: 5,
            pointHitRadius: 10,
	      data: frmDashboard.lineChart.chartData.data2,
      	borderWidth: 3
    	}
		]
  },
  options: { 
        legend: {
            labels: {
                fontColor: "#ddd",
                fontSize: 10
            }
        },
        scales: {
            yAxes: [{
                ticks: {
                    fontColor: "#ddd",
                    fontSize: 12,
                    
                    beginAtZero: true
                }
            }],
            xAxes: [{
                ticks: {
                    fontColor: "#ddd",
                    fontSize: 10,
                   
                    beginAtZero: true
                }
            }]
        }
    }
}

var ctx = document.getElementById('canvas').getContext('2d');
new Chart(ctx, options);
	}





function timerFunction()
{
  //alert("Here You GO ");
}