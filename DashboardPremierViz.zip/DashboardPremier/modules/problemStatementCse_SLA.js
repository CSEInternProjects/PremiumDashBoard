//Type your code here
var ticketsForSLACse;
ticketsForCommentsCse=[];

ProblemStatementPopupCse=[];
var valueCse=0;
var idCse;
function fillIndicatorsCse()
{
  temp=[];
  tempSLA=[];
  if(openCse.ticketsCount!=="0"){
  for(var i=0;i<openCse.tickets.length;i++)
    {
      							 var createdTime=openCse.tickets[i].CreatedAt;
                                 
                                      var localDate = new Date(createdTime);
                                 
                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;
                              var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
      
                        if(hours > 24)
                          {
                            temp.push(openCse.tickets[i].ticketId);
                             
                          }
      
      
      
      customArr=openCse.tickets[i].CustomField;
      for(var k=0;k<customArr.length;k++)
      {

         if(customArr[k].id===22054000)
          {
             if(customArr[k].value!==null)
               {
            lastUpdated=customArr[k].value;
            lastUpdated=lastUpdated.toString();
               }
            else
              {
                lastUpdated=null;
              }
            
          }
        
        
      }
if(lastUpdated!==null){ 
var dateUpdated=lastUpdated.substr(0,10);
var time=lastUpdated.substr(11,8);
dateUpdated=dateUpdated.replace("/"," ");
dateUpdated=dateUpdated.replace("/"," ");
time=time.replace(":"," ");
time=time.replace(":"," ");

var dateArr=dateUpdated.split(" ");
var timeArr=time.split(" ");
var dd=dateArr[0];
var mm=parseInt(dateArr[1])-1;
mm=mm.toString();
var yy=dateArr[2];
var h=timeArr[0];
var m=timeArr[1];
var s=timeArr[2];

var lastUpdated=new Date(yy,mm,dd,h,m,s);
var newDate=new Date();

var hoursSinceUpdate = Math.abs(newDate - lastUpdated) / 36e5;
      if(hoursSinceUpdate > 20)
        {
          tempSLA.push(openCse.tickets[i].ticketId);
        }
      
}

    }
      ticketsForSLACse=tempSLA;
  
  ticketsForCommentsCse=temp;

  
  if(ticketsForCommentsCse.length!==0)
    {
      
        
            idCse=ticketsForCommentsCse[valueCse];
           mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
          headers={};

          data={"ticketId":idCse};

           mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getCseCommentsSuccessCallback, getCseCommentsErrorCallback);
        
    
  }
  
  else
    {
      frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementCse.lblPSCse1.text=0;
      
    }
  
  }
  else
    {
      frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementCse.lblPSCse1.text=0;
      frmDashboard.flxLeadIndicator.flxSLAList.flxSLACse.lblSLACse1.text=0;
      
    }
  
}

function invokingToGetCseComments(value)
{
   idCse=ticketsForCommentsCse[value];
           mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
          headers={};

          data={"ticketId":idCse};

           mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getCseCommentsSuccessCallback, getCseCommentsErrorCallback);
}



function getCseCommentsSuccessCallback(res)
{
  
  if(res.count!==0)
    {
      flag=0;
      for(var k=0;k<res.comments.length;k++)
        {
            str=res.comments[k].text;
           if(str.indexOf("#Problem Statement#") >=0) 
             {
               flag=1;
             }
        }
      
      if(flag===0)
        {
           ProblemStatementPopupCse.push(idCse);
        }
    }
  
  valueCse++;
  if(valueCse<ticketsForCommentsCse.length)
    {
      invokingToGetCseComments(valueCse);
    }
  else
    {
      frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementCse.lblPSCse1.text=ProblemStatementPopupCse.length;
      frmDashboard.flxLeadIndicator.flxSLAList.flxSLACse.lblSLACse1.text=ticketsForSLACse.length;
    }
}


function getCseCommentsErrorCallback(res)
{
  
 // alert("Error in retreiving comments");
}
