//Type your code here

//Type your code here



function showNFBPopup(context)
{
  
  var flxId=context.constructorList[0].id;
  var i;
  
  frmDashboard.flxPopupLead.segPopupLead.widgetDataMap={
    
    slblTicket:"slblTicket",
    slblSeverity:"slblSeverity",
    slblCustName:"slblCustName",
    slblCreated:"slblCreated",   
    slblPsAssignee:"slblPsAssignee",
   
    lblTicket:"valId",
    lblSeverity:"Severity",
    lblCustName:"CName",
    lblCreated:"days",
    
    lblPsAssignee:"PSAssignee"
  };
    arrToSetSegData=[  
    					[ 
                          {
                             slblTicket:"Ticket Id",
  							  slblSupportPlan:"Support Plan",
 							slblSeverity:"Severity",
   							 	slblCustName:"Customer Name",
  							  slblCreated:"Age(Days)",
  							  slblUpdated:"UpdatedAt",
  							  slblPsAssignee:"CSE Assignee"
                          },
                           
                        ]
    
                   ];
  switch(flxId)
    {
      case "flxNFB0":
                         if(nfbCse.ticketsCount!=="0"){
                          for(i=0;i<nfbCse.tickets.length;i++)
                          {
                            
                                   custName="";
                                       psAssign="";
      									 supPlan="";
                                      valId=nfbCse.tickets[i].ticketId;
                        		 nfbCse.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                                            var customArr=nfbCse.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                    {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                    //  kony.print("iteration count in inner for loop:"+k);
                                                    }

                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
                                                    PSAssignee=psAssign.trim();

                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     nfbCse.tickets[i].CName=CustomerName;
                                                     nfbCse.tickets[i].SupportPlan=SupportPlan;



                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                                                    PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                              if(second!=="Tickets")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }

                                           if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }
                            nfbCse.tickets[i].PSAssignee=PSAssignee;
                          					   nfbCse.tickets[i].Severity=severity;
                            
                                   var createdTime=nfbCse.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=nfbCse.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
										 days = Math.round( days * 10 ) / 10;
                       		days=days.toString();
                                         nfbCse.tickets[i].days=days;
                                       //  nfbCse.tickets[i].CreatedAt=createdDateTime;
                                       //  nfbCse.tickets[i].UpdatedAt=updatedDateTime;

                            

                                }
        
                            arrToSetSegData[0].push(nfbCse.tickets);
      					  frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
                          }
  					    else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
                        break;
        
       
        case "flxNFB1":
                        if(nfbProduct.ticketsCount!=="0"){
                          for(i=0;i<nfbProduct.tickets.length;i++)
                          {
                            
                                   custName="";
                                       psAssign="";
      									 supPlan="";
                                   valId=nfbProduct.tickets[i].ticketId;
                        		 nfbProduct.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                                            var customArr=nfbProduct.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                    {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                    //  kony.print("iteration count in inner for loop:"+k);
                                                    }

                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
                                                    PSAssignee=psAssign.trim();

                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     nfbProduct.tickets[i].CName=CustomerName;
                                                     nfbProduct.tickets[i].SupportPlan=SupportPlan;



                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                                                    PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                              if(second!=="Tickets")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }

                                            if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }
                            nfbProduct.tickets[i].PSAssignee=PSAssignee;
                          					   nfbProduct.tickets[i].Severity=severity;
                            
                                   var createdTime=nfbProduct.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=nfbProduct.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
										 days = Math.round( days * 10 ) / 10;
                       		days=days.toString();
                                         nfbProduct.tickets[i].days=days;
                                      //   nfbProduct.tickets[i].CreatedAt=createdDateTime;
                                        // nfbProduct.tickets[i].UpdatedAt=updatedDateTime;

                            

                                }
        
                            arrToSetSegData[0].push(nfbProduct.tickets);
      					  frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
                    }
  					    else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
                        break;
     
        
          }
  
  
  
   if(arrToSetSegData[0][1].length!==0)
   {

  flxRowTemp.forceLayout();
     frmDashboard.flxIndicators.opacity=0.1;
   if(flxId==="flxNFB0" || flxId==="flxNFB1")   
     {
   frmDashboard.flxPopupLead.setVisibility(true);
   frmDashboard.flxPopupLead.forceLayout();
     }
  
     
   }
  else
    {
       frmDashboard.flxIndicators.opacity=1;
      alert("Sorry there are no tickets to display");
    }
  
  
 
}//Type your code here//Type your code here