//Type your code here
//Type your code here

var psCseTickets=[];
var psProductTickets=[];
var psCloudTickets=[];
var sjCseTickets=[];
var sjProductTickets=[];
var sjCloudTickets=[];
var cdCseTickets=[];
var cdProductTickets=[];
var cdCloudTickets=[];
var slaCseTickets=[];
var slaProductTickets=[];
var slaCloudTickets=[];
function showPS_SJPopup(context)
{
  var flxId=context.constructorList[0].id;
  var m,n;
  
  if(flxId==="flxProblemStatementCse")
    {
      
      for(m=0;m<ProblemStatementPopupCse.length;m++)
        {
          
          for(n=0;n<openCse.tickets.length;n++)
            {
              if(ProblemStatementPopupCse[m]===openCse.tickets[n].ticketId)
                {
                  psCseTickets.push(openCse.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
  
   else if(flxId==="flxProblemStatementProduct")
    {
      
      for( m=0;m<ProblemStatementPopupProduct.length;m++)
        {
          
          for( n=0;n<openProduct.tickets.length;n++)
            {
              if(ProblemStatementPopupProduct[m]===openProduct.tickets[n].ticketId)
                {
                  psProductTickets.push(openProduct.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
  
  
     else if(flxId==="flxProblemStatementCloud")
    {
      
      for( m=0;m<ProblemStatementPopupCloud.length;m++)
        {
          
          for( n=0;n<openCloud.tickets.length;n++)
            {
              if(ProblemStatementPopupCloud[m]===openCloud.tickets[n].ticketId)
                {
                  psCloudTickets.push(openCloud.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
 
  
  else if(flxId==="flxSJCse")
    {
      
      for(m=0;m<severityJustificationPopupCse.length;m++)
        {
          
          for(n=0;n<openCse.tickets.length;n++)
            {
              if(severityJustificationPopupCse[m]===openCse.tickets[n].ticketId)
                {
                  sjCseTickets.push(openCse.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
   else if(flxId==="flxSJProduct")
    {
      
      for(m=0;m<severityJustificationPopupProduct.length;m++)
        {
          
          for(n=0;n<openProduct.tickets.length;n++)
            {
              if(severityJustificationPopupProduct[m]===openProduct.tickets[n].ticketId)
                {
                  sjProductTickets.push(openProduct.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
   else if(flxId==="flxSJCloud")
    {
      
      for(m=0;m<severityJustificationPopupCloud.length;m++)
        {
          
          for(n=0;n<openCloud.tickets.length;n++)
            {
              if(severityJustificationPopupCloud[m]===openCloud.tickets[n].ticketId)
                {
                  sjCloudTickets.push(openCloud.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
  
     else if(flxId==="flxCDCse")
    {
      
      for(m=0;m<customerDiscussionPopupCse.length;m++)
        {
          
          for(n=0;n<openCse.tickets.length;n++)
            {
              if(customerDiscussionPopupCse[m]===openCse.tickets[n].ticketId)
                {
                  cdCseTickets.push(openCse.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
  
   else if(flxId==="flxCDProduct")
    {
      
      for(m=0;m<customerDiscussionPopupProduct.length;m++)
        {
          
          for(n=0;n<openCse.tickets.length;n++)
            {
              if(customerDiscussionPopupProduct[m]===openProduct.tickets[n].ticketId)
                {
                  cdProductTickets.push(openCse.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
  
   else if(flxId==="flxCDCloud")
    {
      
      for(m=0;m<customerDiscussionPopupCloud.length;m++)
        {
          
          for(n=0;n<openCse.tickets.length;n++)
            {
              if(customerDiscussionPopupCloud[m]===openCloud.tickets[n].ticketId)
                {
                  cdCloudTickets.push(openCse.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
  
    else if(flxId==="flxSLACse")
    {
      
      for(m=0;m<ticketsForSLACse.length;m++)
        {
          
          for(n=0;n<openCse.tickets.length;n++)
            {
              if(ticketsForSLACse[m]===openCse.tickets[n].ticketId)
                {
                  slaCseTickets.push(openCse.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
   else if(flxId==="flxSLAProduct")
    {
      
      for(m=0;m<ticketsForSLAProduct.length;m++)
        {
          
          for(n=0;n<openProduct.tickets.length;n++)
            {
              if(ticketsForSLAProduct[m]===openProduct.tickets[n].ticketId)
                {
                  slaProductTickets.push(openProduct.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
   else if(flxId==="flxSLACloud")
    {
      
      for(m=0;m<ticketsForSLACloud.length;m++)
        {
          
          for(n=0;n<openCloud.tickets.length;n++)
            {
              if(ticketsForSLACloud[m]===openCloud.tickets[n].ticketId)
                {
                  slaCloudTickets.push(openCloud.tickets[n]);
                  break;
                }
              
            }
          
        }
      
    }
  
  
  
    frmDashboard.flxPopupLag.segPopupLag.widgetDataMap={
    
    slblTicket:"slblTicket", 
    slblSeverity:"slblSeverity",
    slblCustName:"slblCustName",
    slblCreated:"slblCreated",    
    slblPsAssignee:"slblPsAssignee",
      
    lblTicket:"valId",
    lblSeverity:"severityOfTicket",
    lblCustName:"CName",
    lblCreated:"days",
    lblPsAssignee:"PSAssignee"
  };
  
  
  arrToSetSegData=[  
    					[ 
                          {
                             slblTicket:"Ticket Id",
  							  slblSupportPlan:"Support Plan",
 							slblSeverity:"Severity",
   							 	slblCustName:"Customer Name",
  							  slblCreated:"Age(Days)",
  							  slblUpdated:"UpdatedAt",
  							  slblPsAssignee:"CSE Assignee"
                          },
                           
                        ]
    
                   ];
  
  
    
  switch(flxId)
    {
      case "flxProblemStatementCse":
        
                     	for(n=0;n<psCseTickets.length;n++)
                       {
                                    createdTime=psCseTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=psCseTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         psCseTickets[n].days=days;
                         valId=psCseTickets[n].ticketId;
                         
                         psCseTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(psCseTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			psCseTickets=[];
        			 break;    
     case "flxProblemStatementProduct":
        
                     	for(n=0;n<psProductTickets.length;n++)
                       {
                          createdTime=psProductTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=psProductTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    				
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         psProductTickets[n].days=days;
                         valId=psProductTickets[n].ticketId;
                         
                         psProductTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(psProductTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
                      psProductTickets=[];
        			 break;  
       case "flxProblemStatementCloud":
        
                     	for(n=0;n<psCloudTickets.length;n++)
                       {
                          createdTime=psCloudTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=psCloudTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
      
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         psCloudTickets[n].days=days;
                         valId=psCloudTickets[n].ticketId;
                         
                         psCloudTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(psCloudTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			psCloudTickets=[];
        			 break; 
        
      case "flxSJCse":
        
                     	for(n=0;n<sjCseTickets.length;n++)
                       {
                          createdTime=sjCseTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=sjCseTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
      
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         sjCseTickets[n].days=days;
                         valId=sjCseTickets[n].ticketId;
                         
                         sjCseTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(sjCseTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			sjCseTickets=[];
        			 break;
        case "flxSJProduct":
        
                     	for(n=0;n<sjProductTickets.length;n++)
                       {
                          createdTime=sjProductTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=sjProductTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
      
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         sjProductTickets[n].days=days;
                         valId=sjProductTickets[n].ticketId;
                         
                         sjProductTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(sjProductTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			sjProductTickets=[];
        			 break;
      
      case "flxSJCloud":
        
                     	for(n=0;n<sjCloudTickets.length;n++)
                       {
                          createdTime=sjCloudTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=sjCloudTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
      
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         sjCloudTickets[n].days=days;
                         valId=sjCloudTickets[n].ticketId;
                         
                         sjCloudTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(sjCloudTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			sjCloudTickets=[];
        			 break;
        
         case "flxCDCse":
        
                     	for(n=0;n<cdCseTickets.length;n++)
                       {
                          createdTime=cdCseTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=cdCseTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
      
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         cdCseTickets[n].days=days;
                         valId=cdCseTickets[n].ticketId;
                         
                         cdCseTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(cdCseTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			cdCseTickets=[];
        			 break;
        
        case "flxCDProduct":
        
                     	for(n=0;n<cdProductTickets.length;n++)
                       {
                          createdTime=cdProductTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=cdProductTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
      
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         cdProductTickets[n].days=days;
                         valId=cdProductTickets[n].ticketId;
                         
                         cdProductTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(cdProductTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			cdProductTickets=[];
        			 break;
        
        case "flxCDCloud":
        
                     	for(n=0;n<cdCloudTickets.length;n++)
                       {
                          createdTime=cdCloudTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=cdCloudTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
      
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         cdCloudTickets[n].days=days;
                         valId=cdCloudTickets[n].ticketId;
                         
                         cdCloudTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(cdCloudTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			cdCloudTickets=[];
        			 break;
        
        case "flxSLACse":
        
                     	for(n=0;n<slaCseTickets.length;n++)
                       {
                          createdTime=slaCseTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=slaCseTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
      
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         slaCseTickets[n].days=days;
                         valId=slaCseTickets[n].ticketId;
                         
                         slaCseTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(slaCseTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			slaCseTickets=[];
        			 break; 
        
         case "flxSLAProduct":
        
                     	for(n=0;n<slaProductTickets.length;n++)
                       {
                          createdTime=slaProductTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=slaProductTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
      
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         slaProductTickets[n].days=days;
                         valId=slaProductTickets[n].ticketId;
                         
                         slaProductTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(slaProductTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			slaProductTickets=[];
        
        			 break; 
        
        case "flxSLACloud":
        
                     	for(n=0;n<slaCloudTickets.length;n++)
                       {
                          createdTime=slaCloudTickets[n].CreatedAt;
    							 currentTime=new Date();
     
   							  updatedTime=slaCloudTickets[n].UpdatedAt;

                          localDate = new Date(createdTime);
    					
      
						date= new Date();
								 hours = Math.abs(date - localDate) / 36e5;
                         
                          days=hours/24;
							 days = Math.round( days * 10 ) / 10;
                         slaCloudTickets[n].days=days;
                         valId=slaCloudTickets[n].ticketId;
                         
                         slaCloudTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                       }
                     arrToSetSegData[0].push(slaCloudTickets);
      			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
        			slaCloudTickets=[];
        
        			 break; 
        
       
  
    }
  
  if(arrToSetSegData[0][1].length!==0)
   {
   frmDashboard.flxIndicators.opacity=0.1;     
     frmDashboard.flxIndicators.forceLayout();
  flxRowTemp.forceLayout();
   
   frmDashboard.flxPopupLag.setVisibility(true);
   frmDashboard.flxPopupLag.forceLayout();
    
    
     
   }
  else
    {
     frmDashboard.flxIndicators.opacity=1;
      alert("Sorry there are no tickets to display");
    }
  
  
   
  
  
}