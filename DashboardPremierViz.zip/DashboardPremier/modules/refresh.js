//Type your code here
function refreshApp()
{
 
 //this below additions are to set timer ids dynamically
a=a+"1";
b=b+"1";
c=c+"1";
  d=d+"1";
  e=e+"1";
  
 
  timerLoad=1;
  console.log("xxxxxxxxxxxRefreshing This Appxxxxxxxxxxxxxxx");
  viewNumLead=0;
  viewNumTicketStatus=0;
  openCount=0;
pendingCount=0;
solvedCount=0;
  nbCount=0;
  escCount=0;
  
 globalResponsesLeadLag=[]; 
  
  nfrCount=0;
     frbCount=0;
     toBreachCount=0;
      breachedCount=0;
     mttrCount=0;
      cseOpenPendingHours=0;
     cloudOpenPendingHours=0;
    productOpenPendingHours=0;
   overallPremiumHours=0;
  
  L2AutoSolvedCount=0;
 L3AutoSolvedCount=0;
 L2AutoSolvedArr=[];
 L3AutoSolvedArr=[];
 autoSolvedL3=[];
 autoSolvedL2=[];
  
  ticketArrayIterator=0;
  interactionsCount=0;
  repliesCSE=[];
  repliesProduct=[];
 repliesCloud=[];
  interactionsCSE=[];
interactionsProduct=[];
interactionsCloud=[];
  
  ticketsForGraphs=[];
  
     valueCse=0;
     ProblemStatementPopupCse=[];
    valueProduct=0;
     ProblemStatementPopupProduct=[];
     valueCloud=0;
     ProblemStatementPopupCloud=[];
  
     rootCausePopupCse=[];
	solutionPopupCse=[];
 	valueRootCauseCse=0;
        rootCausePopupProduct=[];
	solutionPopupProduct=[];
 	valueRootCauseProduct=0;
        rootCausePopupCloud=[];
	solutionPopupCloud=[];
 	valueRootCauseCloud=0;
  
  severityJustificationPopupCse=[];
  customerDiscussionPopupCse=[];
		valueSJCse=0;
  	severityJustificationPopupProduct=[];
  customerDiscussionPopupProduct=[];
	   valueSJProduct=0;
  	severityJustificationPopupCloud=[];
  customerDiscussionPopupCloud=[];
		valueSJCloud=0;
  
  solvedCseMonth=[];
solvedProductMonth=[];
solvedCloudMonth=[];
  
  monthTicketsSolvedCse=[];
monthTicketsSolvedProduct=[];
monthTicketsSolvedCloud=[];
  
  cseSolvedMTTR=[];
 productSolvedMTTR=[];
 cloudSolvedMTTR=[];
  
  cseCurrentMonthTickets=[];
 cloudCurrentMonthTickets=[];
 productCurrentMonthTickets=[];
  
  
   getResponse(viewArrTicketStatus[viewNumTicketStatus]);
  
   getLeadIndicatorResponse(viewArrLeadIndicator[viewNumLead]);
  
  
  
  
  
}