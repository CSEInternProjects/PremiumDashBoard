//Type your code here


function navigateToView(context)
{
  var id=context.constructorList[0].id;
  switch(id)
    {
      case "flxO1":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115504214";
                   kony.application.openURL(URL);
                   break;
        
      case "flxO2":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115352713";
                   kony.application.openURL(URL);
        			break;
      case "flxO3":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115351973";
                   kony.application.openURL(URL);
        			break;
      case "flxP1":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115351093";
                   kony.application.openURL(URL);
        			break;
      case "flxP2":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115352733";
                   kony.application.openURL(URL);
        			break;  
       case "flxP3":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115351993";
                   kony.application.openURL(URL);
        			break;
       case "flxS1":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115351953";
                   kony.application.openURL(URL);
        			break;
       case "flxS2":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115506394";
                   kony.application.openURL(URL);
        			break;
        case "flxS3":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115352013";
                   kony.application.openURL(URL);
        			break;
        
       case "flxNR0":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115506434";
                   kony.application.openURL(URL);
        			break;
         case "flxNR1":
                   URL="https://konysolutions.zendesk.com/agent/filters/114115352813";
                   kony.application.openURL(URL);
        			break;
         case "flxAC0":
                   URL="https://konysolutions.zendesk.com/agent/filters/114116933313";
                   kony.application.openURL(URL);
        			break;
         case "flxAC1":
                   URL="https://konysolutions.zendesk.com/agent/filters/114116933313";
                   kony.application.openURL(URL);
        			break;
         case "flxNFB0":
                   URL="https://konysolutions.zendesk.com/agent/filters/114117060174";
                   kony.application.openURL(URL);
        			break;
          case "flxNFB1":
                   URL="https://konysolutions.zendesk.com/agent/filters/114116936113";
                   kony.application.openURL(URL);
        			break;
        
        
    }
  
}