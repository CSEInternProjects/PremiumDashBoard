//Type your code here


var nfrCse;
var nfrProduct;
var nfrCseEmpty;
var nfrProductEmpty;
var nfrCount=0;
    var frbCount=0;
    var toBreachCount=0;
     var breachedCount=0;
     var mttrCount=0;
      var cseOpenPendingHours=0;
   var  cloudOpenPendingHours=0;
   var productOpenPendingHours=0;
  var overallPremiumHours=0;
var popupCseTicketsArr;
var popupCseTicketsBreachedArr;
var popupProductTicketsArr;
var popupProductTicketsBreachedArr;
var popupCloudTicketsArr;
var popupCloudTicketsBreachedArr;
viewNumLead=0;
var totalTicketsBreached;
var totalTicketsBreached1;
criticalTicketsArr=[];
mediumTicketsArr=[];
highTicketsArr=[];
lowTicketsArr=[];
globalResponsesLeadLag=[];
viewArrLeadIndicator=["114115506434","114115352813","114115512134","114115514894","114115514994","114116933313"];
function getLeadIndicatorResponse(viewIdHere)
{
     if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
//         kony.application.showLoadingScreen("loadSkin","", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, false, true, {
//             enableMenuKey: true,
//             enableBackKey: true,
//           shouldShowLabelInBottom: "true",
//             progressIndicatorColor: "ffffff77"
//         });

        var operationName = mobileFabricConfiguration.integrationServices[0].operations[1];
      headers={};
     
      data={"viewId":viewIdHere};
        mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
       mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, severityBasedTicketsSeparator, getLeadIndicatorResponseErrorCallback);
        
    }
 }
  
function getLeadIndicatorResponseSuccessCallback(res)
{
     
   
    
}

function getLeadIndicatorResponseErrorCallback(res)
{
  //alert("Error occured in retrieving response");
  frmDashboard.flxIndicators.opacity=1;
}




function severityBasedTicketsSeparator(res)
{
   ticketsCount=null;
  
  ticketsArray=[];
  criticalTicketsArr=[];
  mediumTicketsArr=[];
  highTicketsArr=[];
  lowTicketsArr=[];
 // kony.print("Total Tickets count here is:"+res.ticketsCount+","+res.tickets.length);
  var severity;
  totalTicketsBreachCount=null;
 if(res.ticketsCount!=="0")
  {
    res.viewNumber=viewArrLeadIndicator[viewNumLead];
  for(var i=0;i<res.tickets.length;i++)
    {
       custName="";
       psAssign="";
       supPlan="";
      
      ticketsArray.push(res.tickets[i].ticketId);
      
        var customArr=res.tickets[i].CustomField;
      for(var k=0;k<customArr.length;k++)
      {
        if(customArr[k].id===77167)
          {
            severity=customArr[k].value;
            
          }
        else if(customArr[k].id===21277110)
          {
            custName=customArr[k].value;
          }
           else if(customArr[k].id===40952728)
          {
            supPlan=customArr[k].value;
          }
           else if(customArr[k].id===21145230)
          {
            psAssign=customArr[k].value;
          }
      //  kony.print("iteration count in inner for loop:"+k);
      }

      severity=severity.toLowerCase();
      severity=severity.trim();
      if(custName!==null)
      		CustomerName=custName.trim();
      else
            CustomerName="none";
      SupportPlan=supPlan.trim();
      PSAssignee=psAssign.trim();
      
       if(SupportPlan==="supportplan_1")
         {
           SupportPlan="Premier";
         }
       else if(SupportPlan==="supportplan_1_1")
         {
           SupportPlan="Premier Plus";
         }
     
       res.tickets[i].CName=CustomerName;
       res.tickets[i].SupportPlan=SupportPlan;
      


PSAssignee=PSAssignee.trim();
PSAssignee=PSAssignee.replace("_"," ");
      PSAssignee=PSAssignee.replace("-"," ");
var arr = PSAssignee.split(' ');

var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
if(arr.length>1)
{
var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

if(second!=="Tickets")
{
PSAssignee=first+" "+second;
}
else
{
PSAssignee=first;
}
}
else
{
PSAssignee=first;
}
      
      
      
      
      
      
        res.tickets[i].PSAssignee=PSAssignee;
       
         switch(severity)
           {
             case "critical":
                              res.tickets[i].severityOfTicket="Critical";
                             criticalTicketsArr.push(res.tickets[i]);
                             break;
             case "high":
                           res.tickets[i].severityOfTicket="High";
                          highTicketsArr.push(res.tickets[i]);
                          break;
             case "medium":
               				 res.tickets[i].severityOfTicket="Medium";
                          mediumTicketsArr.push(res.tickets[i]);
                          break;
             case "low":
               			 res.tickets[i].severityOfTicket="Low";
                         lowTicketsArr.push(res.tickets[i]);
                          break;
               
           }
      
   //  kony.print("Outer for loop iteration count:"+i);
    }
    globalResponsesLeadLag.push(res);
   // kony.print("Lengths of arrays:"+criticalTicketsArr.length+","+mediumTicketsArr.length+","+highTicketsArr.length+","+lowTicketsArr.length);
     criticalTicketsDummy0=JSON.parse(JSON.stringify(criticalTicketsArr));
    highTicketsDummy0=JSON.parse(JSON.stringify(highTicketsArr));
    mediumTicketsDummy0=JSON.parse(JSON.stringify(mediumTicketsArr));
    lowTicketsDummy0=JSON.parse(JSON.stringify(lowTicketsArr));
    
    criticalTicketsDummy=JSON.parse(JSON.stringify(criticalTicketsArr));
    highTicketsDummy=JSON.parse(JSON.stringify(highTicketsArr));
    mediumTicketsDummy=JSON.parse(JSON.stringify(mediumTicketsArr));
    lowTicketsDummy=JSON.parse(JSON.stringify(lowTicketsArr));
    
     criticalTicketsDummy1=JSON.parse(JSON.stringify(criticalTicketsArr));
    highTicketsDummy1=JSON.parse(JSON.stringify(highTicketsArr));
    mediumTicketsDummy1=JSON.parse(JSON.stringify(mediumTicketsArr));
    lowTicketsDummy1=JSON.parse(JSON.stringify(lowTicketsArr));
    
  if(viewNumLead===2 || viewNumLead===3 || viewNumLead===4)
    {
    var criticalTicketsToBreachArr=criticalTicketsToBreach(criticalTicketsDummy0);
      var highTicketsToBreachArr=highTicketsToBreach(highTicketsDummy0);
        var mediumTicketsToBreachArr=mediumTicketsToBreach(mediumTicketsDummy0);
      var lowTicketsToBreachArr=lowTicketsToBreach(lowTicketsDummy0);
    
    var criticalTicketsBreachedArr=criticalTicketsBreached(criticalTicketsDummy);
    var highTicketsBreachedArr=highTicketsBreached(highTicketsDummy);
        var mediumTicketsBreachedArr=mediumTicketsBreached(mediumTicketsDummy);
    var lowTicketsBreachedArr=lowTicketsBreached(lowTicketsDummy);
      copyViewNumber=viewNumLead;
    returnCountOfInteractions(viewNumLead);
      
    
//       kony.print("^^^^^^^^^^^MTTR^^^^^^^^^^"+mttrTicketsArr.length);
      
//       kony.print("length of tickets Array:"+criticalTicketsArr.length+" "+highTicketsArr.length+" "+mediumTicketsArr.length+" "+lowTicketsArr.length);
//       kony.print("length:to breach"+" "+criticalTicketsToBreachArr.length+" "+mediumTicketsToBreachArr.length+" "+highTicketsToBreachArr.length+" "+lowTicketsToBreachArr.length);
//        kony.print("length: breached"+" "+criticalTicketsBreachedArr.length+" "+mediumTicketsBreachedArr.length+" "+highTicketsBreachedArr.length+" "+lowTicketsBreachedArr.length);
//  kony.print("========================================================================");
      
//    for(var z=0;z<criticalTicketsToBreachArr.length;z++)
//      {
       
//        kony.print("Critical Tickets About to BREACH array:   TICKETID:"+criticalTicketsToBreachArr[z].ticketId+"  Hours:"+criticalTicketsToBreachArr[z].hours);
//      }
      
//        for( z=0;z<highTicketsToBreachArr.length;z++)
//      {
       
//        kony.print("High Tickets About to BREACH array:   TICKETID:"+highTicketsToBreachArr[z].ticketId+"  Hours:"+highTicketsToBreachArr[z].hours);
//      } 
      
//        for( z=0;z<mediumTicketsToBreachArr.length;z++)
//      {
       
//        kony.print(" Medium Tickets About to BREACH array:   TICKETID:"+mediumTicketsToBreachArr[z].ticketId+"  Hours:"+mediumTicketsToBreachArr[z].hours);
//      } 
      
//           for( z=0;z<lowTicketsToBreachArr.length;z++)
//      {
       
//        kony.print(" low Tickets About to BREACH array:   TICKETID:"+lowTicketsToBreachArr[z].ticketId+"  Hours:"+lowTicketsToBreachArr[z].hours);
//      } 
      
      
      
    
    totalTicketsBreachCount=criticalTicketsToBreachArr.length+mediumTicketsToBreachArr.length+highTicketsToBreachArr.length+lowTicketsToBreachArr.length; 
    
    totalTicketsBreached=criticalTicketsBreachedArr.length+mediumTicketsBreachedArr.length+highTicketsBreachedArr.length+lowTicketsBreachedArr.length;
   // kony.print("total tickets breachCount:"+totalTicketsBreachCount);
   if(totalTicketsBreachCount!==null)
      {
        
        switch(copyViewNumber)
      {
          case 0: 
                  frmDashboard.flxIndicators.flxLeadIndicator.flxNoFirstResList.flxNR0.lblNR02.text=totalTicketsBreachCount;
                  break;
          case 1: 
                  frmDashboard.flxIndicators.flxLeadIndicator.flxNoFirstResList.flxNR1.lblNR12.text=totalTicketsBreachCount;
                  break;
          case 2:
                   
                  cseOpenPendingHours=criticalHours+highHours+mediumHours+lowHours;
                  criticalHours=0;
                  highHours=0;
                  mediumHours=0;
                  lowHours=0;
          
                 popupCseTicketsArr=popupTicketsArr;	
         		 popupTicketsArr=[];
                
                popupCseTicketsBreachedArr=popupTicketsBreachedArr;
                popupTicketsBreachedArr=[];
                  
                 mttrCseTickets=mttrTicketsArr;
                 toBreachCount+=totalTicketsBreachCount;
                  breachedCount+=totalTicketsBreached;
                 frmDashboard.flxIndicators.flxLeadIndicator.flxResToBreachList.flxRTB0.lblRTB02.text=totalTicketsBreachCount;
                 frmDashboard.flxIndicators.flxLagIndicator.flxRBList.flxRB0.lblRB02.text=totalTicketsBreached;
                  mttrCount+=mttrTicketsArr.length;
                 frmDashboard.flxIndicators.flxLagIndicator.flxMttrList.flxMttr0.lblMttr02.text=mttrTicketsArr.length;
                   mttrTicketsArr=[];
                 
      			break;
      
       case 3:
                  productOpenPendingHours=criticalHours+highHours+mediumHours+lowHours;
                  criticalHours=0;
                  highHours=0;
                  mediumHours=0;
                  lowHours=0;
                  
              
  				popupProductTicketsArr=	popupTicketsArr;	
         		 popupTicketsArr=[];
                popupProductTicketsBreachedArr=popupTicketsBreachedArr;
                popupTicketsBreachedArr=[];
              
                 mttrProductTickets=mttrTicketsArr;
              
 						toBreachCount+=totalTicketsBreachCount;
                  breachedCount+=totalTicketsBreached;       
           mttrCount+=mttrTicketsArr.length;
                 frmDashboard.flxIndicators.flxLeadIndicator.flxResToBreachList.flxRTB1.lblRTB12.text=totalTicketsBreachCount;
                  frmDashboard.flxIndicators.flxLagIndicator.flxRBList.flxRB1.lblRB12.text=totalTicketsBreached;
            frmDashboard.flxIndicators.flxLagIndicator.flxMttrList.flxMttr1.lblMttr12.text=mttrTicketsArr.length;
                   mttrTicketsArr=[];
      			//frmDashboard.tabLagIndicator.tabMttrCalculation.
                break;
    case 4:
          
                  cloudOpenPendingHours=criticalHours+highHours+mediumHours+lowHours;
                  criticalHours=0;
                  highHours=0;
                  mediumHours=0;
                  lowHours=0;
          overallPremiumHours= cseOpenPendingHours+productOpenPendingHours+cloudOpenPendingHours;      
          
                 popupCloudTicketsArr=popupTicketsArr;	
         		 popupTicketsArr=[];
                popupCloudTicketsBreachedArr=popupTicketsBreachedArr;
                popupTicketsBreachedArr=[];
          
                 mttrCloudTickets=mttrTicketsArr;
             
          		toBreachCount+=totalTicketsBreachCount;
                  breachedCount+=totalTicketsBreached;
              mttrCount+=mttrTicketsArr.length;
                 frmDashboard.flxIndicators.flxLeadIndicator.flxResToBreachList.flxRTB2.lblRTB22.text=totalTicketsBreachCount;
                  frmDashboard.flxIndicators.flxLagIndicator.flxRBList.flxRB2.lblRB22.text=totalTicketsBreached;
                 frmDashboard.flxIndicators.flxLagIndicator.flxMttrList.flxMttr2.lblMttr22.text=mttrTicketsArr.length;
                   mttrTicketsArr=[];
          
              frmDashboard.flxLeadIndicator.flxResolutionToBreach.lblRTBCount.text=toBreachCount;
             frmDashboard.flxLagIndicator.flxResolutionBreached.lblRBCount.text=breachedCount;
              toBreachCount=0;
              breachedCount=0;
          
             frmDashboard.flxLagIndicator.flxMttr.lblMTTRCount.text=mttrCount;
             mttrCount=0;

      			
               break;
       
     
          //still cases to be handled
      
     		 }
//  			 viewNumLead++;
//  			 if(viewNumLead < viewArrLeadIndicator.length)
//   			  {
//   					    getLeadIndicatorResponse(viewArrLeadIndicator[viewNumLead]);
//   				  }
        
    	  }
      
      else
        {
          
          //alert("Some error Occured! Might be poor connection");
          frmDashboard.flxIndicators.opacity=1;
        }
      
     
    }
    else if(viewNumLead===5)
      {
var L2AutoSolvedCount=0;
var L3AutoSolvedCount=0;
var L2AutoSolvedArr=[];
var L3AutoSolvedArr=[];
         var operationName = mobileFabricConfiguration.integrationServices[0].operations[1];
         headers={};
     
       data={"viewId":viewArrLeadIndicator[viewNumLead]};
       mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
       mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, autoSolvedSuccess, autoSolvedError);
      }
    
    else
      {
    var criticalTicketsBreachedArr1=criticalTicketsBreached1(criticalTicketsDummy1);
       var highTicketsBreachedArr1=highTicketsBreached1(highTicketsDummy1);    
    var mediumTicketsBreachedArr1=mediumTicketsBreached1(mediumTicketsDummy1);
    var lowTicketsBreachedArr1=lowTicketsBreached1(lowTicketsDummy1);
        
        totalTicketsBreached1=criticalTicketsBreachedArr1.length+mediumTicketsBreachedArr1.length+highTicketsBreachedArr1.length+lowTicketsBreachedArr1.length;
     
        
         switch(viewNumLead)
          {
          case 0: 
                 nfrCse=res;
                // nfrCseEmpty=false;
                   firstResponseCseBreached=firstResponseBreachedArr;
                   firstResponseBreachedArr=[];
                   nfrCount+=parseInt(res.ticketsCount);
                   frbCount+=parseInt(totalTicketsBreached1);
                  frmDashboard.flxIndicators.flxLeadIndicator.flxNoFirstResList.flxNR0.lblNR02.text=res.ticketsCount;
                  frmDashboard.flxIndicators.flxLagIndicator.flxFirstResBreachedList.flxFRB0.lblFRB02.text=totalTicketsBreached1;
                  break;
          case 1: 
              nfrProduct=res;
             // nfrProductEmpty=false;
                  firstResponseProductBreached=firstResponseBreachedArr;
                   firstResponseBreachedArr=[];
                  nfrCount+=parseInt(res.ticketsCount);
                  frbCount+=parseInt(totalTicketsBreached1);
                  frmDashboard.flxIndicators.flxLeadIndicator.flxNoFirstResList.flxNR1.lblNR12.text=res.ticketsCount;
           frmDashboard.flxIndicators.flxLagIndicator.flxFirstResBreachedList.flxFRB1.lblFRB12.text=totalTicketsBreached1;
                  frmDashboard.flxLeadIndicator.flxNoFirstResponse.lblFirstResponseCount.text=nfrCount;
                  frmDashboard.flxLagIndicator.flxFirstResponseBreached.lblFirstResponseBreachedCount.text=frbCount;
                  nfrCount=0;
                   frbCount=0;
                  break;         

           }  
        
         viewNumLead++;
  if(viewNumLead < viewArrLeadIndicator.length)
    {
      getLeadIndicatorResponse(viewArrLeadIndicator[viewNumLead]);
    }
        
 }
     
    
  }
  else if(res.ticketsCount==="0")
    {
        switch(viewNumLead)
      {
          case 0: 
                    nfrCse=res;
                 
                   nfrCount+=parseInt(res.ticketsCount);
                   frbCount+=0;
                  frmDashboard.flxIndicators.flxLeadIndicator.flxNoFirstResList.flxNR0.lblNR02.text=0;
                  frmDashboard.flxIndicators.flxLagIndicator.flxFirstResBreachedList.flxFRB0.lblFRB02.text=0;
                  break;
          case 1: 
                 nfrProduct=res;    
               
                    nfrCount+=parseInt(res.ticketsCount);
                   frbCount+=0;
                  frmDashboard.flxIndicators.flxLeadIndicator.flxNoFirstResList.flxNR1.lblNR12.text=0;
           frmDashboard.flxIndicators.flxLagIndicator.flxFirstResBreachedList.flxFRB1.lblFRB12.text=0;
                        frmDashboard.flxLeadIndicator.flxNoFirstResponse.lblFirstResponseCount.text=nfrCount;
                  frmDashboard.flxLagIndicator.flxFirstResponseBreached.lblFirstResponseBreachedCount.text=frbCount;
                  nfrCount=0;
                   frbCount=0;
                  break;
          case 2:
                 frmDashboard.flxIndicators.flxLeadIndicator.flxResToBreachList.flxRTB0.lblRTB02.text=0;
               frmDashboard.flxIndicators.flxLagIndicator.flxRBList.flxRB0.lblRB02.text=0;
      			break;
      
       case 3:
                 frmDashboard.flxIndicators.flxLeadIndicator.flxResToBreachList.flxRTB1.lblRTB22.text=0;
              frmDashboard.flxIndicators.flxLagIndicator.flxRBList.flxRB1.lblRB12.text=0;
      			break;
    case 4:
                 frmDashboard.flxIndicators.flxLeadIndicator.flxResToBreachList.flxRTB2.lblRTB22.text=0;
                 frmDashboard.flxIndicators.flxLagIndicator.flxRBList.flxRB2.lblRB22.text=0;
      			break;
        case 5 :
                   
                autoSolvedSuccess(res);
     
          //still cases to be handled
      
      }
      
      viewNumLead++;
	  if(viewNumLead < viewArrLeadIndicator.length)
   	 {
      getLeadIndicatorResponse(viewArrLeadIndicator[viewNumLead]);
   	 }
    }
  

}



